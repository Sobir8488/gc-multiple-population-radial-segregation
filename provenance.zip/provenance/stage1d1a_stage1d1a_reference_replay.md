# Stage 1D1A reference replay

- Disposition: `CONDITIONAL_DELTA_GAMMA_SUPPORT_FROZEN_ABSOLUTE_SLOPES_BLOCKED`
- Conditional Delta-gamma support ready: True
- Conditional-ready clusters: 6/6
- Absolute density slopes ready: False
- Stage 1D1B authorized: True
- Error failures: 0

The replay used the frozen HST-only products after Stage 1C4R3. No radial slope was fitted.
