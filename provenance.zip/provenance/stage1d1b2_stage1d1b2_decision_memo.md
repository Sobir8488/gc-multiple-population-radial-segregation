# Stage 1D1B2 decision memo

The upper-lambda boundary event is not evidence for or against a physical radial trend. It says only that the one-standard-error rule prefers a model at least as smooth as the smoothest finite point in the original grid.

Extending the finite grid repeatedly after seeing this event would be arbitrary. The principled closure is instead to evaluate the exact nullspace of the already frozen roughness penalty, i.e. the lambda-to-infinity limit. If that limit lies within the original one-standard-error threshold it becomes the selected smoothing state. If it does not, and the largest finite lambda is still selected, Stage 1D2 remains blocked.

This stage therefore repairs an anticipated numerical boundary condition without inspecting a Delta-gamma science result.
