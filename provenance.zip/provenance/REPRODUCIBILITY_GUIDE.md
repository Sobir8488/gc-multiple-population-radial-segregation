# Reproducibility guide

The code is organized by the scientific stage used to generate the released products. Each stage directory contains its Python scripts, frozen configuration, Windows batch runners, and method/decision notes when available.

Important points:

1. The six primary science clusters are NGC 2808, NGC 5024, NGC 5272, NGC 3201, NGC 5904 and NGC 6205.
2. The final Stage1D3 analysis uses the v0.1.1 HUGS-index mapping hotfix; this hotfix is already overlaid in `code/stage1d3/`.
3. The primary likelihood uses continuous population probabilities.
4. The Stage1D1B smoothness boundary is closed with the exact second-difference penalty nullspace.
5. Stage1G is a post-freeze synthetic sensitivity calibration and does not reclassify real clusters.
6. Stage1G2 is a literature cross-check and does not refit the science sample.

The original project root contains external source-data paths that are not redistributed here. Users reproducing from scratch should obtain the HUGS source products separately and map them to the expected input paths described in the protocol files.

The package intentionally does not bundle intermediate Monte Carlo checkpoint files. The final calibration summaries, fixed seeds, and executable code are included.
