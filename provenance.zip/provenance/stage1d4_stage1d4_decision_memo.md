# Stage 1D4 decision memo

Stage 1D3C is the terminal adjudication layer. No further cluster-specific rescue model is permitted.

The final scientific partition is deliberately heterogeneous:

1. NGC 5272 is the cleanest positive detection. Its positive D_diff survives the full 2D and quality audit.
2. NGC 5024 and NGC 6205 retain robust footprint-marginalized radial-average D_diff values, but residual non-axisymmetry persists. Their radial averages may be reported, but neither cluster may be described as having a unique axisymmetric differential-slope field.
3. NGC 2808 is scientifically informative but excluded from the primary positive set because the terminal radially balanced quality closure fails. Its original Stage 1D2 signal must be reported as a quality-sensitive secondary result.
4. NGC 3201 and NGC 5904 remain null-compatible under the frozen Stage 1D2 gates.

This partition is stronger than forcing a universal segregation claim: it demonstrates that local multiple-population structure is cluster-dependent and that radial averaging can hide or coexist with non-axisymmetric structure.

R_peak is not a physical break-radius measurement in this pipeline. The nullspace-limit profiles place the numerical maximum of |Delta_gamma| near the outer claim-support boundary, so R_peak remains descriptive only.
