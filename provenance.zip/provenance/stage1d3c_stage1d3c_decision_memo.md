# Stage 1D3C decision memo

## Frozen interpretation of Stage 1D3B

The Stage 1D3B raw p-values imply, after the fixed four-cluster BH family:

- quality-conditioned angular q:
  NGC2808 = 0.004,
  NGC5024 = 0.00533,
  NGC6205 = 0.004,
  NGC5272 = 0.201;

- 80%-high-quality angular q:
  NGC2808 = 0.004,
  NGC5024 = 0.052,
  NGC6205 = 0.004,
  NGC5272 = 0.127.

Therefore:
- NGC 6205 is the clean persistent-nonaxisymmetry case;
- NGC 2808 remains unresolved because its radial D_diff was quality-trim sensitive even though angular structure persisted;
- NGC 5024 remains unresolved because the quality-conditioned and high-quality angular decisions disagree;
- NGC 5272 remains the clean control.

## Why radial balancing is the final test

A global quality trim can change the radial composition if image quality itself varies with crowding or detector position. Since D_diff is a radial quantity, the final quality-sensitivity test should preserve radial representation by construction. Stage 1D3C therefore performs quality ranking within radial strata.

## Why this stage is terminal

Repeatedly adding new diagnostics until NGC 2808 or NGC 5024 becomes publishable would be post-hoc rescue. Stage 1D3C instead converts any remaining ambiguity into a conservative exclusion/caveat. That allows the final paper to distinguish strong positive results from informative null or unresolved cases without weakening the pre-specified gates.
