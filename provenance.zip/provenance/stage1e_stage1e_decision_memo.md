# Stage 1E decision memo

Stage 1D4 is the terminal science classification. Stage 1E is strictly a manuscript-production layer.

The key presentation principle is to preserve the heterogeneity found by the validation pipeline:

- NGC 5272 is the clean radial benchmark.
- NGC 5024 and NGC 6205 retain robust footprint-marginalized radial averages but show persistent non-axisymmetry.
- NGC 2808 is not promoted back into the primary claim set.
- NGC 3201 and NGC 5904 remain null-compatible.

The figures therefore avoid any visual encoding that could imply that all positive Stage 1D2 point estimates have equal scientific status.

The profile figures retain the frozen claim-support curves and uncertainty bands. The summary D_diff figure uses bootstrap intervals, while the quality-closure figure makes the terminal NGC 2808 instability visually auditable.

R_peak is deliberately omitted from the primary manuscript figures because its numerical maximum is boundary-sensitive under the nullspace-limit model and is not a physical break-radius measurement.
