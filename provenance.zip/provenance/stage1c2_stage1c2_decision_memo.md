# Stage 1C2 decision memo — v0.1.0

## Frozen decision

Stage 1C2 uses an automated but conservative upper-RGB interval, from 2.00 to 0.60 F814W mag above the Stage1C1 MSTO anchor. The 0.60-mag faint exclusion is deliberate: it reduces turnoff/SGB ambiguity without using population information.

The RGB locus is selected only in the optical `F438W-F814W` CMD after high-membership and magnitude-dependent HUGS quality cuts. Chromosome-map coordinates are **not** used in the RGB-selection step.

For each frozen RGB sample, the `F275W-F814W` colour and `C_F275W,F336W,F438W` pseudo-colour are bounded by smoothed 5th and 95th percentile fiducials. The verticalisation follows the sign convention of Milone et al. (2017):

- `Delta_X = W_X (X-X_R)/(X_R-X_B)`
- `Delta_C = W_C (C_R-C)/(C_R-C_B)`

where the normalisation widths are evaluated two F814W magnitudes above the MSTO.

## Claim boundary

This stage freezes geometry in chromosome-map space only. It does not establish which locus is 1P or 2P, does not infer population probabilities, and does not assert population separability.

## External diagnostic

Published HST chromosome-map widths from Milone et al. (2017) are carried only as an external, non-gating benchmark. Differences are expected because Stage 1C2 uses the later public HUGS catalogue, an automated quality/RGB selection, and no tuning to the published widths.

## Next gate

Stage 1C3 may fit a probabilistic population model only after Stage 1C2 returns `rgb_verticalisation_ready=true` for all eight pilot clusters.
