# Stage 1D1B preflight

- Disposition: **CONDITIONAL_LOGIT_SPLINE_PROTOCOL_FROZEN_STAGE1D2_AUTHORIZED**
- Conditional-logit spline protocol frozen: **True**
- Protocol-ready clusters: **6/6**
- Stage 1D2 authorized: **True**
- Delta-gamma computed: **False**
- Absolute density slopes ready: **False**
- Error failures: **0**

## Frozen per-cluster design
- NGC2808: unique masters=4233, fit N=3809, claim N=3385, Rfit=[10.75,91.17] arcsec, Rclaim=[15.33,81.98] arcsec, Kint=7, basis=11.
- NGC5024: unique masters=1376, fit N=1238, claim N=1100, Rfit=[10.76,88.76] arcsec, Rclaim=[16.03,81.79] arcsec, Kint=5, basis=9.
- NGC5272: unique masters=1572, fit N=1414, claim N=1256, Rfit=[11.85,95.26] arcsec, Rclaim=[17.00,86.57] arcsec, Kint=6, basis=10.
- NGC3201: unique masters=147, fit N=131, claim N=117, Rfit=[13.28,95.70] arcsec, Rclaim=[29.33,88.66] arcsec, Kint=3, basis=7.
- NGC5904: unique masters=952, fit N=856, claim N=760, Rfit=[11.73,93.11] arcsec, Rclaim=[17.47,84.00] arcsec, Kint=3, basis=7.
- NGC6205: unique masters=1682, fit N=1512, claim N=1344, Rfit=[14.51,96.21] arcsec, Rclaim=[21.52,89.89] arcsec, Kint=6, basis=10.

## Frozen inference boundary
No slope has been inspected in this stage. Knots, CV folds, lambda grid, bootstrap design, permutation test, multiple-testing rule and stability gates are now fixed before Stage 1D2.

The likelihood is master-level. Any duplicated Stage 1C3 catalogue row is consolidated before science inference so it cannot receive double statistical weight.
