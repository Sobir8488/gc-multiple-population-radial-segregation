# Stage 1D2 v0.2.0 decision memo

The v0.1.0 Stage 1D2 runner was drafted before the Stage 1D1B2 boundary closure and therefore used a finite selected lambda. It is superseded.

Stage 1D2 v0.2.0 consumes the Stage 1D1B2 preflight as an authoritative prerequisite. All six observed fits and all primary bootstraps use the exact penalty-nullspace model. Permutation replays retain the original requirement to reselect smoothness under the null, but the candidate family is now closed by the exact nullspace endpoint.

This change is not science-driven tuning: it implements the boundary action triggered by the Stage 1D1B protocol itself and was frozen before the Stage 1D2 production result.

No absolute density slope is produced.
