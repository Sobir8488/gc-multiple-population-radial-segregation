# Stage 1C3B reference replay

- Disposition: `SIX_CLUSTER_PROBABILITY_FREEZE_WEAK_CLUSTERS_EXCLUDED`
- Error failures: 0
- Primary probability authorized: 6/8
- Excluded weak-classifier clusters: NGC6101, NGC7078

The replay used the exact uploaded `stage1c3_v010_local_checkpoint.zip`.

## Scientific outcome

Both weak clusters prefer a two-component full-covariance Gaussian mixture over a one-component full-covariance model, but the component centroids remain too close and the independent enrichment projection remains one-component. The improvement is therefore interpreted as covariance/shape structure rather than a secure 1P-like/2P-like split. Both clusters remain excluded from the primary probability sample.
