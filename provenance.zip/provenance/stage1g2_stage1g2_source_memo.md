# Stage 1G2 source/interpretation memo

Leitinger et al. (2023) is the closest homogeneous wide-field comparator for the six-cluster validation sample.

Key source-grounded points:
- NGC 5272: A+_4 = -0.36 +/- 0.05 and A+_total = -0.17 +/- 0.10; enriched/P2 central concentration weakens over the full radial range.
- NGC 5024: A+_4 = -0.42 +/- 0.05 and A+_total = -0.84 +/- 0.11; the paper emphasizes the importance of full radial coverage.
- NGC 3201: A+ = +0.46 +/- 0.12 and the P2 fraction is explicitly described as U-shaped, with P2 dominant in the centre and outskirts.
- NGC 6205: A+_4 = -0.04 +/- 0.04 and A+_total = -0.02 +/- 0.07; classified as spatially mixed to the outermost analysed radii.
- NGC 2808: the full-range P2-central signal is substantially stronger than the inner-only value.
- NGC 5904: included among spatially mixed systems in the paper's discussion/conclusions.

NGC 5024 should not be described as a published U-shaped case on the basis of this source. The strong non-monotonic/U-shaped case is NGC 3201.
