# Stage 1D3B decision memo

## Authoritative Stage 1D3 interpretation

Using the Stage 1D3 p-values and six-cluster BH correction:

- NGC 2808: azimuthal q=0.006 and quality-link q=0.006; sector jackknife 16/16.
- NGC 5024: azimuthal q=0.006 and quality-link q=0.045; sector jackknife 16/16.
- NGC 5272: azimuthal q=0.3588 and quality-link q=0.898; sector jackknife 16/16.
- NGC 6205: azimuthal q=0.006 and quality-link q=0.898; sector jackknife 16/16.

NGC 3201 and NGC 5904 remain radial/2D null cases and are not reopened.

## Why Stage 1D3B is needed

The three flagged robust clusters are not equivalent. NGC 2808 and NGC 5024 have both angular and
photometric-quality residual structure, while NGC 6205 has a strong angular residual without a quality-link
flag. A single “fail” label would discard useful information.

Stage 1D3B therefore asks two pre-specified questions: does the radial-average D_diff survive strict
population-blind quality restriction, and does the angular signal persist after controlling for a broader
quality vector?

No Stage 1D2 significance threshold or Stage 1D3 BH gate is changed.
