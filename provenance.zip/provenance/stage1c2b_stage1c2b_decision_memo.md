# Stage 1C2B decision memo

## Scientific trigger

Stage 1C2 produced `W_X = 0.434` for NGC 3201, compared with the diagnostic literature benchmark of about `0.211`, while its second chromosome width `W_C = 0.272` was much closer to the benchmark. The discrepancy must be understood before classifier fitting, but the literature widths are not used as tuning targets or acceptance gates.

## Frozen decisions

- No population labels are inferred in Stage 1C2B.
- The Stage 1C2 RGB sample and verticalised coordinates are immutable inputs.
- The optical spatial proxy uses only `F606W-F814W`, sky position, and the frozen RGB support.
- Spatially adjusted widths are sensitivity products and never replace Stage 1C2 science coordinates.
- The nominal reference width is explicitly distinguished from an **effective data-supported reference** if the nominal reference precedes the first valid fiducial node.
- Bootstrap uncertainty is evaluated at the first genuinely supported reference location.
- NGC 3201 is not excluded simply because its diagnostic literature width differs from Stage 1C2.

## Stage 1C3 rule

If Stage 1C2B passes, all eight pilot clusters may proceed to Stage 1C3. NGC 3201 carries a mandatory classifier sensitivity replay using a C-dominant / X-downweighted alternative in addition to the two-coordinate primary model. Any cluster with material spatial-proxy sensitivity also carries a spatial-proxy replay requirement.
