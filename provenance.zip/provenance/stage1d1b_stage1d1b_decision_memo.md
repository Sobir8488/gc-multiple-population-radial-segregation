# Stage 1D1B decision memo

## Why the model is frozen before fitting

The project has already encountered two places where seemingly reasonable alternative models could change an inclusion decision. Stage 1D1B therefore freezes the radial functional estimator, smoothing selection and claim gates before the first differential-slope profile is inspected.

## Functional model

The spline is applied to `eta(x)=logit[p2P(x)]`, with `x=ln(R/R_ref)`. The radial normalization is a constant shift in x and therefore cannot change `d eta/d ln R`. The desired differential slope follows analytically as `Delta_gamma=-d eta/dx`.

A cubic B-spline with a second-difference penalty is used. The number of interior knots is a deterministic function of the pre-existing sample size and is capped at seven, keeping NGC 3201 well away from a saturated fit.

## Smoothness

Lambda is selected from a fixed logarithmic grid with deterministic radial-interleaved cross-validation. The one-standard-error rule chooses the smoothest model still statistically indistinguishable from the minimum-CV-loss model. A lambda landing on either edge of the frozen grid is a protocol warning/failure, not an invitation to extend the grid after seeing the slope.

## Uncertainty

The primary bootstrap combines star sampling and latent 1P/2P assignment uncertainty by drawing `z_i~Bernoulli(q_i)` after radial-stratified resampling. A secondary bootstrap retains the fractional q values. Lambda is kept fixed during bootstrap so sampling/classification uncertainty is not conflated with smoothness uncertainty; smoothness is audited separately.

## Global and local claims

The global null is tested by q2P-radius permutation, repeating lambda selection in each permutation. Six cluster-level p-values are controlled with Benjamini-Hochberg FDR. Local derivative claims use a simultaneous, not merely pointwise, 95% bootstrap band and are restricted to q10-q90 radial support.

Absolute population-density slopes remain outside the authorized estimand.
