# Stage 1D1B reference replay

- Disposition: `CONDITIONAL_LOGIT_SPLINE_PROTOCOL_FROZEN_STAGE1D2_AUTHORIZED`
- Protocol frozen: True
- Protocol-ready clusters: 6/6
- Stage 1D2 authorized: True
- Delta-gamma computed: False
- Error failures: 0

The replay used the frozen Stage 1D1A project state and performed no science slope fit.

The master-level hygiene removes exactly 1 duplicate catalogue row(s) before the future likelihood. This preserves the frozen Stage 1C3 files while preventing double statistical weight.
