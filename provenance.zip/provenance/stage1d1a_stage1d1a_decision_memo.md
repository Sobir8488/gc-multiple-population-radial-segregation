# Stage 1D1A decision memo

The current normalized HUGS products contain no populated artificial-star detection-completeness field and no exact effective-area mask. Treating those quantities as known would be unjustified.

The principal differential-population question, however, can be written conditionally. Given a retained RGB star at radius R, the probability that it is 2P-like depends on the ratio of population intensities. Any multiplicative selection factor common to both populations cancels. This motivates the primary object

`Delta_gamma(R) = -d logit[p2P(R)] / d ln R`.

Stage 1C2 supplies a common RGB support and Stage 1C3 supplies a probability for every retained RGB star, including ambiguous objects. Stage 1D1A therefore uses the soft probabilities and does not invent a hard classification-completeness correction.

No absolute number-density normalization, no absolute gamma_1P/gamma_2P, and no footprint-corrected Sigma_k profile is authorized here.
