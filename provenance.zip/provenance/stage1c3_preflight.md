# Stage 1C3 preflight

- Disposition: **PARTIAL_HUGS_CLASSIFIER_FREEZE_REFINEMENT_REQUIRED**
- Classifier pipeline ready: **True**
- Full 8-cluster probability layer ready: **False**
- Supported clusters: **6/8**
- Error failures: **0**

## Cluster status
- NGC2808: `SUPPORTED_PHOTOMETRIC_1P2P`; K=5; DeltaBIC=1670.85; ambiguous=0.123
- NGC5024: `SUPPORTED_PHOTOMETRIC_1P2P`; K=2; DeltaBIC=78.19; ambiguous=0.173
- NGC5272: `SUPPORTED_PHOTOMETRIC_1P2P`; K=2; DeltaBIC=178.37; ambiguous=0.137
- NGC3201: `SUPPORTED_PHOTOMETRIC_1P2P`; K=2; DeltaBIC=11.34; ambiguous=0.116
- NGC6101: `WEAK_MODEL_SELECTED_K1+WEAK_BIC_EVIDENCE+HIGH_AMBIGUITY`; K=1; DeltaBIC=0.00; ambiguous=0.626
- NGC5904: `SUPPORTED_PHOTOMETRIC_1P2P`; K=2; DeltaBIC=152.76; ambiguous=0.093
- NGC6205: `SUPPORTED_PHOTOMETRIC_1P2P`; K=4; DeltaBIC=313.95; ambiguous=0.130
- NGC7078: `WEAK_MODEL_SELECTED_K1+WEAK_BIC_EVIDENCE+HIGH_AMBIGUITY`; K=1; DeltaBIC=0.00; ambiguous=0.969

## Claim boundary
Probabilities are photometric 1P-like/2P-like assignments. They are not spectroscopic chemical truth. No radial coordinate was used by the classifier, and wide-field Stetson transfer has not yet been performed.
