# Stage 1C3B decision memo

## Why this stage exists

Stage 1C3 produced stable photometric 1P-like/2P-like probabilities for six pilot clusters but selected a one-component tied-covariance model for NGC 6101 and NGC 7078. Stage 1C3B asks whether that failure reflects an overly restrictive covariance model or genuinely insufficient population separation in the frozen chromosome-map coordinates.

## Protected layer

NGC 2808, NGC 5024, NGC 5272, NGC 3201, NGC 5904, and NGC 6205 are frozen. Their Stage 1C3 model JSON and probability catalogues are checked against the exact SHA-256 values from the uploaded local checkpoint before any adjudication is executed.

## Independent diagnostics

For each weak cluster the stage compares tied-, full-covariance, and one-dimensional enrichment-projection mixtures. It then tests whether a full-covariance K=2 improvement corresponds to separated centroids rather than only unequal covariance matrices. Bootstrap and split-half replays test the stability of any proposed binary partition.

## Conservative rule

A covariance-only mixture split is not a population classification. Literature knowledge that a cluster hosts multiple populations is also not sufficient to assign individual stars in the present catalogue. Without star-level independent anchors, a weak cluster remains excluded from the primary probability sample if the frozen photometric coordinates do not support a stable location-separated partition.
