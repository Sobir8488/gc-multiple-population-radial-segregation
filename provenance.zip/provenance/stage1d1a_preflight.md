# Stage 1D1A preflight

- Disposition: **CONDITIONAL_DELTA_GAMMA_SUPPORT_FROZEN_ABSOLUTE_SLOPES_BLOCKED**
- Conditional Delta-gamma support ready: **True**
- Conditional-ready clusters: **6/6**
- Absolute gamma_1P/gamma_2P ready: **False**
- Stage 1D1B authorized: **True**
- Error failures: **0**

## Cluster support
- NGC2808: N=4233, primary R=[10.75,91.17] arcsec, Nsupport=3809, confident 1P/2P=1206/2137, max radial-quintile ambiguity=0.135.
- NGC5024: N=1376, primary R=[10.76,88.76] arcsec, Nsupport=1238, confident 1P/2P=306/725, max radial-quintile ambiguity=0.229.
- NGC5272: N=1572, primary R=[11.85,95.26] arcsec, Nsupport=1414, confident 1P/2P=303/912, max radial-quintile ambiguity=0.175.
- NGC3201: N=147, primary R=[13.28,95.70] arcsec, Nsupport=131, confident 1P/2P=61/56, max radial-quintile ambiguity=0.207.
- NGC5904: N=952, primary R=[11.73,93.11] arcsec, Nsupport=856, confident 1P/2P=190/589, max radial-quintile ambiguity=0.132.
- NGC6205: N=1683, primary R=[14.52,96.20] arcsec, Nsupport=1513, confident 1P/2P=316/998, max radial-quintile ambiguity=0.167.

## Identifiability boundary
The primary HST-only route is the conditional population-fraction likelihood. Under common selection of the two populations, footprint and detection completeness cancel from p2P(R), so Delta-gamma(R) is identifiable without claiming unavailable AST or effective-area products.

Absolute Sigma_1P, Sigma_2P, gamma_1P and gamma_2P remain blocked until true completeness and footprint products are available.
