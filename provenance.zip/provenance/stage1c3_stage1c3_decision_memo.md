# Stage 1C3 decision memo — probabilistic 1P-like/2P-like classification

## Upstream boundary

Stage 1C2 froze the RGB sample and chromosome-map geometry without population labels.
Stage 1C2B then authorized classifier development after its reference-support and population-blind spatial-photometry audit.

## Frozen classifier decisions

1. Only the two frozen chromosome-map coordinates enter the classifier.
2. No radial or sky-position variable is allowed.
3. The classifier is probabilistic; ambiguous stars are retained.
4. Morphological complexity is BIC-selected over K=1..6 tied-covariance Gaussian components.
5. Tied covariance is deliberate: component evidence must be driven mainly by location in chromosome-map space rather than by splitting one locus solely because of different covariance shapes.
6. Components are mapped to two photometric super-groups by the externally established chromosome-map enrichment direction: higher Delta_C and generally lower Delta_X is the 2P-like direction.
7. A K=1 selected model is not silently converted into a science-ready binary classifier. A forced K=2 diagnostic may be exported, but the cluster remains weak.
8. Hard labels are secondary summaries only. The downstream likelihood should use continuous probabilities.
9. NGC 3201 receives the Stage 1C2B-mandated X-downweighted/C-dominant replay.
10. High-confidence HUGS/master-star anchors are exported for a later wide-field transfer stage; no Stetson star receives a Stage 1C3 population probability.

## Scientific interpretation

The Stage 1C3 labels are called `photometric 1P-like` and `photometric 2P-like`.
They are not treated as direct chemical abundance classifications.
