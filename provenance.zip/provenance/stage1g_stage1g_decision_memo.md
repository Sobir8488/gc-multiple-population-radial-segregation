# Stage 1G decision memo

The observed six-cluster solution reached the exact penalty-nullspace endpoint in every cluster. That is scientifically
acceptable only if the estimator's sensitivity to curvature is explicitly calibrated.

The positive control is intentionally outcome-agnostic. We do not tune injected amplitudes until the selector leaves
the boundary. Two fixed amplitudes are used for both a single-hump and a sign-changing differential-slope truth.

The empirical-soft branch preserves the observed distribution of classifier confidence |q-0.5| but destroys the observed
radius-q association. Because this softening changes the expectation of q relative to the latent population probability,
recovery is scored against the analytically known expected softened-q profile rather than against the latent curve.

The Bernoulli branch is reported separately as the idealized selector-power ceiling.

If strong injected curvature is recovered with finite-interior smoothing, the manuscript can state that the observed
nullspace preference is not mechanically imposed by the estimator. If recovery remains weak, the manuscript must state
that local curvature power is limited and interpret the real profiles as low-order radial-average constraints.
