# Stage 1C3 reference replay

The frozen Stage 1C2 and Stage 1C2B products were replayed with the Stage 1C3 v0.1.0 classifier.

- classifier pipeline: READY
- supported photometric 1P-like/2P-like classifiers: 6/8
- weak clusters: NGC 6101, NGC 7078
- software/preflight errors: 0
- disposition: `PARTIAL_HUGS_CLASSIFIER_FREEZE_REFINEMENT_REQUIRED`

NGC 3201 passes the primary classifier gate and its mandatory X-downweighted/C-dominant replay is effectively identical to the primary classification (median absolute probability change about 6e-6; hard 0.5-label agreement 1.0 in the reference replay).

NGC 6101 and NGC 7078 are deliberately not forced into science-ready binary labels: BIC selects K=1 and the forced K=2 diagnostic is highly ambiguous. This is treated as an evidence outcome requiring a separate refinement/anchoring stage, not as a software failure.
