# Data provenance and release boundary

## External source data

The primary photometric source is the public HST UV Legacy Survey / HUGS catalogue archive. Raw third-party source catalogues are not redistributed in this Zenodo package.

Source archive:
https://archive.stsci.edu/prepds/hugs/

## Released derived data

The package includes derived probabilistic population assignments for the six final science clusters, radial-support products, frozen model-selection information, final numerical science tables, validation summaries, and figures.

## Excluded pathways

NGC 6101 and NGC 7078 were removed before the six-cluster primary radial analysis because the probabilistic population-classification support was insufficient under the frozen adjudication.

A ground-based population-transfer pathway was explored but did not pass the revised independent validation gates. It is therefore not used to extend the primary science outside the HST footprint and is not included as a primary reproducibility branch in this release.

## Absolute-density boundary

No absolute 1P/2P surface-density slope is released as a primary measurement because homogeneous artificial-star/effective-area closure is not available in the normalized public products used for all six clusters.

## Curvature boundary

The synthetic Stage1G calibration shows low recovery power for localized curvature under the frozen selector. The observed Delta-gamma curves are therefore broad radial constraints, not high-resolution shape reconstructions.
