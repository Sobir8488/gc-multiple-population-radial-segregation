# Stage 1D3 decision memo

Stage 1D2 established four globally significant conditional radial differential structures and two null-compatible clusters under the frozen spline/nullspace protocol. Those results are not yet manuscript-level axisymmetric claims.

A radial population fraction can look significant if one population is preferentially located in a particular angular sector, if one detector region carries a classification bias, or if a small part of the field dominates the radial contrast. Stage 1D3 therefore conditions on the exact Stage 1D2 radial baseline and asks for residual angular/quality dependence.

The azimuthal permutation preserves the q2P-radius pairing and shuffles only angle within radial strata. Thus it tests angular structure without destroying the already observed radial trend.

The sector jackknife is deliberately stronger for the four Stage 1D2 robust detections: a claim is retained only when the D_diff direction is not driven by one angular sector.

No threshold is adjusted separately for NGC 2808, NGC 5024, NGC 5272, NGC 3201, NGC 5904, or NGC 6205 after Stage 1D2 results.
