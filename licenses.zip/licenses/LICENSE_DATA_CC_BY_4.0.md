# Derived-data license

Unless a file states otherwise, the derived data, figures, tables, documentation, validation outputs and provenance material in this release are licensed under:

**Creative Commons Attribution 4.0 International (CC BY 4.0)**

License text:
https://creativecommons.org/licenses/by/4.0/

Please cite the Zenodo release and the associated paper when reusing these materials.

This license does not relicense third-party source catalogues, which are not redistributed in this archive.
