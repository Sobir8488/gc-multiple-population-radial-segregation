# Third-party data notice

Raw HST/HUGS source catalogues are not included in this archive.

Users should obtain the source products from the original MAST HUGS archive and follow the archive/provider attribution and usage terms:

https://archive.stsci.edu/prepds/hugs/

The CC BY 4.0 notice in this release applies only to the authors' derived outputs, figures, tables, documentation and provenance files.
