@echo off
python scripts\stage1g_input_preflight.py --root .
