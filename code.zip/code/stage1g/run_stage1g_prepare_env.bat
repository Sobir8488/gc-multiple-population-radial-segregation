@echo off
python -c "import numpy,pandas,scipy,matplotlib,yaml; print('Stage1G environment: OK')"
