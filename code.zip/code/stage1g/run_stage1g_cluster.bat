@echo off
setlocal
if "%~1"=="" (echo Usage: run_stage1g_cluster.bat NGC2808 & exit /b 2)
python scripts\stage1g_calibrate_cluster.py --root . --cluster %~1 || exit /b 1
endlocal
