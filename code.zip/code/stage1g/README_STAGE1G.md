# Stage 1G v0.1.0 — synthetic curvature recovery / positive-control calibration

This stage directly addresses the reviewer question raised by the observed **6/6 penalty-nullspace selections**:

> Is the nullspace outcome evidence-driven, or is the frozen selector unable to recover curvature?

Stage 1G does **not** assume the answer. It injects pre-specified known truths at the **actual radii and N of each cluster** and re-runs the exact finite-grid + nullspace selector.

Five truth scenarios are used:

- `LINEAR_D045` — a true nullspace member;
- `HUMP_G045` and `HUMP_G090`;
- `SIGNCHANGE_G045` and `SIGNCHANGE_G090`.

Two simulation branches are reported:

- `EMPIRICAL_SOFT` (primary): 100 replicates per scenario. It preserves the observed q2P ambiguity/confidence distribution via an empirical confidence kernel.
- `BERNOULLI` (secondary): 50 replicates per scenario with idealized hard latent memberships.

The main output is **not a forced PASS/FAIL**. It reports how often the frozen selector chooses:
- exact nullspace;
- finite interior lambda;
- finite upper/lower boundary;

and whether the injected hump/sign-change is actually recovered.

## Run cluster-by-cluster

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a

call run_stage1g_prepare_env.bat
call run_stage1g_selftest.bat
call run_stage1g_input_preflight.bat

call run_stage1g_cluster.bat NGC2808
call run_stage1g_cluster.bat NGC5024
call run_stage1g_cluster.bat NGC5272
call run_stage1g_cluster.bat NGC3201
call run_stage1g_cluster.bat NGC5904
call run_stage1g_cluster.bat NGC6205

call run_stage1g_finalize.bat
```

Runs are checkpointed every 10 replicates. Re-running an interrupted cluster resumes from its existing scenario CSVs.

Final products include:
- `outputs/stage1g/stage1g_power_summary.csv`
- `outputs/stage1g/stage1g_hump_interior_selection.pdf/png`
- `outputs/stage1g/stage1g_signchange_interior_selection.pdf/png`
- `validation/stage1g_preflight.md/json`

No real-cluster class may change in this stage.
