@echo off
python scripts\stage1g_finalize.py --root .
