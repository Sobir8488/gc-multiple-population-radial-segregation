@echo off
python scripts\stage1g_selftest.py
