
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1g_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1g_protocol.yaml").read_text(encoding="utf-8"))
    checks=[]
    def add(name,passed,detail):
        checks.append({"check":name,"passed":bool(passed),"severity":"ERROR","detail":detail})
    b2=json.loads((root/cfg["upstream"]["stage1d1b2_preflight"]).read_text(encoding="utf-8"))
    add("Stage1D1B2 boundary closed",
        b2.get("disposition")=="SMOOTHNESS_BOUNDARY_CLOSED_STAGE1D2_AUTHORIZED",
        b2.get("disposition",""))
    d4=json.loads((root/cfg["upstream"]["stage1d4_preflight"]).read_text(encoding="utf-8"))
    add("Stage1D4 science frozen",
        d4.get("disposition")=="CLAIM_SAFE_SCIENCE_SYNTHESIS_FROZEN_MANUSCRIPT_INTEGRATION_AUTHORIZED",
        d4.get("disposition",""))
    needed=[cfg["upstream"]["stage1d1b_protocol"],cfg["upstream"]["stage1d1b_readiness"],cfg["upstream"]["stage1d1b_knots"]]
    missing=[x for x in needed if not (root/x).exists()]
    for cid in cfg["clusters"]:
        for key in ["stage1c3_probability_pattern","stage1b_master_pattern"]:
            rel=cfg["upstream"][key].format(cluster=cid)
            if not (root/rel).exists(): missing.append(rel)
    add("all synthetic-calibration inputs present",not missing,";".join(missing) if missing else "all present")
    nerr=sum(not x["passed"] for x in checks)
    obj={"stage":"Stage1G","version":"0.1.0","generated_utc":utcnow(),
         "input_ready":nerr==0,"calibration_performed":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "disposition":"STAGE1G_INPUT_READY" if nerr==0 else "STAGE1G_INPUT_NOT_READY"}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1g_input_preflight.csv",index=False)
    write_json(val/"stage1g_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__": main()
