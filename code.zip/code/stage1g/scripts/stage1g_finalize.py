
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from stage1g_common import utcnow, write_json, sha256_file

def summarize(g):
    n=len(g)
    return pd.Series({
      "n_replicates":n,
      "nullspace_selection_fraction":float(np.mean(g.selection_state=="PENALTY_NULLSPACE_LIMIT")),
      "finite_interior_selection_fraction":float(np.mean(g.selection_state=="FINITE_INTERIOR")),
      "finite_upper_boundary_fraction":float(np.mean(g.selection_state=="FINITE_UPPER_BOUNDARY")),
      "finite_lower_boundary_fraction":float(np.mean(g.selection_state=="FINITE_LOWER_BOUNDARY")),
      "shape_recovery_fraction":float(np.mean(g.shape_recovered.astype(bool))),
      "median_delta_gamma_rmse":float(np.median(g.delta_gamma_rmse)),
      "median_D_diff_bias":float(np.median(g.D_diff_bias)),
      "truth_D_diff":float(g.truth_D_diff.iloc[0]),
      "truth_peak_abs_delta_gamma":float(g.truth_peak_abs_delta_gamma.iloc[0])
    })

def plot_power(summary,outdir):
    soft=summary.loc[summary.branch=="EMPIRICAL_SOFT"].copy()
    for family in ["HUMP","SIGNCHANGE"]:
        s=soft.loc[soft.scenario.str.startswith(family)].copy()
        fig,ax=plt.subplots(figsize=(7.2,4.8))
        for cid,g in s.groupby("cluster_id"):
            amp=[0.45 if "G045" in x else 0.90 for x in g.scenario]
            o=np.argsort(amp)
            ax.plot(np.asarray(amp)[o],
                    g.finite_interior_selection_fraction.to_numpy(float)[o],
                    marker="o",label=cid)
        ax.set_ylim(-0.03,1.03)
        ax.set_xlabel(r"Injected curvature amplitude in $\Delta\gamma$")
        ax.set_ylabel("Finite-interior selection fraction")
        ax.set_title(f"Stage 1G positive-control power: {family.lower()} truth")
        ax.legend(frameon=False,ncol=2,fontsize=8)
        fig.tight_layout()
        fig.savefig(outdir/f"stage1g_{family.lower()}_interior_selection.pdf",bbox_inches="tight")
        fig.savefig(outdir/f"stage1g_{family.lower()}_interior_selection.png",dpi=300,bbox_inches="tight")
        plt.close(fig)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1g_protocol.yaml").read_text(encoding="utf-8"))
    rows=[]; missing=[]
    for cid in cfg["clusters"]:
        p=root/"outputs/stage1g"/"clusters"/cid/f"{cid}_stage1g_all_replicates.csv"
        if not p.exists(): missing.append(cid)
        else: rows.append(pd.read_csv(p))
    if missing: raise SystemExit("Missing completed Stage1G clusters: "+",".join(missing))
    allrep=pd.concat(rows,ignore_index=True)
    out=root/"outputs/stage1g"; out.mkdir(parents=True,exist_ok=True)
    allrep.to_csv(out/"stage1g_all_replicates.csv.gz",index=False,compression="gzip")
    summary=(allrep.groupby(["cluster_id","branch","scenario"],sort=False)
             .apply(summarize,include_groups=False).reset_index())
    summary.to_csv(out/"stage1g_power_summary.csv",index=False)

    # Linear specificity summary.
    lin=summary.loc[(summary.branch=="EMPIRICAL_SOFT")&(summary.scenario=="LINEAR_D045")]
    linear_smooth=float(np.mean(lin.nullspace_selection_fraction+lin.finite_upper_boundary_fraction))
    # Strong curvature capacity: descriptive only.
    strong=summary.loc[(summary.branch=="EMPIRICAL_SOFT")&
                       (summary.scenario.isin(["HUMP_G090","SIGNCHANGE_G090"]))]
    median_interior=float(np.median(strong.finite_interior_selection_fraction))
    median_shape=float(np.median(strong.shape_recovery_fraction))
    plot_power(summary,out)

    obj={
      "stage":"Stage1G","version":"0.1.0","generated_utc":utcnow(),
      "calibration_complete":True,
      "n_clusters":6,
      "primary_branch":"EMPIRICAL_SOFT",
      "replicates_per_primary_scenario":int(cfg["simulation_branches"]["EMPIRICAL_SOFT"]["replicates_per_scenario"]),
      "secondary_branch":"BERNOULLI",
      "replicates_per_secondary_scenario":int(cfg["simulation_branches"]["BERNOULLI"]["replicates_per_scenario"]),
      "mean_linear_nullspace_or_upper_smooth_fraction":linear_smooth,
      "median_strong_curvature_finite_interior_fraction":median_interior,
      "median_strong_curvature_shape_recovery_fraction":median_shape,
      "real_cluster_classes_changed":False,
      "science_refit_performed":False,
      "interpretation":"DESCRIPTIVE_POWER_CALIBRATION_NO_POSTHOC_RECLASSIFICATION",
      "stage1g2_authorized":True,
      "disposition":"SYNTHETIC_CURVATURE_CALIBRATION_COMPLETE_STAGE1G2_AUTHORIZED"
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    write_json(val/"stage1g_preflight.json",obj)

    lines=["# Stage 1G synthetic curvature positive-control calibration","",
           f"- Calibration complete: **True**",
           f"- Mean linear nullspace-or-upper-smooth fraction: **{linear_smooth:.3f}**",
           f"- Median strong-curvature finite-interior selection fraction: **{median_interior:.3f}**",
           f"- Median strong-curvature shape-recovery fraction: **{median_shape:.3f}**","",
           "These are power/specificity diagnostics only. No observed cluster class is changed.","",
           "## Empirical-soft branch"]
    for _,r in summary.loc[summary.branch=="EMPIRICAL_SOFT"].iterrows():
        lines.append(
          f"- {r.cluster_id} {r.scenario}: interior={r.finite_interior_selection_fraction:.3f}, "
          f"null={r.nullspace_selection_fraction:.3f}, upper={r.finite_upper_boundary_fraction:.3f}, "
          f"shape={r.shape_recovery_fraction:.3f}, RMSE={r.median_delta_gamma_rmse:.3f}."
        )
    (val/"stage1g_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1g_output_manifest.csv":
            manifest.append({"path":str(p.relative_to(out)).replace("\\","/"),
                             "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1g_output_manifest.csv",index=False)

if __name__=="__main__": main()
