
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit, logit
from stage1g_common import utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def basis(x,knots,degree,deriv=0):
    n=len(knots)-degree-1
    eye=np.eye(n); cols=[]
    for j in range(n):
        s=BSpline(knots,eye[j],degree,extrapolate=False)
        if deriv: s=s.derivative(deriv)
        cols.append(s(np.asarray(x,float)))
    return np.column_stack(cols)

def penalty(n):
    d2=np.diff(np.eye(n),n=2,axis=0)
    return d2.T@d2

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P)
    N=V[:,w<tol]
    if N.shape[1]!=2:
        raise RuntimeError(f"Expected 2D penalty nullspace, got {N.shape[1]}")
    return N

def fit_logistic(B,y,P=None,lam=0.0,beta0=None,maxiter=40,tol=2e-8):
    B=np.asarray(B,float); y=np.asarray(y,float)
    if beta0 is None:
        m=float(np.clip(np.mean(y),1e-5,1-1e-5))
        b=np.zeros(B.shape[1],float)
        b[0]=math.log(m/(1-m))
    else:
        b=np.asarray(beta0,float).copy()
    if P is None:
        P=np.zeros((B.shape[1],B.shape[1]),float)
    for _ in range(maxiter):
        eta=B@b; p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta)+0.5*lam*(b@P@b))
        g=B.T@(p-y)+lam*(P@b)
        H=B.T@(w[:,None]*B)+lam*P+1e-9*np.eye(B.shape[1])
        step=np.linalg.solve(H,g)
        a=1.0
        for _ in range(20):
            c=b-a*step; e=B@c
            co=float(np.sum(np.logaddexp(0,e)-y*e)+0.5*lam*(c@P@c))
            if co<=obj+1e-12:
                b=c; break
            a*=0.5
        if np.max(np.abs(a*step))<tol: break
    return b

def nll(B,y,b):
    e=B@b
    return float(np.mean(np.logaddexp(0,e)-y*e))

def load_cluster(root,cid,cfg):
    prob=pd.read_csv(root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
    master=pd.read_csv(root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
    rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        rows.append({"master_star_id":str(mid),"q2p":float(np.mean(num(g.population_probability_2p)))})
    d=pd.DataFrame(rows)
    m=master[["master_star_id","x_common_arcsec","y_common_arcsec"]].copy()
    m["master_star_id"]=m.master_star_id.astype(str)
    m=m.drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    d["R"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    ready=pd.read_csv(root/cfg["upstream"]["stage1d1b_readiness"])
    r=ready.loc[ready.cluster_id==cid].iloc[0]
    Rref=float(r.R_ref_arcsec)
    d["x"]=np.log(d.R.to_numpy(float)/Rref)
    fit=(d.R>=float(r.r_fit_q05_arcsec))&(d.R<=float(r.r_fit_q95_arcsec))
    claim=(d.R>=float(r.r_claim_q10_arcsec))&(d.R<=float(r.r_claim_q90_arcsec))
    kd=pd.read_csv(root/cfg["upstream"]["stage1d1b_knots"])
    knots=kd.loc[kd.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
    xf=d.loc[fit,"x"].to_numpy(float)
    qf=d.loc[fit,"q2p"].to_numpy(float)
    order=np.argsort(xf,kind="mergesort")
    folds=np.empty(len(xf),int); folds[order]=np.arange(len(xf))%5
    degree=3
    B=basis(xf,knots,degree,0)
    P=penalty(B.shape[1]); N=nullspace(P); B0=B@N
    gx=np.linspace(np.log(float(r.r_claim_q10_arcsec)/Rref),
                   np.log(float(r.r_claim_q90_arcsec)/Rref),201)
    Bg=basis(gx,knots,degree,0)
    Dg=basis(gx,knots,degree,1)
    return d,fit,claim,xf,qf,folds,B,P,N,B0,gx,Bg,Dg,Rref

def truth_spec(name,xf,gx,qobs):
    eta0=float(logit(np.clip(np.mean(qobs),0.05,0.95)))
    xlo=float(gx[0]); xhi=float(gx[-1]); xmid=0.5*(xlo+xhi)
    span=xhi-xlo; h=0.5*span
    def eta_delta(x):
        x=np.asarray(x,float)
        if name=="LINEAR_D045":
            eta=eta0-0.45*(x-xmid)
            dg=np.full_like(x,0.45,float)
        elif name.startswith("HUMP_"):
            G=0.45 if "G045" in name else 0.90
            w=0.22*span
            u=(x-xmid)/w
            eta=eta0-G*w*np.tanh(u)
            dg=G/(np.cosh(u)**2)
        elif name.startswith("SIGNCHANGE_"):
            G=0.45 if "G045" in name else 0.90
            c=G/(2*h)
            eta=eta0+c*(x-xmid)**2
            dg=-2*c*(x-xmid)
        else:
            raise ValueError(name)
        return eta,dg
    etaf,dgf=eta_delta(xf)
    etag,dgg=eta_delta(gx)
    return etaf,dgf,etag,dgg

def softened_target(eta,dg,abar):
    p=expit(eta)
    q=0.5+abar*(2*p-1)
    dqdx=2*abar*p*(1-p)*(-dg)  # eta'=-Delta_gamma
    q=np.clip(q,1e-6,1-1e-6)
    dlogit=dqdx/(q*(1-q))
    return q,-dlogit

def cv_select(B,P,N,y,folds,lambdas):
    fold_losses={float(l):[] for l in lambdas}
    for f in range(5):
        tr=folds!=f; te=~tr
        warm=None
        for lam in lambdas:
            b=fit_logistic(B[tr],y[tr],P,float(lam),warm)
            warm=b
            fold_losses[float(lam)].append(nll(B[te],y[te],b))
    means={l:float(np.mean(v)) for l,v in fold_losses.items()}
    ses={l:float(np.std(v,ddof=1)/np.sqrt(5)) for l,v in fold_losses.items()}
    lmin=min(means,key=means.get)
    threshold=means[lmin]+ses[lmin]
    B0=B@N; nl=[]
    for f in range(5):
        tr=folds!=f; te=~tr
        th=fit_logistic(B0[tr],y[tr])
        nl.append(nll(B0[te],y[te],th))
    null_mean=float(np.mean(nl))
    if null_mean<=threshold+1e-12:
        return "PENALTY_NULLSPACE_LIMIT",None,threshold,null_mean
    eligible=[l for l in lambdas if means[float(l)]<=threshold+1e-12]
    lam=float(max(eligible))
    if lam==float(lambdas[0]):
        cat="FINITE_LOWER_BOUNDARY"
    elif lam==float(lambdas[-1]):
        cat="FINITE_UPPER_BOUNDARY"
    else:
        cat="FINITE_INTERIOR"
    return cat,lam,threshold,null_mean

def fit_selected(B,P,N,y,state,lam):
    if state=="PENALTY_NULLSPACE_LIMIT":
        th=fit_logistic(B@N,y)
        return "NULL",th
    b=fit_logistic(B,y,P,float(lam))
    return "FINITE",b

def recovered_delta(kind,coef,Dg,N):
    return -((Dg@N)@coef) if kind=="NULL" else -(Dg@coef)

def shape_recovered(name,state,dg,gx):
    if name=="LINEAR_D045":
        return state=="PENALTY_NULLSPACE_LIMIT"
    if name.startswith("HUMP_"):
        j=int(np.argmax(dg))
        internal=(j>=int(.15*len(gx))) and (j<=int(.85*len(gx)))
        return (state=="FINITE_INTERIOR") and internal and (float(np.max(dg))>0)
    if name.startswith("SIGNCHANGE_"):
        return (state=="FINITE_INTERIOR") and (float(np.min(dg))<0) and (float(np.max(dg))>0)
    return False

def replicate_seed(base,cid,branch,scenario,rep):
    token=f"{cid}|{branch}|{scenario}|{rep}"
    return int(base + sum((i+1)*ord(c) for i,c in enumerate(token)) % 100000000)

def run_scenario(root,cid,branch,scenario,nrep,cfg,cluster_cache):
    d,fit,claim,xf,qobs,folds,B,P,N,B0,gx,Bg,Dg,Rref=cluster_cache
    lambdas=np.asarray(cfg["frozen_selector"]["finite_lambda_grid"],float)
    etaf,dgf,etag,dgg=truth_spec(scenario,xf,gx,qobs)
    pfit=expit(etaf)
    confidence=np.abs(qobs-0.5)
    abar=float(np.mean(confidence))
    if branch=="EMPIRICAL_SOFT":
        _,truth_dg=softened_target(etag,dgg,abar)
    else:
        truth_dg=dgg
    truth_D=float(np.mean(truth_dg))
    truth_peak=float(np.max(np.abs(truth_dg)))
    out=root/"outputs/stage1g"/"clusters"/cid
    out.mkdir(parents=True,exist_ok=True)
    ck=out/f"{cid}_{branch}_{scenario}_replicates.csv"
    if ck.exists():
        done=pd.read_csv(ck)
        start=len(done)
        records=done.to_dict("records")
    else:
        start=0; records=[]
    base_seed=int(cfg["random_seed"])
    checkpoint=int(cfg["checkpoint_every"])
    for rep in range(start,nrep):
        rng=np.random.default_rng(replicate_seed(base_seed,cid,branch,scenario,rep))
        z=rng.binomial(1,pfit).astype(float)
        if branch=="BERNOULLI":
            y=z
        else:
            a=rng.choice(confidence,size=len(z),replace=True)
            y=np.clip(0.5+(2*z-1)*a,1e-6,1-1e-6)
        state,lam,thr,nloss=cv_select(B,P,N,y,folds,lambdas)
        kind,coef=fit_selected(B,P,N,y,state,lam)
        dg=recovered_delta(kind,coef,Dg,N)
        rmse=float(np.sqrt(np.mean((dg-truth_dg)**2)))
        D=float(np.mean(dg))
        records.append({
          "cluster_id":cid,"branch":branch,"scenario":scenario,"replicate":rep,
          "selection_state":state,"selected_lambda":lam if lam is not None else np.nan,
          "truth_D_diff":truth_D,"recovered_D_diff":D,"D_diff_bias":D-truth_D,
          "truth_peak_abs_delta_gamma":truth_peak,
          "delta_gamma_rmse":rmse,
          "shape_recovered":bool(shape_recovered(scenario,state,dg,gx))
        })
        if (rep+1)%checkpoint==0 or rep+1==nrep:
            pd.DataFrame(records).to_csv(ck,index=False)
            print(f"[Stage1G] {cid} {branch} {scenario}: {rep+1}/{nrep}")
    return pd.DataFrame(records)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=".")
    ap.add_argument("--cluster",required=True)
    args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1g_protocol.yaml").read_text(encoding="utf-8"))
    if args.cluster not in cfg["clusters"]: raise SystemExit("Unknown cluster")
    pre=json.loads((root/"validation/stage1g_input_preflight.json").read_text(encoding="utf-8"))
    if not pre.get("input_ready",False): raise SystemExit("Stage1G input not ready")
    cache=load_cluster(root,args.cluster,cfg)
    scenarios=["LINEAR_D045","HUMP_G045","HUMP_G090","SIGNCHANGE_G045","SIGNCHANGE_G090"]
    allrows=[]
    for branch in ["EMPIRICAL_SOFT","BERNOULLI"]:
        nrep=int(cfg["simulation_branches"][branch]["replicates_per_scenario"])
        for scenario in scenarios:
            allrows.append(run_scenario(root,args.cluster,branch,scenario,nrep,cfg,cache))
    df=pd.concat(allrows,ignore_index=True)
    out=root/"outputs/stage1g"/"clusters"/args.cluster
    df.to_csv(out/f"{args.cluster}_stage1g_all_replicates.csv",index=False)
    print(f"STAGE1G_CLUSTER_COMPLETE: {args.cluster}")

if __name__=="__main__": main()
