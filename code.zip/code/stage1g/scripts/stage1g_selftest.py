
import numpy as np
from scipy.special import expit

x=np.linspace(-1,1,201)
G=.9; w=.44
u=x/w
dg=G/(np.cosh(u)**2)
assert np.argmax(dg) in range(95,106)
c=G/(2*1.0)
dgs=-2*c*x
assert np.min(dgs)<0 and np.max(dgs)>0
print("STAGE1G_SELFTEST: PASS")
