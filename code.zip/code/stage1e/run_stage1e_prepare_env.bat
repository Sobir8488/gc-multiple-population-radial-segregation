@echo off
python -c "import numpy,pandas,matplotlib,yaml; print('Stage1E environment: OK')"
