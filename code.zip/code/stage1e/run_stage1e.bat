@echo off
setlocal
python scripts\stage1e_selftest.py || exit /b 1
python scripts\stage1e_input_preflight.py --root . || exit /b 1
python scripts\stage1e_generate.py --root . || exit /b 1
echo STAGE1E: PASS
endlocal
