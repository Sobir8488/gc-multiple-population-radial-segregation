@echo off
python scripts\stage1e_selftest.py
