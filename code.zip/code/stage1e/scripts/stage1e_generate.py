
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from stage1e_common import utcnow, write_json, sha256_file

CLASS_SHORT = {
 "PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":"clean radial",
 "PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":"radial avg + persistent 2D",
 "SECONDARY_EXCLUDED_QUALITY_SENSITIVE":"quality-sensitive exclusion",
 "NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE":"null-compatible"
}

def save_figure(fig,stem,dpi):
    stem=Path(stem); stem.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(stem.with_suffix(".pdf"),bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"),dpi=dpi,bbox_inches="tight")
    plt.close(fig)

def d_boot_summary(arr):
    d=np.mean(np.asarray(arr,float),axis=1)
    q=np.quantile(d,[.025,.16,.50,.84,.975])
    return {
      "D_p025":float(q[0]),"D_p16":float(q[1]),"D_p50":float(q[2]),
      "D_p84":float(q[3]),"D_p975":float(q[4]),"D_boot_sd":float(np.std(d,ddof=1))
    }

def profile_figure(root,cid,row,cfg,outfig):
    p=pd.read_csv(root/cfg["upstream"]["stage1d2_profile_pattern"].format(cluster=cid))
    R=pd.to_numeric(p.R_arcsec,errors="coerce").to_numpy(float)
    dg=pd.to_numeric(p.delta_gamma_observed,errors="coerce").to_numpy(float)
    lo95=pd.to_numeric(p.simultaneous95_lower,errors="coerce").to_numpy(float)
    hi95=pd.to_numeric(p.simultaneous95_upper,errors="coerce").to_numpy(float)
    lo68=pd.to_numeric(p.delta_gamma_p16,errors="coerce").to_numpy(float)
    hi68=pd.to_numeric(p.delta_gamma_p84,errors="coerce").to_numpy(float)

    fig,ax=plt.subplots(figsize=(6.4,4.6))
    ax.fill_between(R,lo95,hi95,alpha=0.18,label="95% simultaneous band")
    ax.fill_between(R,lo68,hi68,alpha=0.28,label="68% bootstrap interval")
    ax.plot(R,dg,linewidth=1.8,label=r"$\Delta\gamma(R)$")
    ax.axhline(0,linewidth=0.9,linestyle="--")
    ax.set_xscale("log")
    ax.set_xlabel("Projected radius R [arcsec]")
    ax.set_ylabel(r"$\Delta\gamma(R)$")
    ax.set_title(f"{cid}: {CLASS_SHORT[row.final_science_class]}")
    ax.legend(frameon=False,fontsize=8)
    ax.text(
      0.02,0.03,
      f"Ddiff={float(row.D_diff):.3f}\nqBH={float(row.bh_q_value):.4g}",
      transform=ax.transAxes,fontsize=8,va="bottom"
    )
    save_figure(fig,outfig/f"stage1e_{cid}_delta_gamma",int(cfg["figures"]["dpi"]))

def d_summary_figure(tab,unc,cfg,outfig):
    merged=tab.merge(unc,on="cluster_id",how="left",validate="one_to_one")
    order=["NGC5272","NGC5024","NGC6205","NGC2808","NGC3201","NGC5904"]
    merged=merged.set_index("cluster_id").loc[order].reset_index()
    y=np.arange(len(merged))
    x=merged.D_diff.to_numpy(float)
    e68=np.vstack([x-merged.D_p16.to_numpy(float),merged.D_p84.to_numpy(float)-x])
    e95=np.vstack([x-merged.D_p025.to_numpy(float),merged.D_p975.to_numpy(float)-x])

    fig,ax=plt.subplots(figsize=(7.5,4.8))
    ax.errorbar(x,y,xerr=e95,fmt="none",capsize=2,linewidth=1.0)
    ax.errorbar(x,y,xerr=e68,fmt="o",capsize=3,linewidth=1.8)
    ax.axvline(0,linestyle="--",linewidth=0.9)
    ax.set_yticks(y)
    labels=[
      f"{r.cluster_id}  [{CLASS_SHORT[r.final_science_class]}]"
      for _,r in merged.iterrows()
    ]
    ax.set_yticklabels(labels,fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel(r"$D_{\rm diff}$")
    ax.set_title("Terminal conditional differential-slope summary")
    save_figure(fig,outfig/"stage1e_Ddiff_summary",int(cfg["figures"]["dpi"]))

def quality_closure_figure(root,tab,cfg,outfig):
    tr=pd.read_csv(root/cfg["upstream"]["stage1d3c_balanced_trim"])
    ids=["NGC2808","NGC5024","NGC6205","NGC5272"]
    fig,ax=plt.subplots(figsize=(7.0,4.8))
    for cid in ids:
        s=tr.loc[tr.cluster_id==cid].sort_values("fraction_retained")
        ax.plot(
          100*s.fraction_retained.to_numpy(float),
          s.D_diff.to_numpy(float),
          marker="o",linewidth=1.4,label=cid
        )
        primary=float(tab.loc[tab.cluster_id==cid,"D_diff"].iloc[0])
        ax.scatter([100],[primary],marker="x")
    ax.axhline(0,linestyle="--",linewidth=0.9)
    ax.set_xlabel("Quality-balanced sample retained [%]")
    ax.set_ylabel(r"$D_{\rm diff}$")
    ax.set_title("Terminal radially balanced quality-closure replication")
    ax.legend(frameon=False,ncol=2,fontsize=8)
    save_figure(fig,outfig/"stage1e_quality_balanced_Ddiff",int(cfg["figures"]["dpi"]))

def write_latex_table(tab,unc,path):
    m=tab.merge(unc,on="cluster_id",how="left",validate="one_to_one")
    lines=[
      r"\begin{table*}",
      r"\centering",
      r"\caption{Terminal claim-safe classification and conditional differential-slope measurements.}",
      r"\label{tab:terminal_science}",
      r"\begin{tabular}{lrrrrl}",
      r"\hline",
      r"Cluster & $D_{\rm diff}$ & 68\% interval & $p_{\rm perm}$ & $q_{\rm BH}$ & Final class \\",
      r"\hline"
    ]
    for _,r in m.iterrows():
        cls=CLASS_SHORT[r.final_science_class]
        lines.append(
          f"{r.cluster_id} & {float(r.D_diff):.4f} & "
          f"[{float(r.D_p16):.4f},{float(r.D_p84):.4f}] & "
          f"{float(r.permutation_p_value):.4g} & {float(r.bh_q_value):.4g} & {cls} \\\\"
        )
    lines += [r"\hline",r"\end{tabular}",r"\end{table*}"]
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text("\n".join(lines)+"\n",encoding="utf-8")

def write_manuscript(root,tab,unc,cfg,outpath):
    m=tab.merge(unc,on="cluster_id",how="left",validate="one_to_one").set_index("cluster_id")
    n5272=m.loc["NGC5272"]; n5024=m.loc["NGC5024"]; n6205=m.loc["NGC6205"]
    n2808=m.loc["NGC2808"]; n3201=m.loc["NGC3201"]; n5904=m.loc["NGC5904"]

    text=f"""
% Stage 1E v0.1.0 claim-safe Results/Discussion integration
% This text is generated from frozen Stage 1D2--Stage 1D4 outputs.
% No new fit or adjudication is performed here.

\\subsection{{Conditional differential-slope results}}

We characterize the relative radial structure of the two photometrically identified populations through
\\[
\\Delta\\gamma(R)
=
\\gamma_{{2P}}(R)-\\gamma_{{1P}}(R)
=
-\\frac{{\\mathrm d}}{{\\mathrm d\\ln R}}
\\operatorname{{logit}} p_{{2P}}(R).
\\]
This conditional quantity remains identifiable under a population-blind common selection function, whereas the
absolute population-specific surface-density slopes are not claimed in the absence of a homogeneous artificial-star
and effective-area closure.

The six-cluster sample does not support a universal radial behaviour. After the frozen permutation test, six-cluster
Benjamini--Hochberg correction, simultaneous-band requirement, and the terminal spatial/quality audit, the sample
separates into one clean radial case, two robust radial-average cases with persistent non-axisymmetry, one
quality-sensitive exclusion, and two null-compatible cases.

NGC~5272 provides the cleanest positive result, with
$D_{{\\rm diff}}={n5272.D_diff:.4f}$ and $q_{{\\rm BH}}={n5272.bh_q_value:.4g}$.
Its positive differential slope implies that the 2P-like fraction decreases outward on average over the frozen HST
claim support. The result survives the two-dimensional azimuthal, photometric-quality, sector-jackknife, and terminal
quality-balanced checks.

NGC~5024 and NGC~6205 retain robust footprint-marginalized radial-average signals,
with $D_{{\\rm diff}}={n5024.D_diff:.4f}$ and {n6205.D_diff:.4f}, respectively, and
$q_{{\\rm BH}}={n5024.bh_q_value:.4g}$ and {n6205.bh_q_value:.4g}$.
For both clusters, however, significant residual angular structure persists after the quality-control closure.
Accordingly, these measurements are interpreted as robust radial averages over the observed HST footprint rather than
as unique axisymmetric cluster-wide differential-slope fields.

NGC~2808 illustrates why the terminal quality audit is required. Although the Stage~1D2 analysis initially produced
a positive signal ($D_{{\\rm diff}}={n2808.D_diff:.4f}$, $q_{{\\rm BH}}={n2808.bh_q_value:.4g}$),
the radially balanced quality closure did not preserve the inferred differential slope within the frozen stability
gate. We therefore exclude NGC~2808 from the primary radial-claim set and retain it only as a quality-sensitive
secondary result.

For NGC~3201 and NGC~5904, the point estimates remain positive
($D_{{\\rm diff}}={n3201.D_diff:.4f}$ and {n5904.D_diff:.4f}$), but the permutation/FDR and simultaneous-band
criteria do not support resolved differential radial structure. These clusters are therefore reported as
null-compatible rather than as weak positive detections.

\\subsection{{Interpretive boundary}}

The terminal classification demonstrates that radial averaging and two-dimensional population structure need not be
equivalent. In particular, NGC~5024 and NGC~6205 show that a statistically robust radial-average contrast can coexist
with persistent non-axisymmetry. This distinction is retained explicitly in the final claim language and prevents the
radial statistic from being over-interpreted as an axisymmetric field.

The numerical radius $R_{{\\rm peak}}$ is not interpreted as a physical transition or break radius. Under the frozen
nullspace-limit model, the maximum of $|\\Delta\\gamma|$ lies near the outer edge of the allowed claim interval for
several clusters, making $R_{{\\rm peak}}$ a descriptive boundary-sensitive diagnostic rather than a dynamical scale.

Finally, the present analysis does not report absolute $\\gamma_{{1P}}(R)$, $\\gamma_{{2P}}(R)$,
$\\Sigma_{{1P}}(R)$, or $\\Sigma_{{2P}}(R)$. Those quantities require a separate artificial-star recovery and
effective-area/footprint closure that is not part of the current conditional HST-only inference.
"""
    outpath.parent.mkdir(parents=True,exist_ok=True)
    outpath.write_text(text.strip()+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1e_protocol.yaml").read_text(encoding="utf-8"))
    pre=json.loads((root/"validation/stage1e_input_preflight.json").read_text(encoding="utf-8"))
    if not pre.get("input_ready",False):
        raise SystemExit("Stage1E input preflight is not ready.")

    tab=pd.read_csv(root/cfg["upstream"]["stage1d4_classification"])
    out=root/"outputs/stage1e"; out.mkdir(parents=True,exist_ok=True)
    figdir=root/"figures/stage1e"; figdir.mkdir(parents=True,exist_ok=True)
    tabledir=root/"tables"; tabledir.mkdir(parents=True,exist_ok=True)
    mandir=root/"manuscript"; mandir.mkdir(parents=True,exist_ok=True)

    unc_rows=[]
    for cid in cfg["clusters"]:
        arr=np.load(root/cfg["upstream"]["stage1d2_bootstrap_pattern"].format(cluster=cid))
        r={"cluster_id":cid}; r.update(d_boot_summary(arr)); unc_rows.append(r)
    unc=pd.DataFrame(unc_rows)
    unc.to_csv(out/"stage1e_Ddiff_bootstrap_intervals.csv",index=False)

    for cid in cfg["clusters"]:
        row=tab.loc[tab.cluster_id==cid].iloc[0]
        profile_figure(root,cid,row,cfg,figdir)

    d_summary_figure(tab,unc,cfg,figdir)
    quality_closure_figure(root,tab,cfg,figdir)

    write_latex_table(tab,unc,tabledir/"stage1e_terminal_science_summary.tex")
    write_manuscript(root,tab,unc,cfg,mandir/"stage1e_results_discussion.tex")

    # Copy a concise final table for convenience.
    final=tab.merge(unc,on="cluster_id",how="left",validate="one_to_one")
    final.to_csv(out/"stage1e_manuscript_science_table.csv",index=False)

    obj={
      "stage":"Stage1E","version":"0.1.0","generated_utc":utcnow(),
      "manuscript_figures_ready":True,
      "n_cluster_profile_figures":6,
      "Ddiff_summary_figure_ready":True,
      "quality_closure_figure_ready":True,
      "results_discussion_draft_ready":True,
      "latex_summary_table_ready":True,
      "science_refit_performed":False,
      "absolute_density_slopes_ready":False,
      "next_required_stage":cfg["next_stage"],
      "disposition":"MANUSCRIPT_FIGURES_AND_CLAIMSAFE_RESULTS_INTEGRATION_READY"
    }
    write_json(root/"validation/stage1e_preflight.json",obj)
    print(json.dumps(obj,indent=2))

    manifest=[]
    for p in sorted([
        *(out.rglob("*")),
        *(figdir.rglob("*")),
        tabledir/"stage1e_terminal_science_summary.tex",
        mandir/"stage1e_results_discussion.tex"
    ]):
        if Path(p).is_file():
            pp=Path(p)
            manifest.append({
              "path":str(pp.relative_to(root)).replace("\\","/"),
              "bytes":pp.stat().st_size,
              "sha256":sha256_file(pp)
            })
    pd.DataFrame(manifest).drop_duplicates("path").to_csv(out/"stage1e_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
