
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1e_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1e_protocol.yaml").read_text(encoding="utf-8"))
    p=json.loads((root/cfg["upstream"]["stage1d4_preflight"]).read_text(encoding="utf-8"))
    c=pd.read_csv(root/cfg["upstream"]["stage1d4_classification"])
    checks=[]
    def add(name,passed,detail):
        checks.append({"check":name,"passed":bool(passed),"severity":"ERROR","detail":detail})
    add(
        "Stage1D4 disposition frozen",
        p.get("disposition")==cfg["required_stage1d4_disposition"],
        p.get("disposition","")
    )
    got=dict(zip(c.cluster_id,c.final_science_class))
    add(
        "six terminal classes match",
        all(got.get(k)==v for k,v in cfg["required_final_classes"].items()),
        str({k:got.get(k) for k in cfg["required_final_classes"]})
    )
    missing=[]
    for cid in cfg["clusters"]:
        for key in ["stage1d2_profile_pattern","stage1d2_bootstrap_pattern"]:
            rel=cfg["upstream"][key].format(cluster=cid)
            if not (root/rel).exists(): missing.append(rel)
    for key in ["stage1d3_summary","stage1d3c_summary","stage1d3c_balanced_trim","stage1d4_claim_ledger"]:
        rel=cfg["upstream"][key]
        if not (root/rel).exists(): missing.append(rel)
    add("all figure/manuscript inputs present",not missing,";".join(missing) if missing else "all present")
    nerr=sum(not x["passed"] for x in checks)
    obj={
      "stage":"Stage1E","version":"0.1.0","generated_utc":utcnow(),
      "input_ready":nerr==0,
      "figures_generated":False,
      "manuscript_integration_generated":False,
      "n_checks":len(checks),"n_error_failures":nerr,
      "disposition":"STAGE1E_INPUT_READY" if nerr==0 else "STAGE1E_INPUT_NOT_READY"
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1e_input_preflight.csv",index=False)
    write_json(val/"stage1e_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
