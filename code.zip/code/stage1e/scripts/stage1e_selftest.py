
import numpy as np
# Stage1E must only summarize four frozen final science classes.
classes=[
 "PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE",
 "PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY",
 "SECONDARY_EXCLUDED_QUALITY_SENSITIVE",
 "NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE"
]
assert len(set(classes))==4
# Bootstrap Ddiff is defined as the mean profile derivative per replicate.
x=np.arange(30,dtype=float).reshape(3,10)
assert np.allclose(np.mean(x,axis=1),[4.5,14.5,24.5])
print("STAGE1E_SELFTEST: PASS")
