@echo off
python scripts\stage1e_input_preflight.py --root .
