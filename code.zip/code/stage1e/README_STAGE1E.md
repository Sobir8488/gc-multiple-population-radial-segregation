# Stage 1E v0.1.0 — manuscript figures and claim-safe Results/Discussion integration

Stage 1D4 is frozen. Stage 1E performs **no new science fit**.

It generates manuscript-grade products directly from the authoritative Stage 1D2--Stage 1D4 outputs:

- six standalone `Delta_gamma(R)` profile figures;
- one `D_diff` bootstrap-summary figure;
- one radially balanced quality-closure figure;
- bootstrap intervals for `D_diff`;
- a final manuscript science table;
- a LaTeX summary table;
- a claim-safe English Results/Discussion integration draft.

The frozen scientific partition remains:

- NGC 5272 — clean primary radial differential structure;
- NGC 5024 — primary radial-average structure with persistent non-axisymmetry;
- NGC 6205 — primary radial-average structure with persistent non-axisymmetry;
- NGC 2808 — secondary quality-sensitive exclusion;
- NGC 3201 — null-compatible;
- NGC 5904 — null-compatible.

No absolute `gamma_1P`, `gamma_2P`, `Sigma_1P`, or `Sigma_2P` is generated.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a

call run_stage1e_prepare_env.bat
call run_stage1e_selftest.bat
call run_stage1e_input_preflight.bat
call run_stage1e.bat
```

Expected final disposition:

`MANUSCRIPT_FIGURES_AND_CLAIMSAFE_RESULTS_INTEGRATION_READY`
