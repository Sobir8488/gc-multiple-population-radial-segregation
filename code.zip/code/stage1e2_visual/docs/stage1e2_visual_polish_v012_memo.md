# v0.1.2 visual-audit rationale

The v0.1.1 figures passed scientific readability and contained no clipping or data-rendering errors. The remaining
issue is typographic scale. At common manuscript reduction factors, several labels and annotations would reproduce
smaller than ideal.

The v0.1.2 hotfix changes only typography, canvas size, marker size and line width. All plotted arrays, uncertainty
bands, Ddiff values, p-values, q-values and final cluster classifications remain byte-for-byte sourced from the same
frozen Stage1D2--Stage1D4 outputs.
