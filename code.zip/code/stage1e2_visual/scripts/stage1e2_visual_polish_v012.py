
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image, ImageOps, ImageDraw, ImageFont

CLASS_SHORT = {
 "PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":"clean radial",
 "PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":"radial avg + persistent 2D",
 "SECONDARY_EXCLUDED_QUALITY_SENSITIVE":"quality-sensitive exclusion",
 "NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE":"null-compatible"
}

PROFILE_TITLE=14
AXIS=13
TICK=11.5
LEGEND=11
ANNOT=11.5

def save(fig, stem):
    stem=Path(stem)
    stem.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(stem.with_suffix(".pdf"),bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"),dpi=320,bbox_inches="tight")
    plt.close(fig)

def profile(root,cid,row,figdir):
    p=pd.read_csv(root/f"outputs/stage1d2_v020/clusters/{cid}/{cid}_science_profile.csv")
    R=pd.to_numeric(p.R_arcsec,errors="coerce").to_numpy(float)
    dg=pd.to_numeric(p.delta_gamma_observed,errors="coerce").to_numpy(float)
    lo95=pd.to_numeric(p.simultaneous95_lower,errors="coerce").to_numpy(float)
    hi95=pd.to_numeric(p.simultaneous95_upper,errors="coerce").to_numpy(float)
    lo68=pd.to_numeric(p.delta_gamma_p16,errors="coerce").to_numpy(float)
    hi68=pd.to_numeric(p.delta_gamma_p84,errors="coerce").to_numpy(float)

    fig,ax=plt.subplots(figsize=(7.4,5.3))
    ax.fill_between(R,lo95,hi95,alpha=0.18,label="95% simultaneous band")
    ax.fill_between(R,lo68,hi68,alpha=0.28,label="68% bootstrap interval")
    ax.plot(R,dg,linewidth=2.3,label=r"$\Delta\gamma(R)$")
    ax.axhline(0,linewidth=1.15,linestyle="--")
    ax.set_xscale("log")
    ax.set_xlabel(r"Projected radius $R$ [arcsec]",fontsize=AXIS,labelpad=5)
    ax.set_ylabel(r"$\Delta\gamma(R)$",fontsize=AXIS,labelpad=5)
    ax.set_title(f"{cid} — {CLASS_SHORT[row.final_science_class]}",
                 fontsize=PROFILE_TITLE,pad=10)
    ax.tick_params(axis="both",labelsize=TICK,length=4.5,width=0.9)
    ax.legend(frameon=False,fontsize=LEGEND,loc="upper left",
              handlelength=2.0,labelspacing=0.35)
    ax.text(
        0.965,0.935,
        rf"$D_{{\rm diff}}={float(row.D_diff):.3f}$"+"\n"+
        rf"$q_{{\rm BH}}={float(row.bh_q_value):.4g}$",
        transform=ax.transAxes,ha="right",va="top",
        fontsize=ANNOT,linespacing=1.25
    )
    fig.tight_layout()
    save(fig,figdir/f"stage1e_{cid}_delta_gamma")

def boot_intervals(root,cids):
    rows=[]
    for cid in cids:
        a=np.load(root/f"outputs/stage1d2_v020/clusters/{cid}/{cid}_bootstrap_primary.npy")
        d=np.mean(a,axis=1)
        q=np.quantile(d,[.025,.16,.50,.84,.975])
        rows.append({
            "cluster_id":cid,
            "D_p025":q[0],"D_p16":q[1],"D_p50":q[2],
            "D_p84":q[3],"D_p975":q[4]
        })
    return pd.DataFrame(rows)

def dsummary(root,tab,figdir):
    cids=["NGC5272","NGC5024","NGC6205","NGC2808","NGC3201","NGC5904"]
    unc=boot_intervals(root,cids)
    m=tab.merge(unc,on="cluster_id",how="left",validate="one_to_one")
    m=m.set_index("cluster_id").loc[cids].reset_index()
    y=np.arange(len(m))
    x=m.D_diff.to_numpy(float)
    e68=np.vstack([x-m.D_p16.to_numpy(float),m.D_p84.to_numpy(float)-x])
    e95=np.vstack([x-m.D_p025.to_numpy(float),m.D_p975.to_numpy(float)-x])

    fig,ax=plt.subplots(figsize=(9.4,6.2))
    ax.errorbar(x,y,xerr=e95,fmt="none",capsize=3.0,linewidth=1.25)
    ax.errorbar(x,y,xerr=e68,fmt="o",capsize=4.0,linewidth=2.0,markersize=6.0)
    ax.axvline(0,linestyle="--",linewidth=1.15)
    ax.set_yticks(y)
    labels=[f"{r.cluster_id}\n{CLASS_SHORT[r.final_science_class]}" for _,r in m.iterrows()]
    ax.set_yticklabels(labels,fontsize=11.5,linespacing=1.15)
    ax.invert_yaxis()
    ax.set_xlabel(r"$D_{\rm diff}$",fontsize=13,labelpad=5)
    ax.set_title("Terminal conditional differential-slope summary",fontsize=14,pad=10)
    ax.tick_params(axis="x",labelsize=11.5,length=4.5,width=0.9)
    fig.subplots_adjust(left=0.36,bottom=0.14,top=0.90,right=0.97)
    save(fig,figdir/"stage1e_Ddiff_summary")

def quality(root,tab,figdir):
    tr=pd.read_csv(root/"outputs/stage1d3c/stage1d3c_balanced_quality_trim.csv")
    ids=["NGC2808","NGC5024","NGC6205","NGC5272"]
    fig,ax=plt.subplots(figsize=(8.2,5.7))
    for cid in ids:
        s=tr.loc[tr.cluster_id==cid].sort_values("fraction_retained")
        ax.plot(
            100*s.fraction_retained.to_numpy(float),
            s.D_diff.to_numpy(float),
            marker="o",linewidth=1.9,markersize=6,label=cid
        )
        primary=float(tab.loc[tab.cluster_id==cid,"D_diff"].iloc[0])
        ax.scatter([100],[primary],marker="x",s=58,linewidths=1.6)
    ax.axhline(0,linestyle="--",linewidth=1.15)
    ax.set_xlabel("Quality-balanced sample retained [%]",fontsize=13,labelpad=5)
    ax.set_ylabel(r"$D_{\rm diff}$",fontsize=13,labelpad=5)
    ax.set_title("Terminal radially balanced quality-closure replication",fontsize=14,pad=10)
    ax.tick_params(labelsize=11.5,length=4.5,width=0.9)
    ax.legend(frameon=False,ncol=2,fontsize=10.8,loc="center right",
              handlelength=2.0,columnspacing=1.2,labelspacing=0.45)
    ax.text(
        0.975,0.045,
        r"$\times$ at 100% = untrimmed Stage 1D2 primary",
        transform=ax.transAxes,ha="right",va="bottom",fontsize=10.5
    )
    fig.tight_layout()
    save(fig,figdir/"stage1e_quality_balanced_Ddiff")

def contact_sheet(root):
    stems=[
        "stage1e_NGC2808_delta_gamma","stage1e_NGC5024_delta_gamma",
        "stage1e_NGC5272_delta_gamma","stage1e_NGC3201_delta_gamma",
        "stage1e_NGC5904_delta_gamma","stage1e_NGC6205_delta_gamma",
        "stage1e_Ddiff_summary","stage1e_quality_balanced_Ddiff"
    ]
    thumbs=[]
    cellw,cellh=900,650
    for stem in stems:
        im=Image.open(root/"figures/stage1e"/f"{stem}.png").convert("RGB")
        th=ImageOps.contain(im,(860,590))
        canvas=Image.new("RGB",(cellw,cellh),"white")
        canvas.paste(th,((cellw-th.width)//2,10))
        dr=ImageDraw.Draw(canvas)
        dr.text((20,620),stem,fill="black")
        thumbs.append(canvas)
    sheet=Image.new("RGB",(2*cellw,4*cellh),"white")
    for i,t in enumerate(thumbs):
        sheet.paste(t,((i%2)*cellw,(i//2)*cellh))
    out=root/"figures/stage1e2_contact_sheet_polished_largefonts.png"
    out.parent.mkdir(parents=True,exist_ok=True)
    sheet.save(out)
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=".")
    args=ap.parse_args()
    root=Path(args.root).resolve()
    tab=pd.read_csv(root/"outputs/stage1d4/stage1d4_final_cluster_classification.csv")
    figdir=root/"figures/stage1e"
    figdir.mkdir(parents=True,exist_ok=True)

    for cid in ["NGC2808","NGC5024","NGC5272","NGC3201","NGC5904","NGC6205"]:
        row=tab.loc[tab.cluster_id==cid].iloc[0]
        profile(root,cid,row,figdir)
    dsummary(root,tab,figdir)
    quality(root,tab,figdir)
    out=contact_sheet(root)
    print("STAGE1E2_VISUAL_POLISH_V012: PASS")
    print(f"Contact sheet: {out}")

if __name__=="__main__":
    main()
