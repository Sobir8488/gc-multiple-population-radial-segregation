@echo off
setlocal
python scripts\stage1e2_visual_polish_v012.py --root . || exit /b 1
echo STAGE1E2_VISUAL_POLISH_V012: PASS
endlocal
