# Stage 1E2 visual polish v0.1.2 — large-font finalization

The v0.1.1 contact sheet is scientifically correct, but the typography is still smaller than desirable for
journal reproduction and for a two-column audit sheet.

This hotfix increases typography substantially and slightly enlarges the figure canvases:

- profile titles: 14 pt;
- axis labels: 13 pt;
- tick labels: 11.5 pt;
- legends: about 11 pt;
- Ddiff/qBH annotations: 11.5 pt;
- Ddiff summary class labels: 11.5 pt;
- quality-closure legend/note: about 10.5--10.8 pt.

No science output changes.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a

call run_stage1e2_visual_polish_v012.bat
```

Then inspect/upload:

`figures\stage1e2_contact_sheet_polished_largefonts.png`
