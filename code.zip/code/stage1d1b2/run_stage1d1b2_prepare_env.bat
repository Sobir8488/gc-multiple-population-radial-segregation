@echo off
python -c "import numpy,pandas,scipy,yaml; print('Stage1D1B2 environment: OK')"
