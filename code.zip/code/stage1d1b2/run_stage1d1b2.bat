@echo off
setlocal
python scripts\stage1d1b2_selftest.py || exit /b 1
python scripts\stage1d1b2_close.py --root . || exit /b 1
python scripts\stage1d1b2_preflight.py --root . || exit /b 1
echo STAGE1D1B2: PASS
endlocal
