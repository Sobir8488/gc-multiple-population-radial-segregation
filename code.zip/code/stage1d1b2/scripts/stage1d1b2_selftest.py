
import numpy as np
n=9
D=np.diff(np.eye(n),n=2,axis=0); P=D.T@D
w,V=np.linalg.eigh(P)
assert np.sum(w<1e-9)==2
print("STAGE1D1B2_SELFTEST: PASS")
