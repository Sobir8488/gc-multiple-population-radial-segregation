
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d1b2_common import utcnow, write_json
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1b2_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d1b2/stage1d1b2_boundary_summary.csv")
    checks=[]
    def add(n,p,d): checks.append({"check":n,"passed":bool(p),"severity":"ERROR","detail":d})
    add("six clusters evaluated",len(s)==6 and set(s.cluster_id)==set(cfg["clusters"]),f"{len(s)}/6")
    add("all smoothing boundaries resolved",s.smoothness_boundary_resolved.all(),
        f"{int(s.smoothness_boundary_resolved.sum())}/6")
    add("no science fit performed",(s.science_fit_performed==False).all(),"boundary closure only")
    nerr=sum(not x["passed"] for x in checks)
    ready=nerr==0
    obj={
      "stage":"Stage1D1B2","version":"0.1.0","generated_utc":utcnow(),
      "smoothness_boundary_closed":ready,
      "stage1d2_authorized":ready,
      "delta_gamma_computed":False,
      "science_ready":False,
      "n_checks":len(checks),"n_error_failures":nerr,
      "selected_smoothing_states":dict(zip(s.cluster_id,s.selected_smoothing_state)),
      "disposition":("SMOOTHNESS_BOUNDARY_CLOSED_STAGE1D2_AUTHORIZED" if ready else
                     "SMOOTHNESS_BOUNDARY_UNRESOLVED_STAGE1D2_BLOCKED")
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d1b2_preflight.csv",index=False)
    write_json(val/"stage1d1b2_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)
if __name__=="__main__": main()
