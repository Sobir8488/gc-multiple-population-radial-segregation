
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit
from stage1d1b2_common import sha256_file, utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def basis(x,knots,degree):
    n=len(knots)-degree-1; eye=np.eye(n)
    return np.column_stack([BSpline(knots,eye[j],degree,extrapolate=False)(x) for j in range(n)])

def penalty(n):
    D=np.diff(np.eye(n),n=2,axis=0)
    return D.T@D

def fit(B,y,lam,P,beta0=None):
    y=np.asarray(y,float)
    if beta0 is None:
        m=float(np.clip(np.mean(y),1e-6,1-1e-6))
        b=np.zeros(B.shape[1]); b[0]=math.log(m/(1-m))
    else: b=np.asarray(beta0,float).copy()
    for _ in range(60):
        p=expit(B@b); w=np.maximum(p*(1-p),1e-6)
        g=B.T@(p-y)+lam*(P@b)
        H=B.T@(w[:,None]*B)+lam*P+1e-9*np.eye(B.shape[1])
        step=np.linalg.solve(H,g)
        b-=step
        if np.max(np.abs(step))<1e-8: break
    return b

def fit_unpen(B,y):
    P=np.zeros((B.shape[1],B.shape[1]))
    return fit(B,y,0.0,P)

def loss(B,y,b):
    z=B@b
    return float(np.mean(np.logaddexp(0,z)-y*z))

def dedup(prob,master):
    d=prob.groupby("master_star_id",as_index=False).agg(q2p=("population_probability_2p","mean"))
    m=master[["master_star_id","x_common_arcsec","y_common_arcsec"]].drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    d["r"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    return d

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P)
    N=V[:,w<tol]
    if N.shape[1]!=2:
        raise RuntimeError(f"Expected 2D penalty nullspace, got {N.shape[1]}")
    return N

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1b2_protocol.yaml").read_text(encoding="utf-8"))
    p1=root/"config/stage1d1b_protocol.yaml"
    if sha256_file(p1)!=cfg["required_stage1d1b_protocol_sha256"]:
        raise SystemExit("Stage1D1B protocol hash mismatch")
    p1cfg=yaml.safe_load(p1.read_text(encoding="utf-8"))
    ready=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_readiness_summary.csv")
    knots_all=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_frozen_knots.csv")
    folds_all=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_frozen_cv_folds.csv.gz")
    out=root/"outputs/stage1d1b2"; out.mkdir(parents=True,exist_ok=True)
    rows=[]; scans=[]
    lambdas=np.asarray(p1cfg["smoothness_selection"]["lambda_grid"],float)
    degree=int(p1cfg["model"]["degree"])
    for cid in cfg["clusters"]:
        prob=pd.read_csv(root/p1cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
        master=pd.read_csv(root/p1cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
        d=dedup(prob,master)
        s=ready.loc[ready.cluster_id==cid].iloc[0]
        r=d.r.to_numpy(float); q=d.q2p.to_numpy(float)
        fitmask=(r>=float(s.r_fit_q05_arcsec))&(r<=float(s.r_fit_q95_arcsec))
        x=np.log(r/float(s.R_ref_arcsec))
        knots=knots_all.loc[knots_all.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
        B=basis(x[fitmask],knots,degree); y=q[fitmask]
        P=penalty(B.shape[1]); N=nullspace(P); B0=B@N
        fd=folds_all.loc[folds_all.cluster_id==cid].set_index("master_star_id")
        mids=d.loc[fitmask,"master_star_id"].astype(str).tolist()
        folds=np.array([int(fd.loc[m,"cv_fold"]) for m in mids],int)
        finite=[]
        for lam in lambdas:
            fl=[]
            for f in range(5):
                tr=folds!=f; te=~tr
                b=fit(B[tr],y[tr],float(lam),P)
                fl.append(loss(B[te],y[te],b))
            finite.append((float(lam),float(np.mean(fl)),float(np.std(fl,ddof=1)/np.sqrt(5))))
        tab=pd.DataFrame(finite,columns=["lambda","mean_cv_loss","se_cv_loss"])
        j=int(tab.mean_cv_loss.idxmin())
        threshold=float(tab.loc[j,"mean_cv_loss"]+tab.loc[j,"se_cv_loss"])
        fl0=[]
        for f in range(5):
            tr=folds!=f; te=~tr
            th=fit_unpen(B0[tr],y[tr])
            fl0.append(loss(B0[te],y[te],th))
        null_loss=float(np.mean(fl0)); null_se=float(np.std(fl0,ddof=1)/np.sqrt(5))
        null_eligible=null_loss<=threshold+1e-15
        finite_eligible=tab.loc[tab.mean_cv_loss<=threshold+1e-15]
        largest=float(finite_eligible["lambda"].max())
        if null_eligible:
            selected="PENALTY_NULLSPACE_LIMIT"; resolved=True
        else:
            selected=f"LAMBDA_{largest:g}"
            resolved=largest<float(lambdas.max())
        boundary_hit=(largest==float(lambdas.max()))
        for _,z in tab.iterrows():
            scans.append({"cluster_id":cid,"candidate_type":"FINITE_LAMBDA","candidate":z["lambda"],
                          "mean_cv_loss":z["mean_cv_loss"],"se_cv_loss":z["se_cv_loss"],
                          "one_se_eligible":bool(z["mean_cv_loss"]<=threshold+1e-15)})
        scans.append({"cluster_id":cid,"candidate_type":"PENALTY_NULLSPACE_LIMIT","candidate":np.inf,
                      "mean_cv_loss":null_loss,"se_cv_loss":null_se,
                      "one_se_eligible":bool(null_eligible)})
        rows.append({
          "cluster_id":cid,"finite_min_loss_lambda":float(tab.loc[j,"lambda"]),
          "finite_upper_boundary_eligible":bool(boundary_hit),
          "one_se_threshold":threshold,
          "nullspace_cv_loss":null_loss,"nullspace_cv_se":null_se,
          "nullspace_one_se_eligible":bool(null_eligible),
          "selected_smoothing_state":selected,
          "smoothness_boundary_resolved":bool(resolved),
          "science_fit_performed":False
        })
        print(f"[Stage1D1B2] {cid}: finite-min={tab.loc[j,'lambda']:g} "
              f"upperEligible={boundary_hit} nullLoss={null_loss:.6f} "
              f"nullEligible={null_eligible} -> {selected} resolved={resolved}")
    pd.DataFrame(rows).to_csv(out/"stage1d1b2_boundary_summary.csv",index=False)
    pd.DataFrame(scans).to_csv(out/"stage1d1b2_cv_candidate_scan.csv",index=False)
    write_json(out/"stage1d1b2_boundary_freeze.json",{
      "stage":"Stage1D1B2","version":"0.1.0","generated_utc":utcnow(),
      "science_fit_performed":False,
      "delta_gamma_computed":False,
      "selection_rule":"exact penalty-nullspace limit added as lambda->infinity candidate"
    })

if __name__=="__main__": main()
