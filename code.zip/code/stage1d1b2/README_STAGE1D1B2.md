# Stage 1D1B2 v0.1.0 — smoothness-boundary closure

A dry run of the already frozen Stage 1D1B CV machinery can legitimately discover that the one-standard-error selector reaches the upper lambda boundary. Stage 1D1B explicitly declared such a boundary hit to be a protocol problem, so Stage 1D2 must not simply continue.

Stage 1D1B2 resolves that anticipated boundary without tuning to a slope result. It adds exactly one candidate: the mathematical `lambda -> infinity` limit of the existing second-difference penalty.

If `P=D2^T D2`, the limit is obtained by restricting the spline coefficients to `null(P)`, which is two-dimensional. This is the exact maximally smooth member already implied by the frozen Stage 1D1B model family; it is not a new flexible model.

No Delta-gamma curve, directional statistic, bootstrap interval or significance test is computed here.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d1b2_prepare_env.bat
call run_stage1d1b2_selftest.bat
call run_stage1d1b2.bat
```
