@echo off
python scripts\stage1d1b2_selftest.py
