@echo off
setlocal
python scripts\stage1d4_selftest.py || exit /b 1
python scripts\stage1d4_input_preflight.py --root . || exit /b 1
python scripts\stage1d4_synthesize.py --root . || exit /b 1
echo STAGE1D4: PASS
endlocal
