
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from stage1d4_common import utcnow, write_json, sha256_file

def f4(x):
    return "—" if pd.isna(x) else f"{float(x):.4f}"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d4_claim_synthesis.yaml").read_text(encoding="utf-8"))
    p3c=json.loads((root/cfg["upstream"]["stage1d3c_preflight"]).read_text(encoding="utf-8"))
    if p3c.get("disposition")!="STAGE1D3C_TERMINAL_ADJUDICATION_COMPLETE_CLAIM_SYNTHESIS_AUTHORIZED":
        raise SystemExit("Stage1D3C has not authorized Stage1D4 synthesis.")

    d2=pd.read_csv(root/cfg["upstream"]["stage1d2_summary"])
    d3=pd.read_csv(root/cfg["upstream"]["stage1d3_summary"])
    d3b=pd.read_csv(root/cfg["upstream"]["stage1d3b_summary"])
    d3c=pd.read_csv(root/cfg["upstream"]["stage1d3c_summary"])

    # Authoritative terminal-state checks.
    terminal=dict(zip(d3c.cluster_id,d3c.stage1d3c_status))
    for cid,expected in cfg["expected_terminal_statuses"].items():
        if terminal.get(cid)!=expected:
            raise RuntimeError(f"{cid}: expected terminal status {expected}, got {terminal.get(cid)}")

    rows=[]
    for cid in cfg["clusters"]:
        r2=d2.loc[d2.cluster_id==cid].iloc[0]
        r3=d3.loc[d3.cluster_id==cid].iloc[0]
        r3b=(d3b.loc[d3b.cluster_id==cid].iloc[0] if (d3b.cluster_id==cid).any() else None)
        r3c=(d3c.loc[d3c.cluster_id==cid].iloc[0] if (d3c.cluster_id==cid).any() else None)
        final_class=cfg["fixed_final_science_classes"][cid]
        primary=final_class.startswith("PRIMARY_")
        if final_class=="PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":
            interpretation="Clean conditional radial differential structure; 2P-like fraction declines outward on average."
            axisym="APPROXIMATE_RADIAL_INTERPRETATION_ALLOWED"
        elif final_class=="PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":
            interpretation="Robust HST-footprint radial-average differential structure with persistent residual non-axisymmetry."
            axisym="AXISYMMETRIC_FIELD_INTERPRETATION_FORBIDDEN"
        elif final_class=="SECONDARY_EXCLUDED_QUALITY_SENSITIVE":
            interpretation="Stage1D2 positive radial signal excluded from the primary claim set because quality-balanced closure is unstable."
            axisym="NO_PRIMARY_RADIAL_INTERPRETATION"
        else:
            interpretation="No resolved conditional differential radial structure under the frozen inference gates."
            axisym="NO_POSITIVE_STRUCTURE_CLAIM"

        rows.append({
          "cluster_id":cid,
          "final_science_class":final_class,
          "primary_claim_set":bool(primary),
          "D_diff":float(r2.D_diff),
          "S_diff":float(r2.S_diff),
          "R_peak_arcsec":float(r2.R_peak_arcsec),
          "permutation_p_value":float(r2.permutation_p_value),
          "bh_q_value":float(r2.bh_q_value),
          "local_simultaneous_band_gate_pass":bool(r2.local_simultaneous_band_gate_pass),
          "stage1d2_method_stable":bool(r2.all_method_stability_pass),
          "stage1d3_azimuthal_bh_q":float(r3.azimuthal_bh_q),
          "stage1d3_quality_bh_q":float(r3.quality_bh_q),
          "stage1d3_sector_jackknife_pass":bool(r3.sector_jackknife_pass),
          "stage1d3b_status":(str(r3b.stage1d3b_status) if r3b is not None else ""),
          "stage1d3c_status":(str(r3c.stage1d3c_status) if r3c is not None else ""),
          "axisymmetry_claim_boundary":axisym,
          "claim_safe_interpretation":interpretation
        })

    out=root/"outputs/stage1d4"; out.mkdir(parents=True,exist_ok=True)
    tab=pd.DataFrame(rows)
    tab.to_csv(out/"stage1d4_final_cluster_classification.csv",index=False)

    # Compact claim ledger.
    ledger=[]
    for _,r in tab.iterrows():
        if r.final_science_class=="PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":
            allowed="Robust conditional radial differential structure; positive D_diff; outward decline of p2P over frozen HST support."
            forbidden="Absolute gamma1P/gamma2P; physical break radius from R_peak."
        elif r.final_science_class=="PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":
            allowed="Robust footprint-marginalized radial-average D_diff with persistent non-axisymmetry explicitly retained."
            forbidden="Axisymmetric cluster-wide radial field; absolute gamma1P/gamma2P; physical break radius from R_peak."
        elif r.final_science_class=="SECONDARY_EXCLUDED_QUALITY_SENSITIVE":
            allowed="Secondary report of the Stage1D2 positive signal and its failure under quality-balanced closure."
            forbidden="Primary robust radial claim; axisymmetric interpretation; absolute gamma1P/gamma2P."
        else:
            allowed="Null-compatible statement: no resolved differential slope under frozen gates."
            forbidden="Positive segregation claim from the sign of the point estimate alone."
        ledger.append({"cluster_id":r.cluster_id,"final_class":r.final_science_class,
                       "allowed_claim":allowed,"forbidden_claim":forbidden})
    pd.DataFrame(ledger).to_csv(out/"stage1d4_claim_ledger.csv",index=False)

    # Manuscript-ready markdown.
    robust_clean=tab.loc[tab.final_science_class=="PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE"]
    persistent=tab.loc[tab.final_science_class=="PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY"]
    excluded=tab.loc[tab.final_science_class=="SECONDARY_EXCLUDED_QUALITY_SENSITIVE"]
    nulls=tab.loc[tab.final_science_class=="NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE"]

    lines=[
      "# Stage 1D4 claim-safe science synthesis","",
      "## Primary result",
      "",
      "The frozen HST-only conditional analysis does not support a universal single radial behaviour across the six clusters. "
      "After permutation/FDR inference and the full 2D/quality closure, the sample separates into a clean radial case, "
      "two robust radial-average cases with persistent non-axisymmetry, one quality-sensitive exclusion, and two null-compatible cases.",
      "",
      "### Clean radial differential structure"
    ]
    for _,r in robust_clean.iterrows():
        lines.append(
          f"- **{r.cluster_id}**: D_diff={r.D_diff:.4f}, S_diff={r.S_diff:.4f}, "
          f"p_perm={r.permutation_p_value:.4g}, q_BH={r.bh_q_value:.4g}. "
          "The 2P-like fraction decreases outward on average over the frozen HST claim support, and the result passes the 2D/quality closure."
        )
    lines += ["","### Robust radial-average structure with persistent non-axisymmetry"]
    for _,r in persistent.iterrows():
        lines.append(
          f"- **{r.cluster_id}**: D_diff={r.D_diff:.4f}, S_diff={r.S_diff:.4f}, "
          f"p_perm={r.permutation_p_value:.4g}, q_BH={r.bh_q_value:.4g}. "
          "The footprint-marginalized radial-average signal is retained, but significant residual angular structure persists; "
          "the cluster must not be described as axisymmetric."
        )
    lines += ["","### Quality-sensitive exclusion"]
    for _,r in excluded.iterrows():
        lines.append(
          f"- **{r.cluster_id}**: the Stage1D2 radial detection (D_diff={r.D_diff:.4f}, q_BH={r.bh_q_value:.4g}) "
          "is not retained in the primary claim set because the terminal radially balanced quality closure is unstable."
        )
    lines += ["","### Null-compatible clusters"]
    for _,r in nulls.iterrows():
        lines.append(
          f"- **{r.cluster_id}**: D_diff={r.D_diff:.4f}, p_perm={r.permutation_p_value:.4g}, "
          f"q_BH={r.bh_q_value:.4g}; no resolved differential radial structure is supported."
        )
    lines += ["","## Global claim boundary",
      "",
      "The primary science product is the conditional differential slope "
      "Delta_gamma(R)=gamma_2P(R)-gamma_1P(R)=-d logit[p_2P(R)]/d ln R. "
      "Absolute population-specific surface densities and absolute gamma_1P/gamma_2P remain outside the authorized inference because "
      "the present release does not contain the required artificial-star/effective-area closure.",
      "",
      "R_peak is retained only as a numerical maximum of |Delta_gamma| within the claim support and is not interpreted as a physical break radius."
    ]
    (out/"stage1d4_manuscript_results.md").write_text("\n".join(lines)+"\n",encoding="utf-8")

    # LaTeX table.
    tex=[
      r"\begin{table*}",
      r"\centering",
      r"\caption{Claim-safe terminal classification of the six-cluster HST sample.}",
      r"\label{tab:stage1d4_terminal}",
      r"\begin{tabular}{lrrrrl}",
      r"\hline",
      r"Cluster & $D_{\rm diff}$ & $S_{\rm diff}$ & $p_{\rm perm}$ & $q_{\rm BH}$ & Terminal class \\",
      r"\hline"
    ]
    short={
      "PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":"clean radial",
      "PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":"radial average + persistent 2D",
      "SECONDARY_EXCLUDED_QUALITY_SENSITIVE":"quality-sensitive exclusion",
      "NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE":"null-compatible"
    }
    for _,r in tab.iterrows():
        tex.append(
          f"{r.cluster_id} & {r.D_diff:.4f} & {r.S_diff:.4f} & "
          f"{r.permutation_p_value:.4g} & {r.bh_q_value:.4g} & {short[r.final_science_class]} \\\\"
        )
    tex += [
      r"\hline",
      r"\end{tabular}",
      r"\end{table*}"
    ]
    (root/"tables/stage1d4_terminal_classification.tex").write_text("\n".join(tex)+"\n",encoding="utf-8")

    # Overall freeze object.
    obj={
      "stage":"Stage1D4","version":"0.1.0","generated_utc":utcnow(),
      "claim_safe_synthesis_complete":True,
      "n_primary_clean_radial":int((tab.final_science_class=="PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE").sum()),
      "n_primary_persistent_nonaxisymmetric_radial_average":int((tab.final_science_class=="PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY").sum()),
      "n_secondary_quality_sensitive_excluded":int((tab.final_science_class=="SECONDARY_EXCLUDED_QUALITY_SENSITIVE").sum()),
      "n_null_compatible":int((tab.final_science_class=="NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE").sum()),
      "absolute_density_slopes_ready":False,
      "science_ready_for_manuscript_integration":True,
      "next_required_stage":cfg["next_stage"],
      "disposition":"CLAIM_SAFE_SCIENCE_SYNTHESIS_FROZEN_MANUSCRIPT_INTEGRATION_AUTHORIZED"
    }
    write_json(root/"validation/stage1d4_preflight.json",obj)
    print(json.dumps(obj,indent=2))

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d4_output_manifest.csv":
            manifest.append({"path":str(p.relative_to(out)).replace("\\","/"),
                             "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1d4_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
