
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d4_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d4_claim_synthesis.yaml").read_text(encoding="utf-8"))
    p=json.loads((root/"validation/stage1d3c_preflight.json").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d3c/stage1d3c_cluster_summary.csv")
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("Stage1D3C claim synthesis authorized",
        p.get("science_ready_for_claim_safe_synthesis",False),p.get("disposition",""))
    got=dict(zip(s.cluster_id,s.stage1d3c_status))
    add("terminal target statuses match",
        all(got.get(k)==v for k,v in cfg["expected_terminal_statuses"].items()),
        str({k:got.get(k) for k in cfg["expected_terminal_statuses"]}))
    add("final science classes fixed",len(cfg["fixed_final_science_classes"])==6,
        str(cfg["fixed_final_science_classes"]))
    nerr=sum(not x["passed"] for x in checks)
    obj={"stage":"Stage1D4","version":"0.1.0","generated_utc":utcnow(),
         "input_ready":nerr==0,"synthesis_performed":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "disposition":"STAGE1D4_INPUT_READY" if nerr==0 else "STAGE1D4_INPUT_NOT_READY"}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d4_input_preflight.csv",index=False)
    write_json(val/"stage1d4_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__": main()
