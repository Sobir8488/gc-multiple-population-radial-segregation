@echo off
python scripts\stage1d4_selftest.py
