# Stage 1D4 v0.1.0 — claim-safe science synthesis

Stage 1D3C is terminal. Stage 1D4 does not fit any new model and does not reopen an excluded cluster.

Frozen terminal interpretation:

- **NGC 5272** — primary clean radial differential structure.
- **NGC 5024** — primary radial-average differential structure with persistent non-axisymmetry.
- **NGC 6205** — primary radial-average differential structure with persistent non-axisymmetry.
- **NGC 2808** — secondary quality-sensitive exclusion from the primary radial claim set.
- **NGC 3201** — null-compatible.
- **NGC 5904** — null-compatible.

The resulting primary positive claim set therefore contains three clusters, but only NGC 5272 is clean under the 2D/quality audit. NGC 5024 and NGC 6205 retain robust radial-average `D_diff` while explicitly requiring a persistent-nonaxisymmetry qualifier.

Stage 1D4 generates:
- `stage1d4_final_cluster_classification.csv`;
- `stage1d4_claim_ledger.csv`;
- manuscript-ready Results text;
- a LaTeX terminal-classification table;
- the final synthesis preflight JSON.

Absolute `gamma_1P`, `gamma_2P`, `Sigma_1P`, and `Sigma_2P` remain blocked.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d4_prepare_env.bat
call run_stage1d4_selftest.bat
call run_stage1d4_input_preflight.bat
call run_stage1d4.bat
```
