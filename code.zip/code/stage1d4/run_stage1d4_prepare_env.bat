@echo off
python -c "import pandas,numpy,yaml; print('Stage1D4 environment: OK')"
