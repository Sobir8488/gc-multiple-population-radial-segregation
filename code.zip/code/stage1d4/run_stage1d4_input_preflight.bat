@echo off
python scripts\stage1d4_input_preflight.py --root .
