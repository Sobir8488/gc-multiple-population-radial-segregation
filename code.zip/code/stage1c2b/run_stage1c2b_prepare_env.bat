@echo off
python -c "import numpy,pandas,scipy,yaml; print('Stage1C2B environment: OK')"
