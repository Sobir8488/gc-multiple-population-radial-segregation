# Stage 1C2B method notes

The stage addresses three distinct effects that must not be conflated:

1. **Reference-support limitation.** A width quoted at a nominal reference magnitude is not directly data-supported when the first valid fiducial node lies fainter than that reference. A clipped PCHIP evaluation can still return a finite number, but the provenance must record that the value is anchored to the first supported node.
2. **Finite-sample uncertainty.** Sparse upper-RGB samples can produce broad uncertainty in 5–95% widths. This is evaluated by star-level bootstrap resampling with the full fiducial reconstruction repeated in each replicate.
3. **Spatial photometric sensitivity.** A leave-one-out nearest-neighbour median of residual `F606W-F814W` colour around a population-blind RGB ridge is used as an empirical local colour-offset proxy. Chromosome residuals are regressed against this proxy, and widths are recomputed only as a sensitivity analysis.

No quantity in this stage is a 1P/2P class label, and no radial information enters the Stage 1C2B population-blind systematics model.
