@echo off
setlocal
python -c "import numpy,pandas,scipy,yaml; print('Stage1C2B dependencies: OK')" || exit /b 1
call run_stage1c2b_selftest.bat || exit /b 1
python scripts\stage1c2b_systematics.py --root "%CD%"
if errorlevel 1 (
  echo STAGE1C2B: FAILED
  exit /b 1
)
echo STAGE1C2B: PASS
endlocal
