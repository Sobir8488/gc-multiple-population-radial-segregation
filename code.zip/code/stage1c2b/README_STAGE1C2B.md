# Stage 1C2B v0.1.0 — chromosome-width/systematics closure

Stage 1C2B is a **population-blind sensitivity stage** inserted between the frozen Stage 1C2 RGB/chromosome-map verticalisation and the Stage 1C3 probabilistic 1P/2P classifier.

It does **not** infer 1P/2P labels and does **not** overwrite the Stage 1C2 verticalised coordinates.

## What it closes

1. Replays the Stage 1C2 5–95% PCHIP width calculation exactly.
2. Audits whether the nominal Milone-style reference magnitude lies inside the actual data-supported fiducial-node interval.
3. Quantifies sampling uncertainty with non-parametric bootstrap resampling.
4. Builds a population-blind spatial-photometry proxy from local residuals in `F606W-F814W` around the RGB ridge.
5. Measures how much the chromosome widths change under empirical removal of that local optical proxy, across multiple neighbour scales.
6. Audits reference-location sensitivity and azimuthal variation of the optical proxy.
7. Freezes a Stage 1C3 sensitivity policy, with a special replay requirement for NGC 3201 if needed.

## Important interpretation boundary

The local optical proxy is **not called a physical differential-reddening map**. It can contain differential reddening, residual calibration structure, crowding-related colour offsets, or other spatial photometric effects. The adjusted widths are sensitivity diagnostics only.

## Run

From the existing project root:

```bat
conda activate mp-slopes-stage1a
call run_stage1c2b_prepare_env.bat
call run_stage1c2b_selftest.bat
call run_stage1c2b.bat
```

Expected successful disposition:

```text
SYSTEMATICS_CLOSED_STAGE1C3_AUTHORIZED
```

Primary products:

- `outputs/stage1c2b/stage1c2b_reference_support_audit.csv`
- `outputs/stage1c2b/stage1c2b_bootstrap_width_summary.csv`
- `outputs/stage1c2b/stage1c2b_spatial_proxy_sensitivity.csv`
- `outputs/stage1c2b/stage1c2b_reference_shift_sensitivity.csv`
- `outputs/stage1c2b/stage1c2b_sector_proxy_audit.csv`
- `outputs/stage1c2b/stage1c2b_decision_ledger.csv`
- `validation/stage1c2b_preflight.json`
- `validation/stage1c2b_preflight.md`

## Frozen boundary

A PASS authorizes Stage 1C3 classifier development. It does not make the manuscript science-ready; the classifier, detection completeness, classification completeness, and effective-area/footprint layers remain open.
