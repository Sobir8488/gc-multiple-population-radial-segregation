@echo off
python scripts\stage1c2b_selftest.py
