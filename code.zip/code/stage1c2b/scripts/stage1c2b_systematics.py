from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import PchipInterpolator
from scipy.spatial import cKDTree
from scipy.stats import spearmanr


def utcnow() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load_protocol(root: Path, config: str | None):
    p = Path(config).resolve() if config else root / 'config/stage1c2b_protocol.yaml'
    with p.open('r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def binned_quantiles(mag, val, lo, hi, width, step, min_n, quantiles):
    mag = np.asarray(mag, float)
    val = np.asarray(val, float)
    centers = np.arange(lo, hi + 1e-9, step)
    rows = []
    for c in centers:
        z = val[(np.abs(mag - c) <= width / 2) & np.isfinite(mag) & np.isfinite(val)]
        if z.size >= min_n:
            rows.append([c, int(z.size), *map(float, np.quantile(z, quantiles))])
    return np.asarray(rows, float) if rows else np.empty((0, 2 + len(quantiles)))


def fit_envelope(mag, val, lo, hi, fp):
    st = binned_quantiles(
        mag, val, lo, hi,
        float(fp['bin_width_mag']),
        float(fp['grid_step_mag']),
        int(fp['min_bin_stars']),
        (float(fp['lower_quantile']), 0.50, float(fp['upper_quantile'])),
    )
    if len(st) < int(fp['min_fiducial_nodes']):
        return None
    c = st[:, 0]
    qlo, med, qhi = st[:, 2], st[:, 3], st[:, 4]
    eps = 1e-4
    low = np.maximum(med - qlo, eps)
    high = np.maximum(qhi - med, eps)
    fmed = PchipInterpolator(c, med, extrapolate=True)
    flow = PchipInterpolator(c, np.log(low), extrapolate=True)
    fhigh = PchipInterpolator(c, np.log(high), extrapolate=True)

    def evaluate(x, clip=True):
        xx = np.asarray(x, float)
        if clip:
            xx = np.clip(xx, c.min(), c.max())
        mm = fmed(xx)
        bb = mm - np.exp(flow(xx))
        rr = mm + np.exp(fhigh(xx))
        return bb, mm, rr

    return st, evaluate


def envelope_width(mag, val, lo, hi, ref, fp):
    fit = fit_envelope(mag, val, lo, hi, fp)
    if fit is None:
        return np.nan, np.nan, np.nan, np.nan
    st, ev = fit
    b, _, r = ev([ref], clip=True)
    return float(r[0] - b[0]), float(st[:, 0].min()), float(st[:, 0].max()), float(np.sum(np.abs(np.asarray(mag) - ref) <= float(fp['bin_width_mag']) / 2))


def optical_ridge_residual(df: pd.DataFrame, lo: float, hi: float, sp: dict):
    mag = pd.to_numeric(df['mag_f814w'], errors='coerce').to_numpy(float)
    colour = (pd.to_numeric(df['mag_f606w'], errors='coerce') - pd.to_numeric(df['mag_f814w'], errors='coerce')).to_numpy(float)
    st = binned_quantiles(
        mag, colour, lo, hi,
        float(sp['ridge_bin_width_mag']),
        float(sp['ridge_grid_step_mag']),
        int(sp['ridge_min_bin_stars']),
        (0.16, 0.50, 0.84),
    )
    if len(st) < 5:
        # Sparse-sample fallback: use a global robust linear trend.
        ok = np.isfinite(mag) & np.isfinite(colour)
        if ok.sum() < 20:
            return np.full(len(df), np.nan), {'mode': 'FAILED', 'n_nodes': 0}
        A = np.c_[np.ones(ok.sum()), mag[ok] - np.nanmedian(mag[ok])]
        coef = np.linalg.lstsq(A, colour[ok], rcond=None)[0]
        pred = coef[0] + coef[1] * (mag - np.nanmedian(mag[ok]))
        return colour - pred, {'mode': 'ROBUST_LINEAR_FALLBACK', 'n_nodes': int(len(st))}
    c = st[:, 0]
    med = st[:, 3]
    f = PchipInterpolator(c, med, extrapolate=True)
    pred = f(np.clip(mag, c.min(), c.max()))
    return colour - pred, {'mode': 'PCHIP_MEDIAN_RIDGE', 'n_nodes': int(len(st))}


def sky_xy_arcsec(df: pd.DataFrame):
    ra = np.deg2rad(pd.to_numeric(df['ra_deg'], errors='coerce').to_numpy(float))
    dec = np.deg2rad(pd.to_numeric(df['dec_deg'], errors='coerce').to_numpy(float))
    ra0, dec0 = np.nanmedian(ra), np.nanmedian(dec)
    x = (ra - ra0) * np.cos(dec0) * (180 / np.pi) * 3600.0
    y = (dec - dec0) * (180 / np.pi) * 3600.0
    return np.column_stack([x, y])


def neighbour_proxy(df: pd.DataFrame, residual: np.ndarray, k: int):
    xy = sky_xy_arcsec(df)
    finite = np.isfinite(xy).all(axis=1) & np.isfinite(residual)
    out = np.full(len(df), np.nan)
    if finite.sum() <= max(k + 1, 10):
        return out
    idx_all = np.where(finite)[0]
    tree = cKDTree(xy[finite])
    kk = min(k + 1, finite.sum())
    _, ind = tree.query(xy[finite], k=kk)
    if ind.ndim == 1:
        ind = ind[:, None]
    for local_i, row in enumerate(ind):
        global_i = idx_all[local_i]
        candidates = idx_all[row]
        candidates = candidates[candidates != global_i][:k]
        if len(candidates) >= max(5, min(k, 10)):
            out[global_i] = np.nanmedian(residual[candidates])
    # Only relative local shifts matter.
    if np.isfinite(out).any():
        out = out - np.nanmedian(out)
    return out


def robust_slope(y, x, sigma_clip=3.0, iterations=4):
    y = np.asarray(y, float)
    x = np.asarray(x, float)
    ok = np.isfinite(y) & np.isfinite(x)
    if ok.sum() < 20 or np.nanstd(x[ok]) < 1e-8:
        return np.nan, np.nan, int(ok.sum())
    xx, yy = x[ok], y[ok]
    keep = np.ones(len(xx), dtype=bool)
    coef = np.array([np.nan, np.nan])
    for _ in range(int(iterations)):
        if keep.sum() < 10:
            break
        A = np.c_[np.ones(keep.sum()), xx[keep]]
        coef = np.linalg.lstsq(A, yy[keep], rcond=None)[0]
        resid = yy - (coef[0] + coef[1] * xx)
        center = np.nanmedian(resid[keep])
        scale = 1.4826 * np.nanmedian(np.abs(resid[keep] - center)) + 1e-12
        keep = np.abs(resid - center) <= float(sigma_clip) * scale
    return float(coef[1]), float(coef[0]), int(keep.sum())


def bootstrap_widths(mag, x, c, lo, hi, ref_eff, fp, bp, rng):
    rows = []
    n = len(mag)
    reps = int(bp['replicates'])
    for b in range(reps):
        ii = rng.integers(0, n, n)
        wx, *_ = envelope_width(mag[ii], x[ii], lo, hi, ref_eff, fp)
        wc, *_ = envelope_width(mag[ii], c[ii], lo, hi, ref_eff, fp)
        rows.append((b, wx, wc))
    out = pd.DataFrame(rows, columns=['replicate', 'W_X', 'W_C'])
    return out


def sector_proxy_audit(df, proxy, n_sectors, min_stars):
    xy = sky_xy_arcsec(df)
    theta = np.arctan2(xy[:, 1], xy[:, 0])
    edges = np.linspace(-np.pi, np.pi, int(n_sectors) + 1)
    sector = np.clip(np.digitize(theta, edges) - 1, 0, int(n_sectors) - 1)
    rows = []
    for s in range(int(n_sectors)):
        z = proxy[sector == s]
        rows.append({
            'sector': s,
            'n_stars': int(np.sum(sector == s)),
            'proxy_median': float(np.nanmedian(z)) if np.isfinite(z).sum() >= int(min_stars) else np.nan,
            'proxy_mad': float(1.4826 * np.nanmedian(np.abs(z - np.nanmedian(z)))) if np.isfinite(z).sum() >= int(min_stars) else np.nan,
            'adequate': bool(np.isfinite(z).sum() >= int(min_stars)),
        })
    return rows


def check_upstream(root: Path, protocol: dict):
    p = root / protocol['upstream']['stage1c2_preflight']
    if not p.exists():
        return False, {'missing': str(p)}
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        return False, {'parse_error': repr(e)}
    ready = bool(d.get('rgb_verticalisation_ready', False) and int(d.get('n_error_failures', 1)) == 0 and int(d.get('n_clusters_stage1c3_eligible', 0)) == 8)
    return ready, d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path.cwd())
    ap.add_argument('--config', default=None)
    args = ap.parse_args()
    root = args.root.resolve()
    protocol = load_protocol(root, args.config)
    out = root / 'outputs/stage1c2b'
    val = root / 'validation'
    out.mkdir(parents=True, exist_ok=True)
    val.mkdir(parents=True, exist_ok=True)
    (out / 'clusters').mkdir(parents=True, exist_ok=True)

    fp = protocol['fiducial_replay']
    bp = protocol['bootstrap']
    sp = protocol['spatial_proxy']
    sa = protocol['spatial_sector_audit']
    checks, support_rows, spatial_rows, ref_rows, boot_summary_rows, sector_rows, decision_rows = [], [], [], [], [], [], []

    upstream_ready, upstream_meta = check_upstream(root, protocol)
    checks.append({'cluster_id':'GLOBAL','check':'Stage1C2 RGB verticalisation ready','severity':'ERROR','passed':upstream_ready,'detail':json.dumps(upstream_meta, sort_keys=True)[:500]})

    freeze_p = root / protocol['upstream']['stage1c2_rgb_freeze']
    bench_p = root / protocol['upstream']['stage1c2_width_benchmark']
    if not freeze_p.exists() or not bench_p.exists():
        raise FileNotFoundError('Stage1C2 freeze/benchmark inputs are missing')
    freeze = pd.read_csv(freeze_p).set_index('cluster_id')
    bench = pd.read_csv(bench_p).set_index('cluster_id')
    rng = np.random.default_rng(int(bp['random_seed']))

    for cid in protocol['pilot_clusters']:
        star_p = root / protocol['upstream']['rgb_verticalised_pattern'].format(cluster=cid)
        exists = star_p.exists() and cid in freeze.index and cid in bench.index
        checks.append({'cluster_id':cid,'check':'Stage1C2B inputs exist','severity':'ERROR','passed':exists,'detail':f'star={star_p.exists()} freeze={cid in freeze.index} benchmark={cid in bench.index}'})
        if not exists:
            decision_rows.append({'cluster_id':cid,'stage1c2b_status':'INPUT_MISSING','stage1c3_authorized':False,'reason':'required Stage1C2 input missing'})
            continue

        df = pd.read_csv(star_p, low_memory=False)
        fr = freeze.loc[cid]
        bn = bench.loc[cid]
        n_expected = int(fr['n_final_rgb'])
        checks.append({'cluster_id':cid,'check':'Frozen RGB row count conserved','severity':'ERROR','passed':len(df)==n_expected,'detail':f'rows={len(df)} expected={n_expected}'})
        no_labels = bool(df.get('population_label_status', pd.Series('', index=df.index)).astype(str).eq('NOT_INFERRED_STAGE1C2').all())
        checks.append({'cluster_id':cid,'check':'No 1P/2P labels present','severity':'ERROR','passed':no_labels,'detail':'Stage1C2B remains population-blind'})

        mag = pd.to_numeric(df['mag_f814w'], errors='coerce').to_numpy(float)
        X = pd.to_numeric(df['x_f275w_f814w'], errors='coerce').to_numpy(float)
        C = pd.to_numeric(df['c_f275w_f336w_f438w'], errors='coerce').to_numpy(float)
        lo, hi, nominal_ref = float(fr['rgb_support_bright_f814w']), float(fr['rgb_support_faint_f814w']), float(fr['reference_f814w'])

        wx0, xfirst, xlast, nxref = envelope_width(mag, X, lo, hi, nominal_ref, fp)
        wc0, cfirst, clast, ncref = envelope_width(mag, C, lo, hi, nominal_ref, fp)
        identity_err = max(abs(wx0-float(fr['W_X_reference'])), abs(wc0-float(fr['W_C_reference'])))
        checks.append({'cluster_id':cid,'check':'Stage1C2 width replay identity','severity':'ERROR','passed':identity_err<=float(protocol['validation']['max_baseline_width_identity_abs_error']),'detail':f'max_abs_error={identity_err:.3e}'})

        first_node = max(xfirst, cfirst)
        last_node = min(xlast, clast)
        gap = max(0.0, first_node - nominal_ref)
        nominal_supported = bool(gap <= float(fp['reference_support_tolerance_mag']))
        ref_eff = max(nominal_ref, first_node)
        wx_eff, *_ = envelope_width(mag, X, lo, hi, ref_eff, fp)
        wc_eff, *_ = envelope_width(mag, C, lo, hi, ref_eff, fp)
        support_rows.append({
            'cluster_id':cid,'n_final_rgb':len(df),'nominal_reference_f814w':nominal_ref,
            'first_supported_fiducial_node_f814w':first_node,'last_supported_fiducial_node_f814w':last_node,
            'reference_support_gap_mag':gap,'nominal_reference_supported':nominal_supported,
            'effective_reference_f814w':ref_eff,'n_stars_near_nominal_reference_X':int(nxref),
            'n_stars_near_nominal_reference_C':int(ncref),'W_X_nominal_clipped':wx0,'W_C_nominal_clipped':wc0,
            'W_X_effective_reference':wx_eff,'W_C_effective_reference':wc_eff,
        })

        # Reference-location sensitivity: report only whether each requested location is inside actual fiducial-node support.
        for shift in fp['reference_shift_grid_mag']:
            ref = nominal_ref + float(shift)
            supported = bool(first_node - 1e-12 <= ref <= last_node + 1e-12)
            wx, *_ = envelope_width(mag, X, lo, hi, ref, fp)
            wc, *_ = envelope_width(mag, C, lo, hi, ref, fp)
            ref_rows.append({'cluster_id':cid,'reference_shift_mag':float(shift),'reference_f814w':ref,'inside_fiducial_node_support':supported,'W_X':wx,'W_C':wc})

        # Sampling uncertainty at the first genuinely supported reference location.
        bdf = bootstrap_widths(mag, X, C, lo, hi, ref_eff, fp, bp, rng)
        bdir = out / 'clusters' / cid
        bdir.mkdir(parents=True, exist_ok=True)
        bdf.to_csv(bdir / f'{cid}_width_bootstrap.csv.gz', index=False, compression='gzip')
        q = list(map(float, bp['confidence_quantiles']))
        okx = np.isfinite(bdf['W_X'])
        okc = np.isfinite(bdf['W_C'])
        success = float(min(okx.mean(), okc.mean()))
        checks.append({'cluster_id':cid,'check':'Bootstrap width recovery adequate','severity':'ERROR','passed':success>=float(bp['min_success_fraction']),'detail':f'success_fraction={success:.4f}'})
        qx = np.nanquantile(bdf['W_X'], q)
        qc = np.nanquantile(bdf['W_C'], q)
        pubx, pubc = float(bn['published_W_X']), float(bn['published_W_C'])
        pubx_in95 = bool(qx[0] <= pubx <= qx[-1])
        pubc_in95 = bool(qc[0] <= pubc <= qc[-1])
        boot_summary_rows.append({
            'cluster_id':cid,'bootstrap_success_fraction':success,
            'W_X_q025':qx[0],'W_X_q16':qx[1],'W_X_q50':qx[2],'W_X_q84':qx[3],'W_X_q975':qx[4],
            'W_C_q025':qc[0],'W_C_q16':qc[1],'W_C_q50':qc[2],'W_C_q84':qc[3],'W_C_q975':qc[4],
            'published_W_X':pubx,'published_W_C':pubc,'published_W_X_inside_bootstrap95':pubx_in95,'published_W_C_inside_bootstrap95':pubc_in95,
        })

        # Population-blind optical spatial proxy.  It is a sensitivity probe, not a physical reddening map.
        opt_res, ridge_meta = optical_ridge_residual(df, lo, hi, sp)
        x_mid = 0.5 * (pd.to_numeric(df['x_fid_blue'], errors='coerce').to_numpy(float) + pd.to_numeric(df['x_fid_red'], errors='coerce').to_numpy(float))
        c_mid = 0.5 * (pd.to_numeric(df['c_fid_blue'], errors='coerce').to_numpy(float) + pd.to_numeric(df['c_fid_red'], errors='coerce').to_numpy(float))
        x_resid = X - x_mid
        c_resid = C - c_mid
        spatial_changes_x, spatial_changes_c = [], []
        proxy_for_sector = None
        for k in map(int, sp['neighbour_k']):
            proxy = neighbour_proxy(df, opt_res, k)
            finite_frac = float(np.isfinite(proxy).mean())
            if k == int(sp['neighbour_k'][len(sp['neighbour_k'])//2]):
                proxy_for_sector = proxy.copy()
            bx, ax, nx = robust_slope(x_resid, proxy, sp['robust_regression_sigma_clip'], sp['robust_regression_iterations'])
            bc, ac, nc = robust_slope(c_resid, proxy, sp['robust_regression_sigma_clip'], sp['robust_regression_iterations'])
            Xadj = X - (bx * proxy if np.isfinite(bx) else 0.0)
            Cadj = C - (bc * proxy if np.isfinite(bc) else 0.0)
            wxadj, *_ = envelope_width(mag, Xadj, lo, hi, ref_eff, fp)
            wcadj, *_ = envelope_width(mag, Cadj, lo, hi, ref_eff, fp)
            dxfrac = abs(wxadj - wx_eff) / max(abs(wx_eff), 1e-12)
            dcfrac = abs(wcadj - wc_eff) / max(abs(wc_eff), 1e-12)
            spatial_changes_x.append(dxfrac); spatial_changes_c.append(dcfrac)
            rho_x = spearmanr(proxy, x_resid, nan_policy='omit').statistic if np.isfinite(proxy).sum() >= 20 else np.nan
            rho_c = spearmanr(proxy, c_resid, nan_policy='omit').statistic if np.isfinite(proxy).sum() >= 20 else np.nan
            spatial_rows.append({
                'cluster_id':cid,'neighbour_k':k,'optical_ridge_mode':ridge_meta['mode'],'optical_ridge_nodes':ridge_meta['n_nodes'],
                'finite_proxy_fraction':finite_frac,'proxy_p05':float(np.nanquantile(proxy,0.05)) if np.isfinite(proxy).any() else np.nan,
                'proxy_p95':float(np.nanquantile(proxy,0.95)) if np.isfinite(proxy).any() else np.nan,
                'beta_X_per_optical_proxy':bx,'beta_C_per_optical_proxy':bc,'regression_n_X':nx,'regression_n_C':nc,
                'spearman_proxy_X_residual':rho_x,'spearman_proxy_C_residual':rho_c,
                'W_X_adjusted_sensitivity':wxadj,'W_C_adjusted_sensitivity':wcadj,
                'fractional_width_change_X':dxfrac,'fractional_width_change_C':dcfrac,
                'is_science_correction':False,
            })
        min_proxy_frac = min([r['finite_proxy_fraction'] for r in spatial_rows if r['cluster_id']==cid]) if any(r['cluster_id']==cid for r in spatial_rows) else 0.0
        checks.append({'cluster_id':cid,'check':'Spatial proxy coverage adequate','severity':'ERROR','passed':min_proxy_frac>=float(sp['min_finite_proxy_fraction']),'detail':f'min_finite_fraction={min_proxy_frac:.4f}'})

        if proxy_for_sector is not None:
            for row in sector_proxy_audit(df, proxy_for_sector, sa['n_sectors'], sa['min_stars_per_sector']):
                row['cluster_id'] = cid
                sector_rows.append(row)

        max_sp_x = float(max(spatial_changes_x)) if spatial_changes_x else np.nan
        max_sp_c = float(max(spatial_changes_c)) if spatial_changes_c else np.nan
        benchmark_baseline_frac_x = abs(float(fr['W_X_reference']) - pubx) / max(abs(pubx),1e-12)
        benchmark_baseline_frac_c = abs(float(fr['W_C_reference']) - pubc) / max(abs(pubc),1e-12)
        if max(max_sp_x, max_sp_c) >= float(sp['spatial_width_strong_fraction']):
            spatial_status = 'STRONG_SPATIAL_PHOTOMETRY_SENSITIVITY'
        elif max(max_sp_x, max_sp_c) >= float(sp['spatial_width_review_fraction']):
            spatial_status = 'REVIEW_SPATIAL_PHOTOMETRY_SENSITIVITY'
        else:
            spatial_status = 'SPATIAL_WIDTH_STABLE'

        if cid == 'NGC3201':
            if (not nominal_supported) and pubx_in95:
                discrepancy_status = 'REFERENCE_SUPPORT_LIMITED_BENCHMARK_WITHIN_BOOTSTRAP95'
            elif not nominal_supported:
                discrepancy_status = 'REFERENCE_SUPPORT_LIMITED_BENCHMARK_OUTSIDE_BOOTSTRAP95'
            elif pubx_in95:
                discrepancy_status = 'BENCHMARK_WITHIN_BOOTSTRAP95'
            else:
                discrepancy_status = 'WIDTH_DISCREPANCY_PERSISTS'
        else:
            discrepancy_status = 'BENCHMARK_DIAGNOSTIC_ONLY'

        stage1c3_authorized = True
        mandatory_sensitivity = 'BOTH_COORDINATES_PRIMARY'
        if cid == 'NGC3201':
            mandatory_sensitivity = 'BOTH_COORDINATES_PRIMARY_PLUS_C_DOMINANT_AND_X_DOWNWEIGHTED_REPLAY'
        if spatial_status != 'SPATIAL_WIDTH_STABLE':
            mandatory_sensitivity += '+SPATIAL_PROXY_REPLAY'

        decision_rows.append({
            'cluster_id':cid,'stage1c2b_status':'SYSTEMATICS_AUDIT_FROZEN','stage1c3_authorized':stage1c3_authorized,
            'nominal_reference_supported':nominal_supported,'reference_support_gap_mag':gap,
            'spatial_sensitivity_status':spatial_status,'ngc3201_discrepancy_status':discrepancy_status,
            'baseline_fractional_difference_X_vs_published':benchmark_baseline_frac_x,
            'baseline_fractional_difference_C_vs_published':benchmark_baseline_frac_c,
            'published_W_X_inside_bootstrap95':pubx_in95,'published_W_C_inside_bootstrap95':pubc_in95,
            'max_spatial_fractional_width_change_X':max_sp_x,'max_spatial_fractional_width_change_C':max_sp_c,
            'stage1c3_mandatory_sensitivity':mandatory_sensitivity,
            'reason':'Stage1C2 widths replayed; support, bootstrap, and population-blind spatial sensitivity audited without fitting a population classifier',
        })
        print(f"[Stage1C2B] {cid}: ref_supported={nominal_supported} gap={gap:.3f} boot95_X=({qx[0]:.3f},{qx[-1]:.3f}) pub_X={pubx:.3f} spatial_dX={max_sp_x:.3f} spatial_dC={max_sp_c:.3f}")

    # Write outputs.
    pd.DataFrame(support_rows).to_csv(out/'stage1c2b_reference_support_audit.csv', index=False)
    pd.DataFrame(spatial_rows).to_csv(out/'stage1c2b_spatial_proxy_sensitivity.csv', index=False)
    pd.DataFrame(ref_rows).to_csv(out/'stage1c2b_reference_shift_sensitivity.csv', index=False)
    pd.DataFrame(boot_summary_rows).to_csv(out/'stage1c2b_bootstrap_width_summary.csv', index=False)
    pd.DataFrame(sector_rows).to_csv(out/'stage1c2b_sector_proxy_audit.csv', index=False)
    pd.DataFrame(decision_rows).to_csv(out/'stage1c2b_decision_ledger.csv', index=False)

    cdf = pd.DataFrame(checks)
    cdf.to_csv(val/'stage1c2b_preflight.csv', index=False)
    err = cdf[(cdf['severity']=='ERROR') & (~cdf['passed'].astype(bool))]
    n_auth = int(sum(bool(x.get('stage1c3_authorized', False)) for x in decision_rows))
    ready = bool(upstream_ready and len(err)==0 and n_auth==len(protocol['pilot_clusters']))
    retained = list(protocol['retained_blockers'])
    disposition = 'SYSTEMATICS_CLOSED_STAGE1C3_AUTHORIZED' if ready else 'SYSTEMATICS_CLOSURE_NOT_READY'
    meta = {
        'stage':'Stage1C2B','version':str(protocol['version']),'generated_utc':utcnow(),
        'stage1c2_rgb_verticalisation_ready':upstream_ready,'systematics_closure_ready':ready,
        'stage1c3_authorized':ready,'classifier_fit_performed':False,'science_ready':False,
        'n_clusters':len(protocol['pilot_clusters']),'n_clusters_stage1c3_authorized':n_auth,
        'n_checks':len(cdf),'n_error_failures':len(err),'n_retained_blockers':len(retained),
        'retained_blockers':retained,'disposition':disposition,
        'ngc3201_status':next((x.get('ngc3201_discrepancy_status') for x in decision_rows if x.get('cluster_id')=='NGC3201'), None),
    }
    (val/'stage1c2b_preflight.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    lines = [
        '# Stage 1C2B preflight','',f'- Disposition: **{disposition}**',
        f'- Systematics closure ready: **{ready}**',f'- Stage1C3 authorized: **{ready}**',
        f'- Authorized clusters: **{n_auth}/{len(protocol["pilot_clusters"])}**',f'- Error failures: **{len(err)}**',
        f'- Retained blockers: **{len(retained)}**',f'- NGC 3201 audit status: **{meta["ngc3201_status"]}**',''
    ]
    if len(err):
        lines += ['## Failed error checks'] + [f'- {r.cluster_id} — {r.check}: {r.detail}' for _,r in err.iterrows()] + ['']
    lines += ['## Retained blockers'] + [f'- {x}' for x in retained] + ['', '## Claim boundary', protocol['claim_boundary']['allowed_claim'], '']
    (val/'stage1c2b_preflight.md').write_text('\n'.join(lines), encoding='utf-8')

    # Output manifest (after all science/audit outputs have been written).
    manifest = []
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.name != 'stage1c2b_output_manifest.csv':
            manifest.append({'relative_path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha256(p)})
    pd.DataFrame(manifest).to_csv(out/'stage1c2b_output_manifest.csv', index=False)

    print(json.dumps(meta, indent=2))
    if not ready:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
