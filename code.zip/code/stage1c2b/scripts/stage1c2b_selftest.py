from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from stage1c2b_systematics import fit_envelope, envelope_width, neighbour_proxy, robust_slope


def main():
    rng = np.random.default_rng(42)
    n = 500
    mag = rng.uniform(15.0, 16.4, n)
    x = 1.0 + 0.2*(mag-15.7) + rng.normal(0,0.08,n)
    fp = dict(lower_quantile=.05, upper_quantile=.95, bin_width_mag=.28, grid_step_mag=.07,
              min_bin_stars=15, min_fiducial_nodes=8, min_local_width_mag=.025)
    fit = fit_envelope(mag,x,15.0,16.4,fp)
    assert fit is not None
    w, first, last, nn = envelope_width(mag,x,15.0,16.4,15.0,fp)
    assert np.isfinite(w) and w > 0 and first >= 15.0-1e-9 and last <= 16.4+1e-9

    # Explicit sparse-bright-edge regression: nominal reference may precede the first supported node.
    mag2 = rng.uniform(15.25,16.4,150)
    x2 = rng.normal(0,0.15,150)
    w2, first2, *_ = envelope_width(mag2,x2,15.0,16.4,15.0,fp)
    assert np.isfinite(w2) and first2 > 15.0

    # Spatial proxy and robust regression contract.
    df = pd.DataFrame({'ra_deg':150 + rng.normal(0,.01,n), 'dec_deg':-40+rng.normal(0,.01,n)})
    optical = rng.normal(0,.02,n)
    p = neighbour_proxy(df,optical,15)
    assert np.isfinite(p).mean() > .95
    y = 2.5*p + rng.normal(0,.02,n)
    beta, intercept, nkeep = robust_slope(y,p,3.0,4)
    assert np.isfinite(beta) and abs(beta-2.5) < .5 and nkeep > 300
    print('STAGE1C2B_SELFTEST: PASS')

if __name__ == '__main__':
    main()
