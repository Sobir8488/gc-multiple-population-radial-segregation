# Stage 1D1B v0.1.0 — conditional-logit spline protocol freeze

Stage 1D1A established that the identifiable HST-only quantity is the differential local slope

`Delta_gamma(R) = - d logit[p_2P(R)] / d ln R`.

Stage 1D1B freezes the inference machinery **before any Delta_gamma profile is calculated**.

Primary model:
- unique-master likelihood (duplicate catalogue rows cannot be double-counted);
- continuous Stage 1C3 q2P as the fractional Bernoulli target;
- cubic B-spline for `eta=logit(p2P)`;
- second-difference roughness penalty;
- fit on q05-q95 radial support;
- derivative claims only on q10-q90;
- deterministic radial-interleaved 5-fold CV;
- 17-value lambda grid from 1e-4 to 1e4;
- one-standard-error rule toward the smoother model.

Uncertainty and validation are frozen in advance:
- 500 radial-stratified bootstrap replicates with Bernoulli(q2P) latent-label imputation;
- 300 secondary soft-q bootstrap replicates;
- 95% simultaneous bootstrap band;
- 999 q2P-radius permutation null tests with full lambda reselection;
- Benjamini-Hochberg FDR across the six clusters;
- lambda/knot sensitivity;
- leave-one-radial-quintile-out stability.

No science result is generated here.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d1b_prepare_env.bat
call run_stage1d1b_selftest.bat
call run_stage1d1b.bat
```

Expected disposition:

`CONDITIONAL_LOGIT_SPLINE_PROTOCOL_FROZEN_STAGE1D2_AUTHORIZED`
