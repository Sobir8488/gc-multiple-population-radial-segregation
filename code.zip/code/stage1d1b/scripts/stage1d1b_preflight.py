
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d1b_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1b_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_readiness_summary.csv")
    h=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_master_hygiene.csv")
    f=json.loads((root/"outputs/stage1d1b/stage1d1b_protocol_freeze.json").read_text(encoding="utf-8"))
    checks=[]
    def add(name,passed,detail,severity="ERROR"):
        checks.append({"check":name,"passed":bool(passed),"severity":severity,"detail":detail})
    add("six clusters protocol-ready",s.protocol_ready_for_science_fit.all(),
        f"{int(s.protocol_ready_for_science_fit.sum())}/6")
    add("unique-master likelihood frozen",(s.n_unique_masters<=s.n_stage1c3_rows).all(),
        f"duplicate rows removed total={int(s.n_duplicate_rows_removed.sum())}")
    add("duplicate q2P hygiene passes",
        ((h.loc[h.n_rows>1,"q2p_spread"]<=cfg["science_input_hygiene"]["maximum_duplicate_q2p_spread"]).all()
         if (h.n_rows>1).any() else True),
        f"duplicate masters={int((h.n_rows>1).sum())}")
    add("no science fit performed",(s.science_fit_performed==False).all(),"protocol-only stage")
    add("basis matrices full-rank",s.basis_full_rank.all(),f"{int(s.basis_full_rank.sum())}/6")
    nerr=sum((not x["passed"]) and x["severity"]=="ERROR" for x in checks)
    ready=(nerr==0 and s.protocol_ready_for_science_fit.all())
    obj={
      "stage":"Stage1D1B","version":"0.1.0","generated_utc":utcnow(),
      "conditional_logit_spline_protocol_frozen":bool(ready),
      "protocol_sha256":f["protocol_sha256"],
      "n_clusters_protocol_ready":int(s.protocol_ready_for_science_fit.sum()),
      "stage1d2_authorized":bool(ready),
      "delta_gamma_computed":False,
      "science_ready":False,
      "absolute_density_slopes_ready":False,
      "n_checks":len(checks),"n_error_failures":nerr,
      "n_retained_blockers":len(cfg["retained_blockers"]),
      "retained_blockers":cfg["retained_blockers"],
      "disposition":("CONDITIONAL_LOGIT_SPLINE_PROTOCOL_FROZEN_STAGE1D2_AUTHORIZED"
                     if ready else "CONDITIONAL_LOGIT_SPLINE_PROTOCOL_NOT_READY")
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d1b_preflight.csv",index=False)
    write_json(val/"stage1d1b_preflight.json",obj)
    lines=["# Stage 1D1B preflight","",
           f"- Disposition: **{obj['disposition']}**",
           f"- Conditional-logit spline protocol frozen: **{obj['conditional_logit_spline_protocol_frozen']}**",
           f"- Protocol-ready clusters: **{obj['n_clusters_protocol_ready']}/6**",
           f"- Stage 1D2 authorized: **{obj['stage1d2_authorized']}**",
           "- Delta-gamma computed: **False**",
           "- Absolute density slopes ready: **False**",
           f"- Error failures: **{nerr}**","",
           "## Frozen per-cluster design"]
    for _,r in s.iterrows():
        lines.append(
          f"- {r.cluster_id}: unique masters={int(r.n_unique_masters)}, "
          f"fit N={int(r.n_fit_support)}, claim N={int(r.n_claim_support)}, "
          f"Rfit=[{r.r_fit_q05_arcsec:.2f},{r.r_fit_q95_arcsec:.2f}] arcsec, "
          f"Rclaim=[{r.r_claim_q10_arcsec:.2f},{r.r_claim_q90_arcsec:.2f}] arcsec, "
          f"Kint={int(r.n_interior_knots)}, basis={int(r.n_basis_coefficients)}."
        )
    lines += ["","## Frozen inference boundary",
      "No slope has been inspected in this stage. Knots, CV folds, lambda grid, bootstrap design, "
      "permutation test, multiple-testing rule and stability gates are now fixed before Stage 1D2.",
      "",
      "The likelihood is master-level. Any duplicated Stage 1C3 catalogue row is consolidated before science inference "
      "so it cannot receive double statistical weight."]
    (val/"stage1d1b_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
