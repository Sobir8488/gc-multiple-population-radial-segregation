
import numpy as np
from scipy.interpolate import BSpline

degree=3
xlo,xhi=-2.,2.
interior=np.linspace(xlo,xhi,5)[1:-1]
knots=np.r_[np.repeat(xlo,degree+1),interior,np.repeat(xhi,degree+1)]
ncoef=len(knots)-degree-1
eye=np.eye(ncoef)
grid=np.linspace(xlo,xhi,101)
B=np.column_stack([BSpline(knots,eye[j],degree)(grid) for j in range(ncoef)])
assert np.allclose(B.sum(axis=1),1.0,atol=1e-10)

# Analytic identity: a linear eta(x)=a+b*x implies Delta_gamma=-b.
coef=np.linalg.lstsq(B,np.linspace(-1,1,len(grid)),rcond=None)[0]
spl=BSpline(knots,coef,degree)
d=spl.derivative()(grid[5:-5])
assert np.all(np.isfinite(d))

D=np.diff(np.eye(ncoef),n=2,axis=0)
P=D.T@D
assert np.all(np.linalg.eigvalsh(P)>=-1e-10)
assert np.linalg.matrix_rank(P)==ncoef-2
print("STAGE1D1B_SELFTEST: PASS")
