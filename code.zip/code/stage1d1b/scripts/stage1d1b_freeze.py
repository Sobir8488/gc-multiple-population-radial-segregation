
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from stage1d1b_common import sha256_file, utcnow, write_json

def num(x):
    return pd.to_numeric(x,errors="coerce")

def bspline_design(x, knots, degree):
    x=np.asarray(x,float)
    t=np.asarray(knots,float)
    ncoef=len(t)-degree-1
    eye=np.eye(ncoef)
    B=np.column_stack([BSpline(t,eye[j],degree,extrapolate=False)(x) for j in range(ncoef)])
    return B

def second_difference_penalty(ncoef):
    D=np.diff(np.eye(ncoef),n=2,axis=0)
    return D.T@D

def dedup_probability(prob,master,maxspread,require_same_source):
    hygiene=[]; rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        q=num(g.population_probability_2p).to_numpy(float)
        spread=float(np.nanmax(q)-np.nanmin(q))
        nsrc=int(g.source_row_id.astype(str).nunique()) if "source_row_id" in g else 1
        hygiene.append({"master_star_id":mid,"n_rows":len(g),"q2p_spread":spread,"n_source_row_ids":nsrc})
        if spread>maxspread:
            raise RuntimeError(f"master {mid}: duplicate q2P spread {spread} exceeds gate")
        if require_same_source and len(g)>1 and nsrc!=1:
            raise RuntimeError(f"master {mid}: duplicate rows do not share one HUGS source")
        rows.append({"master_star_id":mid,"q2p":float(np.mean(q))})
    d=pd.DataFrame(rows)
    m=master[["master_star_id","x_common_arcsec","y_common_arcsec"]].drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    return d,pd.DataFrame(hygiene)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1b_protocol.yaml").read_text(encoding="utf-8"))
    pre=json.loads((root/cfg["upstream"]["stage1d1a_preflight"]).read_text(encoding="utf-8"))
    if not pre.get("stage1d1b_authorized",False):
        raise SystemExit("Stage1D1A has not authorized Stage1D1B")
    out=root/"outputs/stage1d1b"; out.mkdir(parents=True,exist_ok=True)

    summaries=[]; knotrows=[]; foldrows=[]; hygiene_all=[]; inputs=[]
    degree=int(cfg["model"]["degree"])
    for cid in cfg["clusters"]:
        pp=root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid)
        mp=root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid)
        for role,p in [("stage1c3_probabilities",pp),("stage1b_master",mp)]:
            inputs.append({"cluster_id":cid,"role":role,
                           "path":str(p.relative_to(root)).replace("\\","/"),
                           "bytes":p.stat().st_size,"sha256":sha256_file(p)})
        prob=pd.read_csv(pp,low_memory=False)
        master=pd.read_csv(mp,low_memory=False)
        d,h=dedup_probability(
            prob,master,
            float(cfg["science_input_hygiene"]["maximum_duplicate_q2p_spread"]),
            bool(cfg["science_input_hygiene"]["require_duplicate_source_row_identity"])
        )
        h["cluster_id"]=cid; hygiene_all.append(h)
        r=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec)).to_numpy(float)
        q=num(d.q2p).to_numpy(float)
        if not np.isfinite(r).all() or not np.isfinite(q).all() or np.any(r<=0):
            raise RuntimeError(f"{cid}: invalid radius/q2P after master-level hygiene")
        q05,q10,q90,q95=np.quantile(r,[0.05,0.10,0.90,0.95])
        fit=(r>=q05)&(r<=q95)
        claim=(r>=q10)&(r<=q90)
        Rref=float(np.median(r[fit]))
        x=np.log(r/Rref)
        xlo=float(np.log(q05/Rref)); xhi=float(np.log(q95/Rref))
        xclaim_lo=float(np.log(q10/Rref)); xclaim_hi=float(np.log(q90/Rref))
        nfit=int(fit.sum())
        kint=int(np.clip(round(nfit/250),3,7))
        interior=np.linspace(xlo,xhi,kint+2)[1:-1]
        knots=np.r_[np.repeat(xlo,degree+1),interior,np.repeat(xhi,degree+1)]
        ncoef=len(knots)-degree-1
        B=bspline_design(x[fit],knots,degree)
        P=second_difference_penalty(ncoef)
        rank=int(np.linalg.matrix_rank(B))
        prank=int(np.linalg.matrix_rank(P))
        cond=float(np.linalg.cond(B.T@B + 1e-8*np.eye(ncoef)))
        grid=np.linspace(xclaim_lo,xclaim_hi,int(cfg["model"]["grid_points"]))
        Bg=bspline_design(grid,knots,degree)
        finite_basis=bool(np.isfinite(B).all() and np.isfinite(Bg).all())
        full_rank=rank==ncoef

        # Deterministic radial-interleaved CV folds for the fit-support stars.
        fit_idx=np.where(fit)[0]
        order=fit_idx[np.argsort(x[fit_idx],kind="mergesort")]
        fold=np.full(len(d),-1,int)
        fold[order]=np.arange(len(order))%int(cfg["smoothness_selection"]["folds"])
        for i in fit_idx:
            foldrows.append({"cluster_id":cid,"master_star_id":d.loc[i,"master_star_id"],
                             "radius_arcsec":float(r[i]),"x":float(x[i]),
                             "cv_fold":int(fold[i]),"in_claim_support":bool(claim[i])})

        for j,val in enumerate(knots):
            knotrows.append({"cluster_id":cid,"knot_index":j,"x_knot":float(val),
                             "radius_arcsec_equiv":float(Rref*np.exp(val)),
                             "is_boundary":bool(j<degree+1 or j>=len(knots)-(degree+1))})

        # Radial-stratum counts for the frozen bootstrap design.
        rankall=np.argsort(np.argsort(r[fit_idx],kind="mergesort"),kind="mergesort")
        strata=np.floor(rankall*10/max(1,len(rankall))).astype(int)
        strata=np.clip(strata,0,9)
        min_stratum=int(pd.Series(strata).value_counts().min())
        fold_counts=pd.Series(fold[fit_idx]).value_counts()
        min_fold=int(fold_counts.min())

        ready=(finite_basis and full_rank and min_fold>=20 and min_stratum>=10 and
               xclaim_hi>xclaim_lo and nfit>=100)
        summaries.append({
            "cluster_id":cid,
            "n_stage1c3_rows":len(prob),
            "n_unique_masters":len(d),
            "n_duplicate_rows_removed":len(prob)-len(d),
            "n_fit_support":nfit,
            "n_claim_support":int(claim.sum()),
            "r_fit_q05_arcsec":float(q05),"r_fit_q95_arcsec":float(q95),
            "r_claim_q10_arcsec":float(q10),"r_claim_q90_arcsec":float(q90),
            "R_ref_arcsec":Rref,
            "n_interior_knots":kint,"n_basis_coefficients":ncoef,
            "basis_rank":rank,"penalty_rank":prank,
            "regularized_gram_condition_number":cond,
            "min_cv_fold_count":min_fold,
            "min_bootstrap_radial_stratum_count":min_stratum,
            "basis_finite":finite_basis,"basis_full_rank":full_rank,
            "protocol_ready_for_science_fit":ready,
            "science_fit_performed":False
        })
        print(f"[Stage1D1B] {cid}: rows={len(prob)} masters={len(d)} fit={nfit} "
              f"claim={int(claim.sum())} Kint={kint} ncoef={ncoef} "
              f"minFold={min_fold} ready={ready}")

    pd.DataFrame(summaries).to_csv(out/"stage1d1b_readiness_summary.csv",index=False)
    pd.DataFrame(knotrows).to_csv(out/"stage1d1b_frozen_knots.csv",index=False)
    pd.DataFrame(foldrows).to_csv(out/"stage1d1b_frozen_cv_folds.csv.gz",index=False,compression="gzip")
    pd.concat(hygiene_all,ignore_index=True).to_csv(out/"stage1d1b_master_hygiene.csv",index=False)
    pd.DataFrame(inputs).to_csv(out/"stage1d1b_input_manifest.csv",index=False)

    prot=root/"config/stage1d1b_protocol.yaml"
    write_json(out/"stage1d1b_protocol_freeze.json",{
        "stage":"Stage1D1B","version":"0.1.0","generated_utc":utcnow(),
        "protocol_path":"config/stage1d1b_protocol.yaml",
        "protocol_sha256":sha256_file(prot),
        "science_fit_performed":False,
        "delta_gamma_computed":False,
        "next_stage":"Stage1D2 first conditional Delta-gamma science inference"
    })
    rows=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d1b_output_manifest.csv":
            rows.append({"path":str(p.relative_to(out)).replace("\\","/"),
                         "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(rows).to_csv(out/"stage1d1b_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
