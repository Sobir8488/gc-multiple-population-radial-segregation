@echo off
setlocal
python scripts\stage1d1b_selftest.py || exit /b 1
python scripts\stage1d1b_freeze.py --root . || exit /b 1
python scripts\stage1d1b_preflight.py --root . || exit /b 1
echo STAGE1D1B: PASS
endlocal
