@echo off
python scripts\stage1d1b_selftest.py
