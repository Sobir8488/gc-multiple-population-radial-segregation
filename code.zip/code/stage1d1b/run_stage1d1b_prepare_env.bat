@echo off
python -c "import numpy,pandas,scipy,yaml; print('Stage1D1B environment: OK')"
