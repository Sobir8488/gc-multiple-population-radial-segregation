
import numpy as np

# A within-stratum quality trim preserves representation in every radial stratum.
n=1000
r=np.linspace(0,1,n)
order=np.argsort(r)
strata=np.empty(n,int)
strata[order]=np.clip(np.floor(np.arange(n)*10/n).astype(int),0,9)
assert len(np.unique(strata))==10

# Terminal family is fixed at 4 clusters.
assert 2+1+1==4
print("STAGE1D3C_SELFTEST: PASS")
