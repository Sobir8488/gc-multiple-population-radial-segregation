
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit
from stage1d3c_common import sha256_file, utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def robust_z(x):
    x=np.asarray(x,float)
    med=float(np.nanmedian(x)); q25,q75=np.nanquantile(x,[.25,.75])
    sc=float((q75-q25)/1.349)
    if not np.isfinite(sc) or sc<=1e-10: sc=float(np.nanstd(x))
    if not np.isfinite(sc) or sc<=1e-10: sc=1.0
    return (x-med)/sc

def basis(x,knots,degree,deriv=0):
    n=len(knots)-degree-1; eye=np.eye(n); cols=[]
    for j in range(n):
        s=BSpline(knots,eye[j],degree,extrapolate=False)
        if deriv: s=s.derivative(deriv)
        cols.append(s(np.asarray(x,float)))
    return np.column_stack(cols)

def penalty(n):
    D=np.diff(np.eye(n),n=2,axis=0)
    return D.T@D

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P); N=V[:,w<tol]
    if N.shape[1]!=2: raise RuntimeError(f"nullspace dim={N.shape[1]}")
    return N

def fit_offset(X,y,offset):
    X=np.asarray(X,float); y=np.asarray(y,float); offset=np.asarray(offset,float)
    b=np.zeros(X.shape[1],float)
    for _ in range(80):
        eta=offset+X@b; p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta))
        g=X.T@(p-y); H=X.T@(w[:,None]*X)+1e-9*np.eye(X.shape[1])
        step=np.linalg.solve(H,g); a=1.0
        for _ in range(25):
            c=b-a*step; e=offset+X@c
            co=float(np.sum(np.logaddexp(0,e)-y*e))
            if co<=obj+1e-12: b=c; break
            a*=0.5
        if np.max(np.abs(a*step))<1e-9: break
    return b

def fit_unpen(B,y): return fit_offset(B,y,np.zeros(len(y)))

def ll(X,y,offset,b):
    e=offset+X@b
    return float(np.sum(y*e-np.logaddexp(0,e)))

def radial_strata(r,n):
    r=np.asarray(r,float); order=np.argsort(r,kind="mergesort")
    s=np.empty(len(r),int)
    s[order]=np.clip(np.floor(np.arange(len(r))*n/len(r)).astype(int),0,n-1)
    return s

def angular_X(theta,lnR):
    z=robust_z(lnR)
    return np.column_stack([
      np.cos(theta),np.sin(theta),np.cos(2*theta),np.sin(2*theta),
      z*np.cos(theta),z*np.sin(theta),z*np.cos(2*theta),z*np.sin(2*theta)
    ])

def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p)
    r=p[o]*n/np.arange(1,n+1)
    r=np.minimum.accumulate(r[::-1])[::-1]
    q=np.empty(n,float); q[o]=np.clip(r,0,1)
    return q

def load_master_quality(root,cid,cfg):
    prob=pd.read_csv(root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
    master=pd.read_csv(root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
    rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        rows.append({"master_star_id":mid,"q2p":float(np.mean(num(g.population_probability_2p)))})
    d=pd.DataFrame(rows)
    need=["master_star_id","x_common_arcsec","y_common_arcsec","hugs_source_index","hugs_source_row_id"]
    d=d.merge(master[need].drop_duplicates("master_star_id"),
              on="master_star_id",how="left",validate="one_to_one")
    h=pd.read_csv(root/cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid),low_memory=False)
    s=pd.read_csv(root/cfg["upstream"]["hugs_source_pattern"].format(cluster=cid),low_memory=False)
    idx=num(d.hugs_source_index).astype(int).to_numpy()
    hh=h.iloc[idx].reset_index(drop=True); ss=s.iloc[idx].reset_index(drop=True)
    if not np.array_equal(hh.source_row_id.astype(str).to_numpy(),
                          d.hugs_source_row_id.astype(str).to_numpy()):
        raise RuntimeError(f"{cid}: HUGS indexed provenance mismatch")
    fs=["F275W","F336W","F438W","F606W","F814W"]
    rms=np.column_stack([num(ss[f"RMS_{f}"]).to_numpy(float) for f in fs])
    qfit=np.column_stack([num(ss[f"QFIT_{f}"]).to_numpy(float) for f in fs])
    radxs=np.column_stack([num(ss[f"RADXS_{f}"]).to_numpy(float) for f in fs])
    nf=np.column_stack([num(ss[f"Nf_{f}"]).to_numpy(float) for f in fs])
    ng=np.column_stack([num(ss[f"Ng_{f}"]).to_numpy(float) for f in fs])
    ratio=np.divide(ng,nf,out=np.zeros_like(ng,float),where=nf>0)
    qmat=np.column_stack([
      robust_z(np.log(np.clip(np.max(rms,axis=1),1e-8,None))),
      robust_z(-np.min(qfit,axis=1)),
      robust_z(np.max(np.abs(radxs),axis=1)),
      robust_z(-np.min(ratio,axis=1)),
      robust_z(num(ss["ITER"]).to_numpy(float))
    ])
    d["quality_burden"]=np.mean(qmat,axis=1)
    d["radius_arcsec"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    d["theta"]=np.arctan2(num(d.y_common_arcsec),num(d.x_common_arcsec))
    return d

def design(root,cid,d,cfg):
    ready=pd.read_csv(root/cfg["upstream"]["stage1d1b_readiness"])
    s=ready.loc[ready.cluster_id==cid].iloc[0]
    kd=pd.read_csv(root/cfg["upstream"]["stage1d1b_knots"])
    knots=kd.loc[kd.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
    R=d.radius_arcsec.to_numpy(float); Rref=float(s.R_ref_arcsec); x=np.log(R/Rref)
    degree=3
    Bfull=basis(x,knots,degree,0); N=nullspace(penalty(Bfull.shape[1]))
    gx=np.linspace(np.log(float(s.r_claim_q10_arcsec)/Rref),
                   np.log(float(s.r_claim_q90_arcsec)/Rref),201)
    Bg=basis(gx,knots,degree,0)@N
    Dg=basis(gx,knots,degree,1)@N
    fit=(R>=float(s.r_fit_q05_arcsec))&(R<=float(s.r_fit_q95_arcsec))
    claim=(R>=float(s.r_claim_q10_arcsec))&(R<=float(s.r_claim_q90_arcsec))
    return s,Rref,x,Bfull,N,gx,Bg,Dg,fit,claim

def balanced_keep(d,fit,fraction,nstrata=10):
    R=d.radius_arcsec.to_numpy(float); burden=d.quality_burden.to_numpy(float)
    idx=np.where(fit)[0]; st=radial_strata(R[idx],nstrata)
    keep=np.zeros(len(d),bool)
    for k in range(nstrata):
        ii=idx[st==k]
        if len(ii)==0: continue
        n=max(1,int(np.floor(float(fraction)*len(ii))))
        chosen=ii[np.argsort(burden[ii],kind="mergesort")[:n]]
        keep[chosen]=True
    return keep

def radial_refit(d,keep,Bfull,N,Bg,Dg,fit):
    q=d.q2p.to_numpy(float)
    m=fit&keep
    th=fit_unpen((Bfull@N)[m],q[m])
    eta=Bg@th; dg=-(Dg@th)
    return float(np.mean(dg)),eta,dg

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3c_protocol.yaml").read_text(encoding="utf-8"))
    inp=json.loads((root/"validation/stage1d3c_input_preflight.json").read_text(encoding="utf-8"))
    if not inp.get("input_ready",False): raise SystemExit("Stage1D3C input not ready")
    s2=pd.read_csv(root/cfg["upstream"]["stage1d2_summary"])
    s3=pd.read_csv(root/cfg["upstream"]["stage1d3_summary"])
    s3b=pd.read_csv(root/cfg["upstream"]["stage1d3b_summary"])
    audited=cfg["unresolved_targets"]+cfg["persistent_2d_comparator"]+cfg["clean_control"]
    out=root/"outputs/stage1d3c"; out.mkdir(parents=True,exist_ok=True)
    summaries=[]; trimrows=[]

    # Helper defined here so the normalized radial grid has Rref available.
    def cluster_aggregate_test(d,keeps,etas,gx,Rref,claim,nperm,seed):
        q=d.q2p.to_numpy(float); R=d.radius_arcsec.to_numpy(float); theta=d.theta.to_numpy(float)
        parent=np.where(claim)[0]
        parent_strata=radial_strata(R[parent],10)
        per=[]
        for keep,eta_grid in zip(keeps,etas):
            m=claim&keep
            off=np.interp(np.log(R[m]/Rref),gx,eta_grid)
            A=angular_X(theta[m],np.log(R[m]))
            b=fit_offset(A,q[m],off)
            ll0=float(np.sum(q[m]*off-np.logaddexp(0,off)))
            stat=2*(ll(A,q[m],off,b)-ll0)
            per.append((m,off,stat))
        obs=float(np.median([z[2] for z in per]))
        rng=np.random.default_rng(seed); vals=np.empty(nperm,float)
        for j in range(nperm):
            tp=theta.copy()
            for k in np.unique(parent_strata):
                ii=parent[parent_strata==k]
                tp[ii]=theta[rng.permutation(ii)]
            stats=[]
            for (m,off,_) in per:
                A=angular_X(tp[m],np.log(R[m]))
                b=fit_offset(A,q[m],off)
                ll0=float(np.sum(q[m]*off-np.logaddexp(0,off)))
                stats.append(2*(ll(A,q[m],off,b)-ll0))
            vals[j]=float(np.median(stats))
        p=float((1+np.sum(vals>=obs))/(1+nperm))
        return obs,p,vals,[float(z[2]) for z in per]

    for ic,cid in enumerate(audited):
        d=load_master_quality(root,cid,cfg)
        s,Rref,x,Bfull,N,gx,Bg,Dg,fit,claim=design(root,cid,d,cfg)
        upstream=s2.loc[s2.cluster_id==cid].iloc[0]
        boot=np.load(root/cfg["upstream"]["stage1d2_bootstrap_primary_pattern"].format(cluster=cid))
        Dsd=float(np.std(np.mean(boot,axis=1),ddof=1))
        keeps=[]; etas=[]; Ds=[]
        for frac in cfg["radially_balanced_quality_trim"]["fractions_retained"]:
            keep=balanced_keep(d,fit,float(frac),int(cfg["radially_balanced_quality_trim"]["radial_strata"]))
            Dt,eta,dg=radial_refit(d,keep,Bfull,N,Bg,Dg,fit)
            keeps.append(keep); etas.append(eta); Ds.append(Dt)
            shift=abs(Dt-float(upstream.D_diff))
            trimrows.append({
              "cluster_id":cid,"fraction_retained":float(frac),
              "n_fit_retained":int((fit&keep).sum()),
              "n_claim_retained":int((claim&keep).sum()),
              "D_diff":Dt,"D_shift":float(Dt-float(upstream.D_diff)),
              "D_shift_bootstrap_sd_units":float(shift/Dsd),
              "sign_preserved":bool(np.sign(Dt)==np.sign(float(upstream.D_diff)))
            })
        gate=cfg["radially_balanced_quality_trim"]["stability_gate"]
        radialstable=all(
            np.sign(Dt)==np.sign(float(upstream.D_diff)) and
            abs(Dt-float(upstream.D_diff))<=float(gate["maximum_abs_D_shift_each_fraction_in_primary_bootstrap_sd_units"])*Dsd
            for Dt in Ds
        )
        stat,pval,perms,perstats=cluster_aggregate_test(
            d,keeps,etas,gx,Rref,claim,
            int(cfg["aggregate_angular_replication"]["permutations"]),
            int(cfg["aggregate_angular_replication"]["random_seed"])+10000*ic
        )
        cdir=out/"clusters"/cid; cdir.mkdir(parents=True,exist_ok=True)
        np.save(cdir/f"{cid}_aggregate_angular_permutation.npy",perms)
        summaries.append({
          "cluster_id":cid,
          "upstream_stage1d3b_status":s3b.loc[s3b.cluster_id==cid,"stage1d3b_status"].iloc[0],
          "D_diff_primary":float(upstream.D_diff),
          "bootstrap_D_sd":Dsd,
          "balanced_quality_radial_stable":bool(radialstable),
          "D_diff_balanced90":Ds[0],"D_diff_balanced80":Ds[1],"D_diff_balanced70":Ds[2],
          "aggregate_angular_statistic":stat,"aggregate_angular_p":pval,
          "angular_stat_90":perstats[0],"angular_stat_80":perstats[1],"angular_stat_70":perstats[2],
          "stage1d3_sector_jackknife_pass":bool(s3.loc[s3.cluster_id==cid,"sector_jackknife_pass"].iloc[0]),
          "stage1d3b_max_single_shell_fraction":float(
              s3b.loc[s3b.cluster_id==cid,"max_single_shell_abs_gain_fraction"].iloc[0])
        })
        print(f"[Stage1D3C] {cid}: balancedRadial={radialstable} aggregateAz_p={pval:.4g} "
              f"D90/80/70={Ds[0]:.4f}/{Ds[1]:.4f}/{Ds[2]:.4f}")

    df=pd.DataFrame(summaries)
    df["aggregate_angular_bh_q"]=bh(df.aggregate_angular_p)
    statuses=[]
    for _,r in df.iterrows():
        sig=bool(r.aggregate_angular_bh_q<0.05)
        persistent=(sig and bool(r.stage1d3_sector_jackknife_pass) and
                    float(r.stage1d3b_max_single_shell_fraction)<=0.80)
        if r.cluster_id=="NGC5272":
            st=("CLEAN_CONTROL_REMAINS_CLEAN"
                if bool(r.balanced_quality_radial_stable) and not sig
                else "CLEAN_CONTROL_FAILURE")
        elif r.cluster_id=="NGC6205":
            st=("RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY"
                if bool(r.balanced_quality_radial_stable) and persistent
                else "COMPARATOR_RESULT_CHANGED_UNDER_TERMINAL_AUDIT")
        else:
            if not bool(r.balanced_quality_radial_stable):
                st="EXCLUDED_FROM_PRIMARY_RADIAL_CLAIM_QUALITY_SENSITIVE"
            elif persistent:
                st="RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY"
            elif not sig:
                st="RADIAL_AVERAGE_ROBUST_SPATIAL_FLAG_NOT_REPLICATED_UNDER_BALANCED_QUALITY"
            else:
                st="EXCLUDED_FROM_PRIMARY_RADIAL_CLAIM_SPATIAL_AMBIGUITY"
        statuses.append(st)
    df["stage1d3c_status"]=statuses
    df.to_csv(out/"stage1d3c_cluster_summary.csv",index=False)
    pd.DataFrame(trimrows).to_csv(out/"stage1d3c_balanced_quality_trim.csv",index=False)

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d3c_output_manifest.csv":
            manifest.append({"path":str(p.relative_to(out)).replace("\\","/"),
                             "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1d3c_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
