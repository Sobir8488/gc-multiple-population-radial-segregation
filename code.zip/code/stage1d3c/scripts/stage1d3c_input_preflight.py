
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3c_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3c_protocol.yaml").read_text(encoding="utf-8"))
    p=json.loads((root/cfg["upstream"]["stage1d3b_preflight"]).read_text(encoding="utf-8"))
    s=pd.read_csv(root/cfg["upstream"]["stage1d3b_summary"])
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("Stage1D3B unresolved closure is authoritative",
        p.get("disposition")=="STAGE1D3B_CLOSURE_COMPLETE_UNRESOLVED_FLAGS_REMAIN",
        p.get("disposition",""))
    got=dict(zip(s.cluster_id,s.stage1d3b_status))
    expected=cfg["expected_stage1d3b_status"]
    add("four frozen Stage1D3B statuses match",
        all(got.get(k)==v for k,v in expected.items()),
        str({k:got.get(k) for k in expected}))
    missing=[]
    for cid in cfg["unresolved_targets"]+cfg["persistent_2d_comparator"]+cfg["clean_control"]:
        for key in ["stage1d2_bootstrap_primary_pattern","stage1c3_probability_pattern",
                    "stage1b_master_pattern","hugs_normalized_pattern","hugs_source_pattern"]:
            rel=cfg["upstream"][key].format(cluster=cid)
            if not (root/rel).exists(): missing.append(rel)
    add("all terminal-closure inputs present",not missing,";".join(missing) if missing else "all present")
    nerr=sum(not x["passed"] for x in checks)
    obj={"stage":"Stage1D3C","version":"0.1.0","generated_utc":utcnow(),
         "input_ready":nerr==0,"terminal_adjudication_performed":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "disposition":"STAGE1D3C_INPUT_READY" if nerr==0 else "STAGE1D3C_INPUT_NOT_READY"}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3c_input_preflight.csv",index=False)
    write_json(val/"stage1d3c_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__": main()
