
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3c_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3c_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d3c/stage1d3c_cluster_summary.csv")
    expected=set(cfg["unresolved_targets"]+cfg["persistent_2d_comparator"]+cfg["clean_control"])
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("four terminal-audit clusters present",set(s.cluster_id)==expected,f"{len(s)}/4")
    add("aggregate angular q-values finite",s.aggregate_angular_bh_q.notna().all(),"finite")
    control=s.loc[s.cluster_id=="NGC5272","stage1d3c_status"].iloc[0]
    add("clean control remains clean",control=="CLEAN_CONTROL_REMAINS_CLEAN",control)
    nerr=sum(not x["passed"] for x in checks)

    target=s.loc[s.cluster_id.isin(cfg["unresolved_targets"])]
    eligible=int(target.stage1d3c_status.isin([
        "RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY",
        "RADIAL_AVERAGE_ROBUST_SPATIAL_FLAG_NOT_REPLICATED_UNDER_BALANCED_QUALITY"
    ]).sum())
    excluded=int(target.stage1d3c_status.str.startswith("EXCLUDED_FROM_PRIMARY_RADIAL_CLAIM").sum())
    comparator_ok=bool(
        s.loc[s.cluster_id=="NGC6205","stage1d3c_status"].iloc[0] in [
            "RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY",
            "COMPARATOR_RESULT_CHANGED_UNDER_TERMINAL_AUDIT"
        ])
    # Terminal rule: conservative exclusion is an acceptable completed claim boundary.
    synthesis=bool(nerr==0)
    obj={
      "stage":"Stage1D3C","version":"0.1.0","generated_utc":utcnow(),
      "terminal_adjudication_complete":nerr==0,
      "n_unresolved_targets_radial_average_retained":eligible,
      "n_unresolved_targets_excluded_from_primary_radial_claim":excluded,
      "clean_control_remains_clean":control=="CLEAN_CONTROL_REMAINS_CLEAN",
      "absolute_density_slopes_ready":False,
      "science_ready_for_claim_safe_synthesis":synthesis,
      "next_required_stage":(
          "Stage1D4 claim-safe science synthesis and manuscript integration"
          if synthesis else "Stage1D3C technical repair"
      ),
      "n_checks":len(checks),"n_error_failures":nerr,
      "disposition":(
          "STAGE1D3C_TERMINAL_ADJUDICATION_COMPLETE_CLAIM_SYNTHESIS_AUTHORIZED"
          if synthesis else "STAGE1D3C_TERMINAL_ADJUDICATION_NOT_READY"
      )
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3c_preflight.csv",index=False)
    write_json(val/"stage1d3c_preflight.json",obj)
    lines=["# Stage 1D3C terminal unresolved-cluster adjudication","",
           f"- Terminal adjudication complete: **{obj['terminal_adjudication_complete']}**",
           f"- Unresolved targets retained as radial-average claims: **{eligible}/2**",
           f"- Unresolved targets conservatively excluded: **{excluded}/2**",
           f"- Clean control remains clean: **{obj['clean_control_remains_clean']}**",
           f"- Claim-safe synthesis authorized: **{synthesis}**",
           "- Absolute density slopes ready: **False**","","## Cluster adjudication"]
    for _,r in s.iterrows():
        lines.append(
          f"- {r.cluster_id}: `{r.stage1d3c_status}`; balanced-radial={bool(r.balanced_quality_radial_stable)}, "
          f"aggregate az p={r.aggregate_angular_p:.4g}, qBH={r.aggregate_angular_bh_q:.4g}; "
          f"D90/80/70={r.D_diff_balanced90:.4f}/{r.D_diff_balanced80:.4f}/{r.D_diff_balanced70:.4f}."
        )
    lines += ["","## Terminal rule",
      "No additional rescue stage is opened for NGC 2808 or NGC 5024. "
      "A conservative exclusion is treated as a completed claim boundary, allowing the paper to proceed without post-hoc tuning.",
      "",f"Next: **{obj['next_required_stage']}**"]
    (val/"stage1d3c_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
