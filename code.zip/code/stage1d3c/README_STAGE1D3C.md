# Stage 1D3C v0.1.0 — terminal unresolved-cluster adjudication

Stage 1D3B left two unresolved robust-radial clusters:
- NGC 2808: quality-sensitive radial closure;
- NGC 5024: spatial-structure ambiguity.

NGC 6205 is used as a persistent-nonaxisymmetry comparator and NGC 5272 as the clean control.

This is a **terminal** closure. It does not relax any Stage 1D2/1D3/1D3B gate and it does not open another rescue stage if a target remains ambiguous.

Two tests are fixed:

1. **Radially balanced quality trims.**  
   At 90%, 80%, and 70% retained fractions, quality selection is performed separately inside 10 radial strata.
   This directly tests whether the Stage 1D3B global quality-trim failure was caused by changing radial composition.
   The same exact penalty-nullspace radial family is refitted. Every D_diff must retain its Stage 1D2 sign and stay
   within 1.5 primary-bootstrap SD.

2. **Aggregate angular replication.**  
   The three balanced-quality subsets each receive the same m=1/m=2 angular test on top of their own refit radial baseline.
   The cluster statistic is the median of the three angular likelihood-ratio statistics. A single 999-permutation null
   shuffles theta within radial strata in the parent claim sample and is propagated consistently to all nested subsets.
   BH-FDR is applied across NGC 2808, NGC 5024, NGC 6205 and NGC 5272.

Possible terminal outcomes include:
- `RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY`;
- `RADIAL_AVERAGE_ROBUST_SPATIAL_FLAG_NOT_REPLICATED_UNDER_BALANCED_QUALITY`;
- `EXCLUDED_FROM_PRIMARY_RADIAL_CLAIM_QUALITY_SENSITIVE`;
- `EXCLUDED_FROM_PRIMARY_RADIAL_CLAIM_SPATIAL_AMBIGUITY`.

A conservative exclusion is a successful terminal claim boundary. It does not block manuscript synthesis.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d3c_prepare_env.bat
call run_stage1d3c_selftest.bat
call run_stage1d3c_input_preflight.bat
call run_stage1d3c.bat
```
