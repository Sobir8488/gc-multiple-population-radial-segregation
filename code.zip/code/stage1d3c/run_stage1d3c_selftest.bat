@echo off
python scripts\stage1d3c_selftest.py
