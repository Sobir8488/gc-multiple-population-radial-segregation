@echo off
python scripts\stage1d3c_input_preflight.py --root .
