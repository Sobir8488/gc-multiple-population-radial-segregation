@echo off
setlocal
python scripts\stage1d3c_selftest.py || exit /b 1
python scripts\stage1d3c_input_preflight.py --root . || exit /b 1
python scripts\stage1d3c_audit.py --root . || exit /b 1
python scripts\stage1d3c_finalize.py --root . || exit /b 1
echo STAGE1D3C: PASS
endlocal
