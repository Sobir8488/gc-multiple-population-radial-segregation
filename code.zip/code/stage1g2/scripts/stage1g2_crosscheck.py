
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from stage1g2_common import utcnow, write_json

SHORT={
 "PRIMARY_CLEAN_RADIAL_DIFFERENTIAL_STRUCTURE":"clean radial",
 "PRIMARY_RADIAL_AVERAGE_WITH_PERSISTENT_NONAXISYMMETRY":"radial avg + persistent 2D",
 "SECONDARY_EXCLUDED_QUALITY_SENSITIVE":"quality-sensitive exclusion",
 "NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE":"null-compatible"
}

def directional_status(r):
    cls=str(r.final_science_class)
    if cls=="NULL_NO_RESOLVED_DIFFERENTIAL_STRUCTURE":
        return "NO_DIRECTIONAL_CLAIM"
    if cls=="SECONDARY_EXCLUDED_QUALITY_SENSITIVE":
        return "PRIMARY_DIRECTIONAL_CLAIM_WITHHELD"
    # Positive D versus negative A means same P2-central direction.
    s4=np.sign(float(r.D_diff))*np.sign(-float(r.Aplus_4))
    st=np.sign(float(r.D_diff))*np.sign(-float(r.Aplus_total))
    if s4>0 and st>0: return "DIRECTIONALLY_CONCORDANT_INNER_AND_TOTAL"
    if s4>0 or st>0: return "PARTIAL_DIRECTIONAL_CONCORDANCE"
    return "DIRECTIONALLY_DISCORDANT"

def n3201_power(power):
    q=power.loc[
      (power.cluster_id=="NGC3201")&
      (power.branch=="EMPIRICAL_SOFT")&
      (power.scenario=="SIGNCHANGE_G090")
    ]
    if len(q)!=1:
        return "STAGE1G_POWER_RECORD_MISSING",np.nan,np.nan
    r=q.iloc[0]
    shape=float(r.shape_recovery_fraction)
    interior=float(r.finite_interior_selection_fraction)
    if shape>=0.70 and interior>=0.70:
        status="STRONG_SIGNCHANGE_RECOVERABLE_AT_NGC3201_SAMPLING"
    elif shape>=0.40:
        status="INTERMEDIATE_SIGNCHANGE_POWER_AT_NGC3201_SAMPLING"
    else:
        status="SIGNCHANGE_POWER_LIMITED_AT_NGC3201_SAMPLING"
    return status,interior,shape

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1g2_protocol.yaml").read_text(encoding="utf-8"))
    g=json.loads((root/cfg["upstream"]["stage1g_preflight"]).read_text(encoding="utf-8"))
    if g.get("disposition")!="SYNTHETIC_CURVATURE_CALIBRATION_COMPLETE_STAGE1G2_AUTHORIZED":
        raise SystemExit("Stage1G has not authorized Stage1G2")
    ours=pd.read_csv(root/cfg["upstream"]["stage1d4_classification"])
    lit=pd.read_csv(root/cfg["source"]["values_file"])
    power=pd.read_csv(root/cfg["upstream"]["stage1g_power_summary"])
    m=ours.merge(lit,on="cluster_id",how="inner",validate="one_to_one")
    if len(m)!=6: raise RuntimeError("Expected exactly six literature matches")

    m["terminal_class_short"]=m.final_science_class.map(SHORT)
    m["directional_crosscheck"]=m.apply(directional_status,axis=1)
    m["minus_Aplus_4"]=-m.Aplus_4
    m["minus_Aplus_total"]=-m.Aplus_total
    nstatus,nint,nshape=n3201_power(power)
    m["curvature_context"]=""
    m.loc[m.cluster_id=="NGC3201","curvature_context"]=(
        f"{nstatus}; strong sign-change interior-selection={nint:.3f}; shape-recovery={nshape:.3f}"
    )
    m.loc[m.cluster_id=="NGC5024","curvature_context"]=(
        "Leitinger: strong inner-versus-full radial-coverage contrast; not classified here as a U-shaped case."
    )
    out=root/"outputs/stage1g2"; out.mkdir(parents=True,exist_ok=True)
    keep=[
      "cluster_id","D_diff","S_diff","permutation_p_value","bh_q_value",
      "terminal_class_short","Aplus_4","Aplus_4_err","Aplus_total","Aplus_total_err",
      "P2frac_4","P2frac_4_err","P2frac_total","P2frac_total_err","rmax_HLR",
      "published_morphology","directional_crosscheck","curvature_context"
    ]
    m[keep].to_csv(out/"stage1g2_leitinger_crosscheck.csv",index=False)

    # LaTeX table.
    rows=[]
    for _,r in m[keep].iterrows():
        rows.append(
          f"{r.cluster_id} & {float(r.D_diff):.3f} & "
          f"${float(r.Aplus_4):+.2f}\\pm{float(r.Aplus_4_err):.2f}$ & "
          f"${float(r.Aplus_total):+.2f}\\pm{float(r.Aplus_total_err):.2f}$ & "
          f"{r.terminal_class_short} \\\\"
        )
    tex=r"""\begin{table*}
\centering
\caption{Quantitative cross-check against Leitinger et al. (2023). Their $A^+<0$ convention denotes a more centrally concentrated enriched/P2 population, whereas our $D_{\rm diff}>0$ denotes an outward-decreasing P2-like fraction. The statistics are not numerically equivalent estimands.}
\label{tab:leitinger_crosscheck}
\begin{tabular}{lrrrl}
\toprule
Cluster & $D_{\rm diff}$ & $A^+_4$ & $A^+_{\rm total}$ & Terminal class \\
\midrule
"""+"\n".join(rows)+r"""
\bottomrule
\end{tabular}
\end{table*}
"""
    tdir=root/"tables"; tdir.mkdir(exist_ok=True)
    (tdir/"stage1g2_leitinger_crosscheck.tex").write_text(tex,encoding="utf-8")

    # Manuscript fragment, driven by actual Stage1G result for NGC3201.
    if nstatus=="STRONG_SIGNCHANGE_RECOVERABLE_AT_NGC3201_SAMPLING":
        n3201_text=(
          "The Stage~1G positive-control calibration shows that a strong sign-changing injected profile is "
          f"recoverable at the actual NGC~3201 sampling (finite-interior selection fraction {nint:.2f}; "
          f"shape-recovery fraction {nshape:.2f}). Therefore the observed nullspace solution is not imposed "
          "mechanically by the selector; rather, the frozen NGC~3201 data do not justify the published wide-field "
          "U-shaped curvature within the HST support."
        )
    elif nstatus=="INTERMEDIATE_SIGNCHANGE_POWER_AT_NGC3201_SAMPLING":
        n3201_text=(
          "The Stage~1G calibration gives only intermediate power for a strong sign-changing profile at the actual "
          f"NGC~3201 sampling (finite-interior {nint:.2f}; shape recovery {nshape:.2f}). We therefore interpret the "
          "HST nullspace result as a low-order constraint and do not claim that the method decisively excludes the "
          "wide-field U-shaped structure."
        )
    else:
        n3201_text=(
          "The Stage~1G calibration is power-limited for a strong sign-changing profile at the actual NGC~3201 "
          f"sampling (finite-interior {nint:.2f}; shape recovery {nshape:.2f}). The HST nullspace result should "
          "therefore be read as a low-order radial constraint rather than as evidence against the wide-field "
          "U-shaped population-fraction structure."
        )

    fragment=f"""
% Stage 1G2 quantitative literature cross-check

\\subsection{{Quantitative comparison with Leitinger et al. (2023)}}

Leitinger et al. (2023) provide a homogeneous wide-field comparison for all six clusters in our validation sample.
Their cumulative statistic uses the convention $A^+<0$ for a centrally concentrated enriched/P2 population and
$A^+>0$ for a centrally concentrated primordial/P1 population. Our convention is different:
$D_{{\\rm diff}}>0$ means that the P2-like fraction decreases outward on average. Thus directional agreement
corresponds to the same sign between $D_{{\\rm diff}}$ and $-A^+$, but the two quantities are not numerically
interchangeable because one is a local log-odds derivative and the other is an integrated cumulative statistic.

For NGC~5272, our clean positive result is directionally consistent with both the Leitinger inner
($A^+_4=-0.36\\pm0.05$) and full-range ($A^+_{{\\rm total}}=-0.17\\pm0.10$) measurements. The weakening of
$|A^+|$ when the radial range is expanded reinforces the distinction between a central HST derivative and a global
cumulative concentration measure.

NGC~5024 also shows the same P2-central direction in the Leitinger measurements
($A^+_4=-0.42\\pm0.05$, $A^+_{{\\rm total}}=-0.84\\pm0.11$), but the published analysis emphasizes that the inner
HST-only view differs substantially from the full radial extent. We therefore use NGC~5024 as an inner-versus-global
coverage example rather than labelling it as a published U-shaped case. Our terminal result adds a separate constraint:
the HST-footprint radial average is robust, but residual non-axisymmetry persists.

For NGC~6205, Leitinger et al. find nearly zero cumulative concentration
($A^+_4=-0.04\\pm0.04$, $A^+_{{\\rm total}}=-0.02\\pm0.07$) and classify the populations as spatially mixed over
their wide radial coverage. Our positive HST-footprint $D_{{\\rm diff}}$ therefore should not be presented as a
global contradiction. It is a local radial average in a field that our own two-dimensional audit shows to be
non-axisymmetric.

NGC~3201 is the clearest example of why an integrated $A^+$ value can hide non-monotonic structure. Leitinger et al.
report $A^+_4=A^+_{{\\rm total}}=+0.46\\pm0.12$, while their radial P2 fraction is U-shaped: P2 is relatively high
towards the centre and outer field, with P1 most prominent at intermediate radius. {n3201_text}

NGC~2808 is externally consistent with complex radial structure: Leitinger et al. obtain
$A^+_4=-0.08\\pm0.03$ and $A^+_{{\\rm total}}=-0.49\\pm0.08$, with a much stronger P2-central signal once the outer
field is included. This external plausibility does not override our terminal quality-sensitive exclusion.
NGC~5904 is classified as spatially mixed in their discussion; our result is likewise null-compatible under the
frozen local derivative gates.

The quantitative cross-check therefore strengthens, rather than replaces, the paper's claim boundary: local
conditional derivatives, integrated cumulative concentration, wide-field morphology and two-dimensional central-field
structure are complementary observables and need not yield identical classifications in a finite radial interval.
"""
    mdir=root/"manuscript"; mdir.mkdir(exist_ok=True)
    (mdir/"stage1g2_leitinger_crosscheck.tex").write_text(fragment.strip()+"\n",encoding="utf-8")

    obj={
      "stage":"Stage1G2","version":"0.1.0","generated_utc":utcnow(),
      "crosscheck_complete":True,
      "n_clusters":6,
      "leitinger_source_doi":cfg["source"]["doi"],
      "ngc3201_stage1g_power_status":nstatus,
      "ngc3201_strong_signchange_interior_fraction":None if np.isnan(nint) else float(nint),
      "ngc3201_strong_signchange_shape_recovery_fraction":None if np.isnan(nshape) else float(nshape),
      "real_cluster_classes_changed":False,
      "science_refit_performed":False,
      "manuscript_fragment_ready":True,
      "disposition":"LEITINGER_QUANTITATIVE_CROSSCHECK_COMPLETE_MANUSCRIPT_UPDATE_AUTHORIZED"
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    write_json(val/"stage1g2_preflight.json",obj)
    print(json.dumps(obj,indent=2))

if __name__=="__main__": main()
