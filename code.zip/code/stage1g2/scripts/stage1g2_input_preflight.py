
from pathlib import Path
import argparse, json
import yaml
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1g2_protocol.yaml").read_text(encoding="utf-8"))
    missing=[]
    for rel in [cfg["source"]["values_file"],cfg["upstream"]["stage1d4_classification"],
                cfg["upstream"]["stage1g_preflight"],cfg["upstream"]["stage1g_power_summary"]]:
        if not (root/rel).exists(): missing.append(rel)
    obj={"stage":"Stage1G2","input_ready":not missing,"missing":missing,
         "disposition":"STAGE1G2_INPUT_READY" if not missing else "STAGE1G2_INPUT_NOT_READY"}
    print(json.dumps(obj,indent=2))
    if missing: raise SystemExit(2)
if __name__=="__main__": main()
