@echo off
setlocal
python scripts\stage1g2_input_preflight.py --root . || exit /b 1
python scripts\stage1g2_crosscheck.py --root . || exit /b 1
echo STAGE1G2: PASS
endlocal
