@echo off
python scripts\stage1g2_input_preflight.py --root .
