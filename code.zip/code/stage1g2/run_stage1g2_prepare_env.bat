@echo off
python -c "import numpy,pandas,yaml; print('Stage1G2 environment: OK')"
