# Stage 1G2 v0.1.0 — Leitinger et al. (2023) quantitative cross-check

This package is designed to run **after Stage 1G**.

It contains the exact six-cluster values transcribed from Leitinger et al. (2023, MNRAS 520, 1456; doi:10.1093/mnras/stad093):

- `A+_4` and uncertainty;
- `A+_total` and uncertainty;
- inner/full enriched fractions;
- maximum analysed radius in HLR;
- a conservative published-morphology note.

The script merges these with the frozen Stage1D4 table and with the **actual Stage1G power calibration**.

The estimands are deliberately kept distinct:
- our `D_diff>0`: P2-like fraction decreases outward on average;
- Leitinger `A+<0`: P2/enriched population is cumulatively more centrally concentrated.

The package does **not** compute a Pearson/Spearman correlation between the six `D_diff` and `A+` values, because the sample is tiny and the quantities are not equivalent observables.

The NGC 3201 discussion is generated from the actual Stage1G `SIGNCHANGE_G090` recovery result, so the paper will say either:
- strong sign-changing curvature is recoverable at the real NGC3201 sampling;
- power is intermediate; or
- the HST analysis is power-limited for that curvature.

## Run after Stage 1G finalize

```bat
call run_stage1g2_prepare_env.bat
call run_stage1g2_input_preflight.bat
call run_stage1g2.bat
```

Outputs:
- `outputs/stage1g2/stage1g2_leitinger_crosscheck.csv`
- `tables/stage1g2_leitinger_crosscheck.tex`
- `manuscript/stage1g2_leitinger_crosscheck.tex`
- `validation/stage1g2_preflight.json`
