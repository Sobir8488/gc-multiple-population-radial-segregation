@echo off
setlocal
python scripts\stage1d3b_selftest.py || exit /b 1
python scripts\stage1d3b_input_preflight.py --root . || exit /b 1
python scripts\stage1d3b_audit.py --root . || exit /b 1
python scripts\stage1d3b_finalize.py --root . || exit /b 1
echo STAGE1D3B: PASS
endlocal
