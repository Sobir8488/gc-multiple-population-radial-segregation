
import numpy as np

# Oriented quality burden: larger is worse by construction.
rms=np.array([0.01,0.02,0.04])
qfit=np.array([0.99,0.95,0.80])
assert np.argsort(rms).tolist()==np.argsort(-qfit).tolist()

# Four-cluster BH family is fixed: 3 flagged + 1 clean control.
assert 3+1==4
print("STAGE1D3B_SELFTEST: PASS")
