
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3b_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3b_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d3b/stage1d3b_cluster_summary.csv")
    expected=set(cfg["flagged_clusters"]+cfg["clean_control"])
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("four closure clusters audited",set(s.cluster_id)==expected,f"{len(s)}/4")
    add("closure q-values finite",s.quality_conditioned_az_bh_q.notna().all() and
        s.highq80_az_bh_q.notna().all(),"finite")
    add("clean control present",(s.cluster_id=="NGC5272").sum()==1,"NGC5272")
    nerr=sum(not x["passed"] for x in checks)
    unresolved=s.stage1d3b_status.isin([
        "RADIAL_RESULT_QUALITY_SENSITIVE_UNRESOLVED",
        "RADIAL_RESULT_SPATIAL_STRUCTURE_AMBIGUOUS",
        "CLEAN_CONTROL_CHANGED_UNDER_CLOSURE"
    ])
    nun=int(unresolved.sum())
    persistent=int((s.stage1d3b_status=="RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY").sum())
    qualityvalid=int((s.stage1d3b_status=="RADIAL_AVERAGE_VALIDATED_AFTER_QUALITY_CONTROL").sum())
    controlclean=bool((s.stage1d3b_status=="CLEAN_CONTROL_REMAINS_2D_CLEAN").any())
    synthesis=bool(nerr==0 and nun==0 and controlclean)
    obj={
      "stage":"Stage1D3B","version":"0.1.0","generated_utc":utcnow(),
      "closure_complete":nerr==0,
      "n_flagged_validated_after_quality_control":qualityvalid,
      "n_persistent_nonaxisymmetric_radial_average":persistent,
      "n_unresolved_or_ambiguous":nun,
      "clean_control_remains_clean":controlclean,
      "absolute_density_slopes_ready":False,
      "science_ready_for_claim_safe_synthesis":synthesis,
      "next_required_stage":(
          "Stage1D4 claim-safe science synthesis and manuscript integration"
          if synthesis else
          "Stage1D3C targeted unresolved-cluster closure; do not relax Stage1D3B gates"
      ),
      "n_checks":len(checks),"n_error_failures":nerr,
      "disposition":(
          "STAGE1D3B_CLOSURE_COMPLETE_CLAIM_SYNTHESIS_AUTHORIZED"
          if synthesis else
          "STAGE1D3B_CLOSURE_COMPLETE_UNRESOLVED_FLAGS_REMAIN"
      )
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3b_preflight.csv",index=False)
    write_json(val/"stage1d3b_preflight.json",obj)
    lines=["# Stage 1D3B flagged-cluster spatial closure","",
           f"- Closure complete: **{obj['closure_complete']}**",
           f"- Validated after quality control: **{qualityvalid}**",
           f"- Persistent non-axisymmetric radial averages: **{persistent}**",
           f"- Unresolved/ambiguous: **{nun}**",
           f"- Clean control remains clean: **{controlclean}**",
           f"- Claim-safe synthesis authorized: **{synthesis}**",
           "- Absolute density slopes ready: **False**","","## Cluster adjudication"]
    for _,r in s.iterrows():
        lines.append(
          f"- {r.cluster_id}: `{r.stage1d3b_status}`; conditioned az p={r.quality_conditioned_az_p:.4g}, "
          f"qBH={r.quality_conditioned_az_bh_q:.4g}; highQ80 az p={r.highq80_az_p:.4g}, "
          f"qBH={r.highq80_az_bh_q:.4g}; shellMax={r.max_single_shell_abs_gain_fraction:.3f}; "
          f"radial-quality-stable={bool(r.radial_quality_trim_stable)}."
        )
    lines += ["",f"Next: **{obj['next_required_stage']}**"]
    (val/"stage1d3b_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
