
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3b_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3b_protocol.yaml").read_text(encoding="utf-8"))
    p=json.loads((root/cfg["upstream"]["stage1d3_preflight"]).read_text(encoding="utf-8"))
    s=pd.read_csv(root/cfg["upstream"]["stage1d3_summary"])
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("Stage1D3 flagged closure required",
        p.get("disposition")=="STAGE1D3_AUDIT_COMPLETE_FLAGGED_CLUSTERS_REQUIRE_CLOSURE",
        p.get("disposition",""))
    observed_flagged=s.loc[s.stage1d3_status=="RADIAL_DIFFERENTIAL_STRUCTURE_2D_FLAGGED","cluster_id"].tolist()
    add("frozen flagged cluster set matches",
        set(observed_flagged)==set(cfg["flagged_clusters"]),",".join(observed_flagged))
    controls=s.loc[s.stage1d3_status=="RADIAL_DIFFERENTIAL_STRUCTURE_2D_VALIDATED","cluster_id"].tolist()
    add("NGC5272 is frozen clean control",
        set(cfg["clean_control"]).issubset(set(controls)),",".join(controls))
    missing=[]
    for cid in cfg["flagged_clusters"]+cfg["clean_control"]:
        for key in ["stage1d2_profile_pattern","stage1d2_bootstrap_primary_pattern",
                    "stage1c3_probability_pattern","stage1b_master_pattern",
                    "hugs_normalized_pattern","hugs_source_pattern"]:
            rel=cfg["upstream"][key].format(cluster=cid)
            if not (root/rel).exists(): missing.append(rel)
    add("all closure inputs present",not missing,";".join(missing) if missing else "all present")
    nerr=sum(not x["passed"] for x in checks)
    obj={"stage":"Stage1D3B","version":"0.1.0","generated_utc":utcnow(),
         "input_ready":nerr==0,"closure_performed":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "disposition":"STAGE1D3B_INPUT_READY" if nerr==0 else "STAGE1D3B_INPUT_NOT_READY"}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3b_input_preflight.csv",index=False)
    write_json(val/"stage1d3b_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
