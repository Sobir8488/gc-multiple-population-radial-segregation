
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit, logit
from stage1d3b_common import sha256_file, utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def robust_z(x):
    x=np.asarray(x,float)
    med=float(np.nanmedian(x)); q25,q75=np.nanquantile(x,[.25,.75])
    sc=float((q75-q25)/1.349)
    if not np.isfinite(sc) or sc<=1e-10: sc=float(np.nanstd(x))
    if not np.isfinite(sc) or sc<=1e-10: sc=1.0
    return (x-med)/sc

def basis(x,knots,degree,deriv=0):
    n=len(knots)-degree-1; eye=np.eye(n)
    out=[]
    for j in range(n):
        s=BSpline(knots,eye[j],degree,extrapolate=False)
        if deriv: s=s.derivative(deriv)
        out.append(s(np.asarray(x,float)))
    return np.column_stack(out)

def penalty(n):
    D=np.diff(np.eye(n),n=2,axis=0)
    return D.T@D

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P)
    N=V[:,w<tol]
    if N.shape[1]!=2: raise RuntimeError(f"penalty nullspace dimension={N.shape[1]}")
    return N

def fit_offset(X,y,offset):
    X=np.asarray(X,float); y=np.asarray(y,float); offset=np.asarray(offset,float)
    b=np.zeros(X.shape[1],float)
    for _ in range(80):
        eta=offset+X@b; p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta))
        g=X.T@(p-y); H=X.T@(w[:,None]*X)+1e-9*np.eye(X.shape[1])
        step=np.linalg.solve(H,g); a=1.0
        for _ in range(25):
            c=b-a*step; e=offset+X@c
            co=float(np.sum(np.logaddexp(0,e)-y*e))
            if co<=obj+1e-12: b=c; break
            a*=0.5
        if np.max(np.abs(a*step))<1e-9: break
    return b

def ll(X,y,offset,b):
    e=offset+X@b
    return float(np.sum(y*e-np.logaddexp(0,e)))

def fit_unpen(B,y):
    return fit_offset(B,y,np.zeros(len(y)))

def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p)
    r=p[o]*n/np.arange(1,n+1)
    r=np.minimum.accumulate(r[::-1])[::-1]
    q=np.empty(n,float); q[o]=np.clip(r,0,1)
    return q

def radial_strata(r,n):
    r=np.asarray(r,float); order=np.argsort(r,kind="mergesort")
    s=np.empty(len(r),int)
    s[order]=np.clip(np.floor(np.arange(len(r))*n/len(r)).astype(int),0,n-1)
    return s

def joint_strata(r,burden):
    rs=radial_strata(r,5)
    cut=float(np.median(burden))
    qs=(burden>cut).astype(int)
    return rs*2+qs

def angular_X(theta,lnR):
    z=robust_z(lnR)
    return np.column_stack([
      np.cos(theta),np.sin(theta),np.cos(2*theta),np.sin(2*theta),
      z*np.cos(theta),z*np.sin(theta),z*np.cos(2*theta),z*np.sin(2*theta)
    ])

def load_master_quality(root,cid,cfg):
    prob=pd.read_csv(root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
    master=pd.read_csv(root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
    rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        rows.append({"master_star_id":mid,"q2p":float(np.mean(num(g.population_probability_2p)))})
    d=pd.DataFrame(rows)
    need=["master_star_id","x_common_arcsec","y_common_arcsec","hugs_source_index","hugs_source_row_id"]
    m=master[need].drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    h=pd.read_csv(root/cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid),low_memory=False)
    s=pd.read_csv(root/cfg["upstream"]["hugs_source_pattern"].format(cluster=cid),low_memory=False)
    if len(h)!=len(s): raise RuntimeError(f"{cid}: HUGS normalized/source mismatch")
    idx=num(d.hugs_source_index).astype(int).to_numpy()
    hh=h.iloc[idx].reset_index(drop=True); ss=s.iloc[idx].reset_index(drop=True)
    if not np.array_equal(hh.source_row_id.astype(str).to_numpy(),
                          d.hugs_source_row_id.astype(str).to_numpy()):
        raise RuntimeError(f"{cid}: frozen HUGS index provenance mismatch")

    filters=["F275W","F336W","F438W","F606W","F814W"]
    rms=np.column_stack([num(ss[f"RMS_{f}"]).to_numpy(float) for f in filters])
    qfit=np.column_stack([num(ss[f"QFIT_{f}"]).to_numpy(float) for f in filters])
    radxs=np.column_stack([num(ss[f"RADXS_{f}"]).to_numpy(float) for f in filters])
    nf=np.column_stack([num(ss[f"Nf_{f}"]).to_numpy(float) for f in filters])
    ng=np.column_stack([num(ss[f"Ng_{f}"]).to_numpy(float) for f in filters])
    ratio=np.divide(ng,nf,out=np.zeros_like(ng,float),where=nf>0)
    if not np.isfinite(rms).all() or not np.isfinite(qfit).all() or not np.isfinite(radxs).all():
        raise RuntimeError(f"{cid}: non-finite HUGS quality metrics")
    d["max_rms"]=np.max(rms,axis=1)
    d["min_qfit"]=np.min(qfit,axis=1)
    d["max_abs_radxs"]=np.max(np.abs(radxs),axis=1)
    d["min_ng_nf"]=np.min(ratio,axis=1)
    d["iter"]=num(ss["ITER"]).to_numpy(float)
    qmat=np.column_stack([
      robust_z(np.log(np.clip(d.max_rms.to_numpy(float),1e-8,None))),
      robust_z(-d.min_qfit.to_numpy(float)),
      robust_z(d.max_abs_radxs.to_numpy(float)),
      robust_z(-d.min_ng_nf.to_numpy(float)),
      robust_z(d["iter"].to_numpy(float))
    ])
    d["quality_burden"]=np.mean(qmat,axis=1)
    d["radius_arcsec"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    d["theta"]=np.arctan2(num(d.y_common_arcsec),num(d.x_common_arcsec))
    return d,qmat

def radial_baseline(root,cid,R,cfg):
    p=pd.read_csv(root/cfg["upstream"]["stage1d2_profile_pattern"].format(cluster=cid))
    xp=np.log(num(p.R_arcsec).to_numpy(float))
    pp=np.clip(num(p.p2p).to_numpy(float),1e-6,1-1e-6)
    x=np.log(np.asarray(R,float))
    return np.interp(x,xp,logit(pp)),float(np.min(p.R_arcsec)),float(np.max(p.R_arcsec))

def conditional_az_test(q,R,theta,Q,offset,nperm,seed):
    A=angular_X(theta,np.log(R))
    bq=fit_offset(Q,q,offset)
    offq=offset+Q@bq
    ba=fit_offset(A,q,offq)
    ll0=ll(Q,q,offset,bq)
    ll1=ll(A,q,offq,ba)
    obs=2*(ll1-ll0)
    st=joint_strata(R,np.mean(Q,axis=1))
    rng=np.random.default_rng(seed); vals=np.empty(nperm,float)
    for j in range(nperm):
        tp=theta.copy()
        for k in np.unique(st):
            idx=np.where(st==k)[0]
            tp[idx]=theta[rng.permutation(idx)]
        Ap=angular_X(tp,np.log(R))
        bp=fit_offset(Ap,q,offq)
        vals[j]=2*(ll(Ap,q,offq,bp)-ll0)
    p=float((1+np.sum(vals>=obs))/(1+nperm))
    # Per-star absolute likelihood-gain localization.
    e0=offq
    e1=offq+A@ba
    gain=(q*e1-np.logaddexp(0,e1))-(q*e0-np.logaddexp(0,e0))
    return obs,p,ba,vals,gain

def highq_az_test(q,R,theta,offset,nperm,seed):
    A=angular_X(theta,np.log(R))
    b=fit_offset(A,q,offset)
    ll0=float(np.sum(q*offset-np.logaddexp(0,offset)))
    obs=2*(ll(A,q,offset,b)-ll0)
    st=radial_strata(R,5); rng=np.random.default_rng(seed)
    vals=np.empty(nperm,float)
    for j in range(nperm):
        tp=theta.copy()
        for k in np.unique(st):
            idx=np.where(st==k)[0]
            tp[idx]=theta[rng.permutation(idx)]
        Ap=angular_X(tp,np.log(R)); bp=fit_offset(Ap,q,offset)
        vals[j]=2*(ll(Ap,q,offset,bp)-ll0)
    return obs,float((1+np.sum(vals>=obs))/(1+nperm)),vals

def nullspace_refit(root,cid,d,keep,cfg):
    ready=pd.read_csv(root/cfg["upstream"]["stage1d1b_readiness"])
    s=ready.loc[ready.cluster_id==cid].iloc[0]
    kd=pd.read_csv(root/cfg["upstream"]["stage1d1b_knots"])
    knots=kd.loc[kd.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
    R=d.radius_arcsec.to_numpy(float); q=d.q2p.to_numpy(float)
    Rref=float(s.R_ref_arcsec); x=np.log(R/Rref)
    fit=(R>=float(s.r_fit_q05_arcsec))&(R<=float(s.r_fit_q95_arcsec))&keep
    degree=3
    B=basis(x[fit],knots,degree,0); N=nullspace(penalty(B.shape[1]))
    th=fit_unpen(B@N,q[fit])
    gx=np.linspace(np.log(float(s.r_claim_q10_arcsec)/Rref),
                   np.log(float(s.r_claim_q90_arcsec)/Rref),201)
    Bg=basis(gx,knots,degree,0)@N
    Dg=basis(gx,knots,degree,1)@N
    eta=Bg@th; dg=-(Dg@th)
    return float(np.mean(dg)),Rref*np.exp(gx),eta,dg

def shell_fraction(R,gain):
    st=radial_strata(R,3)
    vals=[]
    for k in range(3):
        vals.append(float(np.sum(np.abs(gain[st==k]))))
    tot=sum(vals)
    return (max(vals)/tot if tot>0 else 1.0),vals

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3b_protocol.yaml").read_text(encoding="utf-8"))
    inp=json.loads((root/"validation/stage1d3b_input_preflight.json").read_text(encoding="utf-8"))
    if not inp.get("input_ready",False): raise SystemExit("Stage1D3B input not ready")
    s2=pd.read_csv(root/cfg["upstream"]["stage1d2_summary"])
    s3=pd.read_csv(root/cfg["upstream"]["stage1d3_summary"])
    audited=cfg["flagged_clusters"]+cfg["clean_control"]
    out=root/"outputs/stage1d3b"; out.mkdir(parents=True,exist_ok=True)
    rows=[]; trimrows=[]; shellrows=[]

    for ic,cid in enumerate(audited):
        d,Qall=load_master_quality(root,cid,cfg)
        eta,rlo,rhi=radial_baseline(root,cid,d.radius_arcsec,cfg)
        claim=(d.radius_arcsec>=rlo)&(d.radius_arcsec<=rhi)
        g=d.loc[claim].copy().reset_index(drop=True)
        Q=Qall[claim]
        q=g.q2p.to_numpy(float); R=g.radius_arcsec.to_numpy(float)
        th=g.theta.to_numpy(float); off=eta[claim]
        astat,ap,ab,avals,gain=conditional_az_test(
            q,R,th,Q,off,int(cfg["conditional_azimuthal_test"]["permutations"]),
            int(cfg["conditional_azimuthal_test"]["random_seed"])+10000*ic)
        shfrac,shvals=shell_fraction(R,gain)
        for k,v in enumerate(shvals):
            shellrows.append({"cluster_id":cid,"radial_shell":k,
                              "absolute_loglik_gain":v})
        upstream=s2.loc[s2.cluster_id==cid].iloc[0]
        boot=np.load(root/cfg["upstream"]["stage1d2_bootstrap_primary_pattern"].format(cluster=cid))
        Dsd=float(np.std(np.mean(boot,axis=1),ddof=1))
        trimDs={}
        highq_p=np.nan; highq_stat=np.nan
        for frac in cfg["quality_trim_replication"]["fractions_retained"]:
            cut=float(np.quantile(d.quality_burden,float(frac)))
            keep=(d.quality_burden.to_numpy(float)<=cut)
            Dt,gR,et,dg=nullspace_refit(root,cid,d,keep,cfg)
            trimDs[float(frac)]=Dt
            trimrows.append({
              "cluster_id":cid,"fraction_retained":float(frac),
              "n_retained":int(keep.sum()),"D_diff":Dt,
              "D_shift":float(Dt-float(upstream.D_diff)),
              "D_shift_bootstrap_sd_units":float(abs(Dt-float(upstream.D_diff))/Dsd),
              "sign_preserved":bool(np.sign(Dt)==np.sign(float(upstream.D_diff)))
            })
            if abs(float(frac)-float(cfg["quality_trim_replication"]["primary_trim_fraction"]))<1e-9:
                # Test angle on the 80% high-quality sample using its own refit radial baseline.
                keep_claim=keep & (d.radius_arcsec>=rlo)&(d.radius_arcsec<=rhi)
                gg=d.loc[keep_claim].copy().reset_index(drop=True)
                xg=np.log(gg.radius_arcsec.to_numpy(float))
                eta_h=np.interp(xg,np.log(gR),et)
                highq_stat,highq_p,hvals=highq_az_test(
                    gg.q2p.to_numpy(float),gg.radius_arcsec.to_numpy(float),
                    gg.theta.to_numpy(float),eta_h,
                    int(cfg["quality_trim_replication"]["high_quality_azimuthal_test"]["permutations"]),
                    int(cfg["conditional_azimuthal_test"]["random_seed"])+500000+10000*ic)
                cdir=out/"clusters"/cid; cdir.mkdir(parents=True,exist_ok=True)
                np.save(cdir/f"{cid}_highq_azimuthal_permutation.npy",hvals)
        radialstable=all(
            np.sign(v)==np.sign(float(upstream.D_diff)) and
            abs(v-float(upstream.D_diff))<=
            float(cfg["quality_trim_replication"]["radial_stability_gate"]["maximum_abs_D_shift_each_fraction_in_primary_bootstrap_sd_units"])*Dsd
            for v in trimDs.values()
        )
        cdir=out/"clusters"/cid; cdir.mkdir(parents=True,exist_ok=True)
        np.save(cdir/f"{cid}_quality_conditioned_azimuthal_permutation.npy",avals)
        rows.append({
          "cluster_id":cid,
          "upstream_stage1d2_status":upstream.final_status,
          "upstream_stage1d3_status":s3.loc[s3.cluster_id==cid,"stage1d3_status"].iloc[0],
          "n_claim":len(g),"D_diff_primary":float(upstream.D_diff),
          "bootstrap_D_sd":Dsd,
          "quality_conditioned_az_statistic":astat,
          "quality_conditioned_az_p":ap,
          "highq80_az_statistic":highq_stat,
          "highq80_az_p":highq_p,
          "max_single_shell_abs_gain_fraction":shfrac,
          "radial_quality_trim_stable":bool(radialstable),
          "stage1d3_sector_jackknife_pass":bool(s3.loc[s3.cluster_id==cid,"sector_jackknife_pass"].iloc[0])
        })
        print(f"[Stage1D3B] {cid}: condAz_p={ap:.4g} highQ80_p={highq_p:.4g} "
              f"shellMax={shfrac:.3f} radialQualityStable={radialstable}")

    df=pd.DataFrame(rows)
    df["quality_conditioned_az_bh_q"]=bh(df.quality_conditioned_az_p)
    df["highq80_az_bh_q"]=bh(df.highq80_az_p)
    statuses=[]
    for _,r in df.iterrows():
        condsig=bool(r.quality_conditioned_az_bh_q<0.05)
        highsig=bool(r.highq80_az_bh_q<0.05)
        if r.cluster_id in cfg["clean_control"]:
            if bool(r.radial_quality_trim_stable) and (not condsig) and (not highsig):
                st="CLEAN_CONTROL_REMAINS_2D_CLEAN"
            else:
                st="CLEAN_CONTROL_CHANGED_UNDER_CLOSURE"
        else:
            if not bool(r.radial_quality_trim_stable):
                st="RADIAL_RESULT_QUALITY_SENSITIVE_UNRESOLVED"
            elif (not condsig) and (not highsig):
                st="RADIAL_AVERAGE_VALIDATED_AFTER_QUALITY_CONTROL"
            elif condsig and highsig and \
                 float(r.max_single_shell_abs_gain_fraction)<=float(cfg["radial_localization"]["maximum_single_shell_fraction_for_persistent_2d_class"]) and \
                 bool(r.stage1d3_sector_jackknife_pass):
                st="RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY"
            else:
                st="RADIAL_RESULT_SPATIAL_STRUCTURE_AMBIGUOUS"
        statuses.append(st)
    df["stage1d3b_status"]=statuses
    df.to_csv(out/"stage1d3b_cluster_summary.csv",index=False)
    pd.DataFrame(trimrows).to_csv(out/"stage1d3b_quality_trim_replication.csv",index=False)
    pd.DataFrame(shellrows).to_csv(out/"stage1d3b_radial_shell_localization.csv",index=False)

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d3b_output_manifest.csv":
            manifest.append({"path":str(p.relative_to(out)).replace("\\","/"),
                             "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1d3b_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
