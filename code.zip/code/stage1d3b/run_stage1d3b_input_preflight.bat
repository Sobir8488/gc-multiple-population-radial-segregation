@echo off
python scripts\stage1d3b_input_preflight.py --root .
