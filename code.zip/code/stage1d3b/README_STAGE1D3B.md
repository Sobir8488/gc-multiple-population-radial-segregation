# Stage 1D3B v0.1.0 — flagged-cluster spatial closure

Stage 1D3 produced one clean 2D-validated radial detection (NGC 5272), three flagged radial detections
(NGC 2808, NGC 5024, NGC 6205), and two radial/2D null clusters (NGC 3201, NGC 5904).

Stage 1D3B does **not** relax the Stage 1D3 threshold. It asks what the three flags mean.

Four clusters are audited with one identical closure pipeline:
- NGC 2808, NGC 5024, NGC 6205: flagged targets;
- NGC 5272: frozen clean negative control.

The closure has three blocks:

1. **Quality-conditioned azimuthal test**  
   The frozen Stage 1D2 radial baseline is augmented by five population-blind HUGS quality covariates:
   max RMS, min QFIT, max |RADXS|, min Ng/Nf, and ITER. Angular m=1/m=2 terms are then tested on top
   of this nuisance model with 999 angle permutations in joint radial×quality strata.

2. **Quality-trim replication**  
   The exact nullspace radial model is refitted after retaining the best 90%, 80%, and 70% of stars by a
   population-blind quality-burden score. Every retained-fraction D_diff must keep the primary sign and stay
   within 1.5 primary-bootstrap SD of the Stage 1D2 D_diff. The 80% high-quality sample also receives its own
   999-permutation azimuthal test.

3. **Radial localization of the 2D signal**  
   The angular likelihood gain is decomposed over three equal-count radial shells. A persistent-2D
   classification is not allowed when >80% of the absolute gain comes from one shell.

Possible scientifically useful outcomes include:
- `RADIAL_AVERAGE_VALIDATED_AFTER_QUALITY_CONTROL`;
- `RADIAL_AVERAGE_ROBUST_WITH_PERSISTENT_NONAXISYMMETRY`.

The second status is not a failure: it means the HST-footprint radial average is robust, but the cluster
must not be described as axisymmetric.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d3b_prepare_env.bat
call run_stage1d3b_selftest.bat
call run_stage1d3b_input_preflight.bat
call run_stage1d3b.bat
```
