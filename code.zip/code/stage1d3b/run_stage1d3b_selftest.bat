@echo off
python scripts\stage1d3b_selftest.py
