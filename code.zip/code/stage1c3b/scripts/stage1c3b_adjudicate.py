
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from sklearn.mixture import GaussianMixture
from stage1c3b_common import sha256_file, utc, write_json

def robust_scale(X):
    med=np.median(X,axis=0)
    q25=np.quantile(X,0.25,axis=0); q75=np.quantile(X,0.75,axis=0)
    sc=(q75-q25)/1.349
    sd=np.std(X,axis=0)
    sc=np.where((sc>1e-10)&np.isfinite(sc),sc,np.where(sd>1e-10,sd,1.0))
    return med,sc

def fit_gmm(X,k,cov,n_init,max_iter,reg,seed):
    gm=GaussianMixture(n_components=k,covariance_type=cov,n_init=n_init,
                       max_iter=max_iter,reg_covar=reg,random_state=seed,
                       init_params="kmeans")
    gm.fit(X)
    return gm

def family_scan(X,cov,cfg,seed_offset=0,maxk=None):
    maxk=maxk or int(cfg["gmm"]["max_components"])
    rows=[]; models={}
    for k in range(1,maxk+1):
        gm=fit_gmm(X,k,cov,int(cfg["gmm"]["n_init"]),int(cfg["gmm"]["max_iter"]),
                   float(cfg["gmm"]["reg_covar"]),int(cfg["gmm"]["random_seed"])+seed_offset+97*k)
        models[k]=gm
        rows.append({"k":k,"bic":gm.bic(X),"aic":gm.aic(X),"converged":bool(gm.converged_),
                     "n_iter":int(gm.n_iter_)})
    return pd.DataFrame(rows),models

def orient_two(gm):
    means=gm.means_
    score=means[:,1]-0.5*means[:,0]
    hi=int(np.argmax(score)); lo=1-hi
    q=gm.predict_proba(gm._X_for_diag)[:,hi] if hasattr(gm,"_X_for_diag") else None
    return lo,hi,score

def two_metrics(X,gm):
    score=gm.means_[:,1]-0.5*gm.means_[:,0]
    hi=int(np.argmax(score)); lo=1-hi
    q=gm.predict_proba(X)[:,hi]
    w=gm.weights_
    pooled=w[0]*gm.covariances_[0]+w[1]*gm.covariances_[1]
    d=gm.means_[hi]-gm.means_[lo]
    mahal=float(np.sqrt(max(0.0,d@np.linalg.inv(pooled)@d)))
    gap=float(score[hi]-score[lo])
    amb=float(np.mean((q>0.2)&(q<0.8)))
    dets=np.array([np.linalg.det(c) for c in gm.covariances_],float)
    cov_ratio=float(np.nanmax(dets)/max(np.nanmin(dets),1e-15))
    return {"hi":hi,"lo":lo,"q":q,"mahal":mahal,"gap":gap,"amb":amb,
            "cov_det_ratio":cov_ratio,
            "weights":gm.weights_.tolist(),
            "means":gm.means_.tolist(),
            "covariances":gm.covariances_.tolist()}

def projection_scan(X,cfg,seed_offset=0):
    s=(X[:,1]-0.5*X[:,0])[:,None]
    rows=[]; models={}
    for k in range(1,int(cfg["projection_gmm"]["max_components"])+1):
        gm=GaussianMixture(n_components=k,covariance_type="full",
                           n_init=int(cfg["projection_gmm"]["n_init"]),
                           max_iter=int(cfg["gmm"]["max_iter"]),
                           reg_covar=float(cfg["gmm"]["reg_covar"]),
                           random_state=int(cfg["gmm"]["random_seed"])+seed_offset+811*k)
        gm.fit(s); models[k]=gm
        rows.append({"k":k,"bic":gm.bic(s),"aic":gm.aic(s),"converged":bool(gm.converged_)})
    return pd.DataFrame(rows),models

def oriented_q(X,gm):
    score=gm.means_[:,1]-0.5*gm.means_[:,0]
    hi=int(np.argmax(score))
    return gm.predict_proba(X)[:,hi]

def compare_hard(qref,q):
    # q and 1-q are both possible under numerical component swaps; orientation handles most cases.
    a=float(np.mean((qref>=0.5)==(q>=0.5)))
    return max(a,1-a)

def bootstrap_diag(X,refq,cfg):
    rng=np.random.default_rng(int(cfg["bootstrap"]["random_seed"]))
    n=len(X); rows=[]
    for b in range(int(cfg["bootstrap"]["n_replays"])):
        idx=rng.integers(0,n,n)
        xb=X[idx]
        try:
            g1=fit_gmm(xb,1,"full",3,500,float(cfg["gmm"]["reg_covar"]),500000+b)
            g2=fit_gmm(xb,2,"full",4,500,float(cfg["gmm"]["reg_covar"]),600000+b)
            db=float(g1.bic(xb)-g2.bic(xb))
            tm=two_metrics(xb,g2)
            q=oriented_q(X,g2)
            rows.append({"replay":b,"delta_bic_k1_to_k2":db,"mahal":tm["mahal"],
                         "gap":tm["gap"],"ambiguity":tm["amb"],
                         "hard_agreement":compare_hard(refq,q)})
        except Exception:
            rows.append({"replay":b,"delta_bic_k1_to_k2":np.nan,"mahal":np.nan,
                         "gap":np.nan,"ambiguity":np.nan,"hard_agreement":np.nan})
    return pd.DataFrame(rows)

def split_half_diag(X,refq,cfg):
    rng=np.random.default_rng(int(cfg["split_half"]["random_seed"]))
    n=len(X); rows=[]
    for r in range(int(cfg["split_half"]["n_replays"])):
        perm=rng.permutation(n)
        for half,hidx in enumerate([perm[:n//2],perm[n//2:]]):
            try:
                gm=fit_gmm(X[hidx],2,"full",4,500,float(cfg["gmm"]["reg_covar"]),700000+10*r+half)
                q=oriented_q(X,gm)
                rows.append({"replay":r,"half":half,"hard_agreement":compare_hard(refq,q)})
            except Exception:
                rows.append({"replay":r,"half":half,"hard_agreement":np.nan})
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1c3b_protocol.yaml").read_text(encoding="utf-8"))
    s3=root/"outputs/stage1c3"; out=root/"outputs/stage1c3b"; out.mkdir(parents=True,exist_ok=True)

    # Freeze audit for six supported clusters.
    freeze=pd.read_csv(root/"config/stage1c3b_supported_freeze_manifest.csv")
    audits=[]
    for _,r in freeze.iterrows():
        p=s3/r["path"]
        got=sha256_file(p) if p.exists() else "MISSING"
        audits.append({"cluster_id":r.cluster_id,"path":r["path"],"expected_sha256":r.sha256,
                       "observed_sha256":got,"byte_identity_passed":got==r.sha256})
    pd.DataFrame(audits).to_csv(out/"stage1c3b_supported_freeze_audit.csv",index=False)
    if not all(x["byte_identity_passed"] for x in audits):
        raise SystemExit("Supported Stage1C3 byte identity failed; refusing adjudication.")

    summaries=[]; modelrows=[]; bootall=[]; halfall=[]; decisions=[]
    for cid in cfg["weak_clusters"]:
        p=s3/"clusters"/cid/f"{cid}_population_probabilities.csv.gz"
        df=pd.read_csv(p)
        cols=cfg["features"]
        Xraw=df[cols].to_numpy(float)
        med,sc=robust_scale(Xraw); X=(Xraw-med)/sc

        fulltab,fullmodels=family_scan(X,"full",cfg,0)
        tiedtab,tiedmodels=family_scan(X,"tied",cfg,10000)
        protab,promodels=projection_scan(X,cfg,20000)
        kfull=int(fulltab.loc[fulltab.bic.idxmin(),"k"])
        ktied=int(tiedtab.loc[tiedtab.bic.idxmin(),"k"])
        kproj=int(protab.loc[protab.bic.idxmin(),"k"])
        full1=fullmodels[1]; full2=fullmodels[2]
        db_full12=float(full1.bic(X)-full2.bic(X))
        db_proj=float(protab.loc[protab.k==1,"bic"].iloc[0]-protab.bic.min())
        tm=two_metrics(X,full2); refq=tm["q"]

        boot=bootstrap_diag(X,refq,cfg); boot["cluster_id"]=cid; bootall.append(boot)
        half=split_half_diag(X,refq,cfg); half["cluster_id"]=cid; halfall.append(half)

        gates=cfg["gates"]
        boot_frac=float(np.nanmean(boot.delta_bic_k1_to_k2>=float(gates["min_fullcov_delta_bic_k1_to_k2"])))
        boot_agree=float(np.nanmedian(boot.hard_agreement))
        half_agree=float(np.nanmedian(half.hard_agreement))
        gatevals={
            "fullcov_k2_evidence":db_full12>=float(gates["min_fullcov_delta_bic_k1_to_k2"]),
            "projection_location_evidence":db_proj>=float(gates["min_projection_delta_bic_k1_to_best"]) and kproj>=2,
            "centroid_mahalanobis":tm["mahal"]>=float(gates["min_pooled_mahalanobis_centroid_separation"]),
            "enrichment_centroid_gap":tm["gap"]>=float(gates["min_enrichment_centroid_gap_robust_units"]),
            "ambiguity":tm["amb"]<=float(gates["max_ambiguity_fraction_0p2_0p8"]),
            "bootstrap_bic_support":boot_frac>=float(gates["min_bootstrap_fraction_fullcov_k2_supported"]),
            "bootstrap_label_stability":boot_agree>=float(gates["min_bootstrap_median_hard_agreement"]),
            "split_half_label_stability":half_agree>=float(gates["min_split_half_median_hard_agreement"])
        }

        if all(gatevals.values()):
            status="RECOVERED_PHOTOMETRIC_1P2P"
        else:
            # Multi-pop collapse requires actual location evidence; covariance-only partitions never qualify.
            status="UNRESOLVED_PRIMARY_EXCLUSION"

        # EXTREMES_ONLY is deliberately unavailable without independent star-level anchors.
        anchor_file=root/"inputs/stage1c3b_external_anchors"/f"{cid}.csv"
        external_anchor_available=anchor_file.exists()

        summaries.append({
            "cluster_id":cid,"n_rgb":len(df),
            "stage1c3_status":df["cluster_classifier_status"].iloc[0],
            "best_k_tied":ktied,"best_k_full":kfull,"best_k_projection":kproj,
            "delta_bic_full_k1_to_k2":db_full12,
            "delta_bic_projection_k1_to_best":db_proj,
            "full_k2_centroid_mahalanobis":tm["mahal"],
            "full_k2_enrichment_centroid_gap":tm["gap"],
            "full_k2_ambiguity_fraction":tm["amb"],
            "full_k2_covariance_determinant_ratio":tm["cov_det_ratio"],
            "bootstrap_fraction_k2_supported":boot_frac,
            "bootstrap_median_hard_agreement":boot_agree,
            "split_half_median_hard_agreement":half_agree,
            "external_star_level_anchor_available":external_anchor_available,
            "final_status":status
        })
        for fam,tab in [("tied_2d",tiedtab),("full_2d",fulltab),("projection_1d",protab)]:
            tt=tab.copy(); tt["cluster_id"]=cid; tt["family"]=fam
            modelrows.append(tt)
        decisions.append({
            "cluster_id":cid,"final_status":status,
            "primary_probability_authorized":status in ["RECOVERED_PHOTOMETRIC_1P2P","MULTIPOP_COLLAPSE_AUTHORIZED"],
            "extremes_only_authorized":status=="EXTREMES_ONLY_AUTHORIZED",
            "reason":";".join([k for k,v in gatevals.items() if not v]) or "all gates passed",
            "claim_boundary":"Covariance-driven partitions with weak centroid separation are not treated as distinct 1P/2P populations."
        })
        write_json(out/"clusters"/cid/f"{cid}_stage1c3b_diagnostics.json",{
            "cluster_id":cid,"generated_utc":utc(),"robust_location":med.tolist(),"robust_scale":sc.tolist(),
            "best_k":{"tied":ktied,"full":kfull,"projection":kproj},
            "full_k2_metrics":{k:v for k,v in tm.items() if k!="q"},
            "bootstrap":{"fraction_k2_supported":boot_frac,"median_hard_agreement":boot_agree},
            "split_half":{"median_hard_agreement":half_agree},
            "gates":gatevals,"final_status":status
        })
        print(f"[Stage1C3B] {cid}: fullK={kfull} projK={kproj} dBIC12={db_full12:.2f} "
              f"mahal={tm['mahal']:.3f} gap={tm['gap']:.3f} amb={tm['amb']:.3f} -> {status}")

    sdf=pd.DataFrame(summaries)
    sdf.to_csv(out/"stage1c3b_adjudication_summary.csv",index=False)
    pd.concat(modelrows,ignore_index=True).to_csv(out/"stage1c3b_model_family_scan.csv",index=False)
    pd.concat(bootall,ignore_index=True).to_csv(out/"stage1c3b_bootstrap_diagnostics.csv",index=False)
    pd.concat(halfall,ignore_index=True).to_csv(out/"stage1c3b_split_half_diagnostics.csv",index=False)
    pd.DataFrame(decisions).to_csv(out/"stage1c3b_decision_ledger.csv",index=False)

    primary=pd.DataFrame({"cluster_id":cfg["supported_frozen_clusters"],
                          "probability_source":"Stage1C3_v0.1.0_FROZEN",
                          "primary_status":"AUTHORIZED"})
    for _,r in sdf.iterrows():
        primary.loc[len(primary)]={"cluster_id":r.cluster_id,
                                   "probability_source":"Stage1C3B_v0.1.0",
                                   "primary_status":"AUTHORIZED" if r.final_status!="UNRESOLVED_PRIMARY_EXCLUSION" else "EXCLUDED_WEAK_CLASSIFIER"}
    primary.to_csv(out/"stage1c3b_primary_probability_sample.csv",index=False)

if __name__=="__main__":
    main()
