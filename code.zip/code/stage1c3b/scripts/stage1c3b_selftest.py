
import numpy as np
from sklearn.mixture import GaussianMixture
rng=np.random.default_rng(123)
a=rng.normal(loc=[0,0],scale=[0.3,0.3],size=(400,2))
b=rng.normal(loc=[-1.2,1.4],scale=[0.35,0.35],size=(500,2))
X=np.vstack([a,b])
g1=GaussianMixture(1,covariance_type="full",n_init=5,random_state=1).fit(X)
g2=GaussianMixture(2,covariance_type="full",n_init=10,random_state=1).fit(X)
assert g1.bic(X)-g2.bic(X)>10
# covariance-only split: same means but very different covariance should not be interpreted as centroid separation.
c=rng.normal(0,0.25,size=(600,2))
d=rng.normal(0,1.2,size=(400,2))
Y=np.vstack([c,d])
h=GaussianMixture(2,covariance_type="full",n_init=10,random_state=2).fit(Y)
pooled=h.weights_[0]*h.covariances_[0]+h.weights_[1]*h.covariances_[1]
dv=h.means_[1]-h.means_[0]
mah=float(np.sqrt(max(0,dv@np.linalg.inv(pooled)@dv)))
assert mah<0.75
print("STAGE1C3B_SELFTEST: PASS")
