
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1c3b_common import utc, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1c3b_protocol.yaml").read_text(encoding="utf-8"))
    out=root/"outputs/stage1c3b"; val=root/"validation"; val.mkdir(exist_ok=True)
    f=pd.read_csv(out/"stage1c3b_supported_freeze_audit.csv")
    s=pd.read_csv(out/"stage1c3b_adjudication_summary.csv")
    p=pd.read_csv(out/"stage1c3b_primary_probability_sample.csv")
    checks=[]
    def add(name,passed,detail,severity="ERROR"):
        checks.append({"check":name,"passed":bool(passed),"severity":severity,"detail":detail})
    add("six supported Stage1C3 clusters preserved byte-for-byte",f.byte_identity_passed.all(),f"{int(f.byte_identity_passed.sum())}/{len(f)} files passed")
    add("exactly two weak clusters adjudicated",set(s.cluster_id)==set(cfg["weak_clusters"]),",".join(s.cluster_id))
    add("allowed final statuses only",s.final_status.isin(cfg["allowed_final_statuses"]).all(),",".join(sorted(s.final_status.unique())))
    add("all eight pilot clusters accounted for",len(p)==8 and p.cluster_id.nunique()==8,f"{len(p)} rows")
    nerr=sum((not x["passed"]) and x["severity"]=="ERROR" for x in checks)
    nauth=int((p.primary_status=="AUTHORIZED").sum())
    nexcl=int((p.primary_status=="EXCLUDED_WEAK_CLASSIFIER").sum())
    if nerr:
        disp="STAGE1C3B_NOT_READY"
    elif nexcl==0:
        disp="EIGHT_CLUSTER_HUGS_PROBABILITY_FREEZE"
    else:
        disp="SIX_CLUSTER_PROBABILITY_FREEZE_WEAK_CLUSTERS_EXCLUDED"
    obj={"stage":"Stage1C3B","version":"0.1.0","generated_utc":utc(),
         "adjudication_ready":nerr==0,"science_ready":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "n_primary_probability_authorized":nauth,
         "n_primary_probability_excluded":nexcl,
         "excluded_clusters":p.loc[p.primary_status=="EXCLUDED_WEAK_CLASSIFIER","cluster_id"].tolist(),
         "n_retained_blockers":len(cfg["retained_blockers"]),
         "retained_blockers":cfg["retained_blockers"],"disposition":disp}
    pd.DataFrame(checks).to_csv(val/"stage1c3b_preflight.csv",index=False)
    write_json(val/"stage1c3b_preflight.json",obj)
    lines=["# Stage 1C3B preflight","",f"- Disposition: **{disp}**",
           f"- Adjudication ready: **{obj['adjudication_ready']}**",
           f"- Authorized primary probability clusters: **{nauth}/8**",
           f"- Excluded weak-classifier clusters: **{nexcl}**",
           f"- Error failures: **{nerr}**","","## Weak-cluster decisions"]
    for _,r in s.iterrows():
        lines.append(f"- {r.cluster_id}: `{r.final_status}`; full-cov K={int(r.best_k_full)}, "
                     f"projection K={int(r.best_k_projection)}, ΔBIC(K1→K2)={r.delta_bic_full_k1_to_k2:.2f}, "
                     f"Mahalanobis={r.full_k2_centroid_mahalanobis:.3f}, ambiguity={r.full_k2_ambiguity_fraction:.3f}.")
    lines += ["","## Claim boundary",
              "A full-covariance mixture may improve BIC by separating covariance structure rather than population centroids. "
              "Such a split is not promoted to a 1P/2P classification unless independent location-separation and stability gates also pass."]
    (val/"stage1c3b_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)
if __name__=="__main__": main()
