# Stage 1C3B v0.1.0 — weak-cluster morphology adjudication

This is a true-flat overlay for the existing project root after Stage 1C3.

Stage 1C3B touches only NGC 6101 and NGC 7078. The six Stage 1C3-supported probability files and model JSON files are protected by a frozen SHA-256 manifest; the run aborts if any one of them differs byte-for-byte from the local Stage 1C3 checkpoint.

The adjudication deliberately distinguishes **mixture evidence** from **population-centroid evidence**. A full-covariance GMM can win BIC merely because one component is broader than another. Such a covariance-driven partition is not accepted as 1P/2P unless an independent 1-D enrichment projection, centroid-separation, ambiguity, bootstrap, and split-half stability gates also pass.

No radius, sky position, or later density-slope information enters Stage 1C3B.

Run:

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1c3b_prepare_env.bat
call run_stage1c3b_selftest.bat
call run_stage1c3b.bat
```

Primary outputs:

- `outputs\stage1c3b\stage1c3b_adjudication_summary.csv`
- `outputs\stage1c3b\stage1c3b_decision_ledger.csv`
- `outputs\stage1c3b\stage1c3b_primary_probability_sample.csv`
- `outputs\stage1c3b\stage1c3b_supported_freeze_audit.csv`
- `validation\stage1c3b_preflight.json`
- `validation\stage1c3b_preflight.md`

Possible weak-cluster statuses are frozen in the protocol. `UNRESOLVED_PRIMARY_EXCLUSION` is a valid scientific outcome and must not be converted to a supported classifier by relaxing the gates.
