@echo off
setlocal
python scripts\stage1c3b_selftest.py || exit /b 1
python scripts\stage1c3b_adjudicate.py --root . || exit /b 1
python scripts\stage1c3b_preflight.py --root . || exit /b 1
echo STAGE1C3B: PASS
endlocal
