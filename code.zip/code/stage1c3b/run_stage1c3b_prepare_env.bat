@echo off
python -c "import numpy,pandas,scipy,sklearn,yaml; print('Stage1C3B environment: OK; scikit-learn='+sklearn.__version__)"
