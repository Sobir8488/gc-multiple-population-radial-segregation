@echo off
python scripts\stage1c3b_selftest.py
