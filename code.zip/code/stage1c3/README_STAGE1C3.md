# Stage 1C3 v0.1.0 — probabilistic chromosome-map classifier

This is a **true-flat overlay** for the existing project root after Stage 1C2 and Stage 1C2B have passed.

## Scientific scope

Stage 1C3 fits a radial-blind probabilistic classifier on the two frozen Stage 1C2 chromosome-map coordinates only:

- `delta_f275w_f814w`
- `delta_c_f275w_f336w_f438w`

The model is a tied-covariance Gaussian mixture with BIC-selected morphology complexity (`K=1..6`). Multiple Gaussian components are allowed so that a cluster such as NGC 2808 is not forced into exactly two Gaussian blobs.

The selected components are collapsed to two **photometric** super-groups by their chromosome-map enrichment direction. The higher-enrichment group is called `2P_LIKE`, following the established orientation in which 2P stars occupy higher Delta_C and generally lower Delta_X than 1P stars.

No radius, RA/Dec, cluster-centric distance, or downstream density information enters the classifier.

## Important claim boundary

`population_probability_2p` is a probability of membership in the photometric 2P-like chromosome-map group under this model. It is **not** a spectroscopic chemical-truth probability.

If the data do not support a multi-component mixture, a forced K=2 diagnostic can still be written, but the entire cluster is marked `WEAK_MODEL_*` and its probabilities are not authorized for the primary science analysis.

Stage 1C3 also does **not** yet transfer population probabilities to the wide-field Stetson catalogue. It exports only high-confidence HUGS/master-star anchors for the next transfer stage.


## Dependency note

Stage 1C3 uses `scikit-learn==1.8.0` for the tied-covariance Gaussian-mixture implementation. `run_stage1c3_prepare_env.bat` checks the dependency and installs the frozen version from conda-forge if it is absent.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1c3_prepare_env.bat
call run_stage1c3_selftest.bat
call run_stage1c3.bat
```

## Outputs

- `outputs/stage1c3/stage1c3_cluster_summary.csv`
- `outputs/stage1c3/stage1c3_model_selection.csv`
- `outputs/stage1c3/stage1c3_decision_ledger.csv`
- `outputs/stage1c3/stage1c3_sensitivity_summary.csv`
- `outputs/stage1c3/stage1c3_transfer_anchors.csv.gz`
- `outputs/stage1c3/clusters/<CLUSTER>/<CLUSTER>_population_probabilities.csv.gz`
- `outputs/stage1c3/clusters/<CLUSTER>/<CLUSTER>_model.json`
- `validation/stage1c3_preflight.{csv,json,md}`

A pipeline PASS means the software and provenance gates passed. It does not force every cluster to have a science-authorized binary population model.
