@echo off
python -c "import numpy,pandas,scipy,yaml" || exit /b 1
python -c "import sklearn; print('Stage1C3 scikit-learn:', sklearn.__version__)" >nul 2>&1
if errorlevel 1 (
  echo [Stage1C3] Installing frozen scikit-learn dependency...
  conda install -y -c conda-forge scikit-learn=1.8.0 || exit /b 1
)
python -c "import sklearn; print('Stage1C3 environment: OK; scikit-learn=' + sklearn.__version__)"
