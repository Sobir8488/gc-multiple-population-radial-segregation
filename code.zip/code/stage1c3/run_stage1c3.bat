@echo off
setlocal
python scripts\stage1c3_selftest.py || exit /b 1
python scripts\stage1c3_classifier.py --root . || exit /b 1
python scripts\stage1c3_preflight.py --root . || exit /b 1
echo STAGE1C3: PASS
endlocal
