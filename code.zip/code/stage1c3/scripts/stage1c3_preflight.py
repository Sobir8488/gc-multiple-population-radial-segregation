from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
from stage1c3_common import timestamp_utc, write_json

def add(rows,cluster,check,passed,severity,detail):
    rows.append({"cluster_id":cluster,"check":check,"passed":bool(passed),"severity":severity,"detail":detail})

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1c3_protocol.yaml").read_text(encoding="utf-8"))
    out=root/"outputs/stage1c3"
    s=pd.read_csv(out/"stage1c3_cluster_summary.csv")
    d=pd.read_csv(out/"stage1c3_decision_ledger.csv")
    rows=[]
    add(rows,"GLOBAL","all pilot clusters processed",set(s.cluster_id)==set(cfg["pilot_clusters"]),"ERROR",f"{len(s)}/8 summaries")
    # No radial features in output/model inputs.
    for cid in cfg["pilot_clusters"]:
        f=out/"clusters"/cid/f"{cid}_population_probabilities.csv.gz"
        ok=f.exists(); add(rows,cid,"probability catalogue exists",ok,"ERROR",str(f))
        if not ok: continue
        df=pd.read_csv(f)
        q=pd.to_numeric(df["population_probability_2p"],errors="coerce")
        add(rows,cid,"q2P finite and bounded",q.notna().all() and ((q>=0)&(q<=1)).all(),"ERROR","P(2P) must be in [0,1]")
        add(rows,cid,"master_star_id preserved",df["master_star_id"].notna().all(),"ERROR","Stage1B identity required")
        add(rows,cid,"label semantics explicit",(df["label_semantics"]=="PHOTOMETRIC_1P_LIKE_2P_LIKE").all(),"ERROR","No chemical-truth claim")
        forbidden=[c for c in cfg["features"]["forbidden_columns"] if c in [cfg["features"]["x_column"],cfg["features"]["c_column"]]]
        add(rows,cid,"radial/spatial features excluded from classifier",len(forbidden)==0,"ERROR","classifier uses only the two frozen chromosome-map coordinates")
        ss=s[s.cluster_id==cid].iloc[0]
        add(rows,cid,"probability row conservation",int(ss.n_rgb)==len(df),"ERROR",f"{len(df)}/{int(ss.n_rgb)}")
        if str(ss.classifier_status).startswith("SUPPORTED"):
            add(rows,cid,"supported model has K>=2",int(ss.selected_k_by_bic)>=2,"ERROR",f"K={int(ss.selected_k_by_bic)}")
            add(rows,cid,"supported model passes BIC gate",float(ss.delta_bic_k1_to_selected)>=float(cfg["support_gates"]["min_delta_bic_k1_to_selected"]),"ERROR",f"dBIC={ss.delta_bic_k1_to_selected}")
    nerr=sum((not r["passed"]) and r["severity"]=="ERROR" for r in rows)
    nsupp=int((s.classifier_status=="SUPPORTED_PHOTOMETRIC_1P2P").sum())
    nweak=len(s)-nsupp
    classifier_pipeline_ready=(nerr==0)
    population_probability_layer_ready=(nerr==0 and nweak==0)
    # This stage intentionally does not transfer labels to Stetson.
    science_ready=False
    disposition=("HUGS_CLASSIFIER_FROZEN_WIDEFIELD_TRANSFER_BLOCKED" if population_probability_layer_ready
                 else "PARTIAL_HUGS_CLASSIFIER_FREEZE_REFINEMENT_REQUIRED" if classifier_pipeline_ready
                 else "CLASSIFIER_PIPELINE_NOT_READY")
    retained=["wide-field HST-to-Stetson population-probability transfer",
              "detection completeness","classification completeness","footprint/effective-area masks"]
    obj={"stage":"Stage1C3","version":"0.1.0","generated_utc":timestamp_utc(),
         "classifier_pipeline_ready":classifier_pipeline_ready,
         "population_probability_layer_ready":population_probability_layer_ready,
         "science_ready":science_ready,"n_clusters":len(s),
         "n_clusters_supported":nsupp,"n_clusters_weak":nweak,
         "n_checks":len(rows),"n_error_failures":nerr,
         "n_retained_blockers":len(retained),"retained_blockers":retained,
         "disposition":disposition,
         "weak_clusters":s.loc[s.classifier_status!="SUPPORTED_PHOTOMETRIC_1P2P","cluster_id"].tolist()}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(rows).to_csv(val/"stage1c3_preflight.csv",index=False)
    write_json(val/"stage1c3_preflight.json",obj)
    md=["# Stage 1C3 preflight","",f"- Disposition: **{disposition}**",
        f"- Classifier pipeline ready: **{classifier_pipeline_ready}**",
        f"- Full 8-cluster probability layer ready: **{population_probability_layer_ready}**",
        f"- Supported clusters: **{nsupp}/{len(s)}**",
        f"- Error failures: **{nerr}**","",
        "## Cluster status"]
    for _,r in s.iterrows():
        md.append(f"- {r.cluster_id}: `{r.classifier_status}`; K={int(r.selected_k_by_bic)}; "
                  f"DeltaBIC={float(r.delta_bic_k1_to_selected):.2f}; ambiguous={float(r.fraction_ambiguous):.3f}")
    md += ["","## Claim boundary",
           "Probabilities are photometric 1P-like/2P-like assignments. They are not spectroscopic chemical truth. "
           "No radial coordinate was used by the classifier, and wide-field Stetson transfer has not yet been performed."]
    (val/"stage1c3_preflight.md").write_text("\n".join(md)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)
if __name__=="__main__": main()
