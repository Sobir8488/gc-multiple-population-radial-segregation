from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
sys.path.insert(0,str(Path(__file__).parent))
from stage1c3_classifier import classify_one, gate_status, hard_category

root=Path(__file__).resolve().parents[1]
cfg=yaml.safe_load((root/"config/stage1c3_protocol.yaml").read_text(encoding="utf-8"))
rng=np.random.default_rng(12345)
# Strong synthetic chromosome map: high-C/low-X group must orient as 2P-like.
n1,n2=450,650
x1=rng.normal(0.02,0.05,n1); c1=rng.normal(0.02,0.045,n1)
x2=rng.normal(-0.18,0.07,n2); c2=rng.normal(0.22,0.06,n2)
df=pd.DataFrame({cfg["features"]["x_column"]:np.r_[x1,x2],
                 cfg["features"]["c_column"]:np.r_[c1,c2]})
r=classify_one(df,cfg,1.0,0); status,fail=gate_status(r,cfg)
assert status=="SUPPORTED_PHOTOMETRIC_1P2P",(status,fail)
assert r["delta_c"]>0 and r["delta_x"]<0
q=r["qfull"]; truth=np.r_[np.zeros(n1,dtype=int),np.ones(n2,dtype=int)]
acc=np.mean((q>=0.5)==truth)
assert acc>0.92,acc
# Radial columns must be irrelevant.
df2=df.copy(); df2["ra_deg"]=rng.uniform(0,360,len(df2)); df2["radius"]=rng.uniform(0,10,len(df2))
r2=classify_one(df2,cfg,1.0,0)
assert np.median(np.abs(r2["qfull"]-q))<1e-10
# Unimodal fixture should not be authorized as a supported 1P/2P split.
u=pd.DataFrame({cfg["features"]["x_column"]:rng.normal(0,0.08,1000),
                cfg["features"]["c_column"]:rng.normal(0,0.08,1000)})
ru=classify_one(u,cfg,1.0,0); su,_=gate_status(ru,cfg)
assert su!="SUPPORTED_PHOTOMETRIC_1P2P"
print("STAGE1C3_SELFTEST: PASS")
