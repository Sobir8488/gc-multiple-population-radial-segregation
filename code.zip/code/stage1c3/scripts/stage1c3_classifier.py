from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
from sklearn.mixture import GaussianMixture
from stage1c3_common import sha256_file, write_json


def robust_loc_scale(X):
    med=np.nanmedian(X,axis=0)
    q25=np.nanquantile(X,0.25,axis=0); q75=np.nanquantile(X,0.75,axis=0)
    scale=(q75-q25)/1.349
    sd=np.nanstd(X,axis=0)
    scale=np.where(np.isfinite(scale)&(scale>1e-8),scale,np.where(sd>1e-8,sd,1.0))
    return med,scale


def fit_best(X,cfg,seed_offset=0):
    mix=cfg['mixture']; fits=[]
    for k in range(int(mix['min_components']),int(mix['max_components'])+1):
        gm=GaussianMixture(
            n_components=k,covariance_type='tied',
            reg_covar=float(mix['covariance_floor']),
            n_init=int(mix['n_initializations']),
            max_iter=int(mix['max_iterations']),
            tol=float(mix['tolerance']),
            random_state=int(mix['random_seed'])+int(seed_offset)+1009*k,
            init_params='kmeans')
        gm.fit(X)
        # Reject non-converged or tiny-component solutions: these typically
        # represent outlier capture rather than a stable chromosome-map group.
        if (not bool(gm.converged_)) or float(np.min(gm.weights_)) < float(mix['min_component_weight']):
            continue
        fits.append({'k':k,'bic':float(gm.bic(X)),'loglik':float(gm.score(X)*len(X)),
                     'iterations':int(gm.n_iter_),'model':gm})
    if not fits: raise RuntimeError('No converged mixture survived the component-weight gate')
    selected=min(fits,key=lambda z:z['bic'])
    return selected,fits


def binary_split(component_scores,weights,min_group_weight):
    order=np.argsort(component_scores); best=None
    for cut in range(1,len(order)):
        lo=order[:cut]; hi=order[cut:]
        wl=float(weights[lo].sum()); wh=float(weights[hi].sum())
        if wl<min_group_weight or wh<min_group_weight: continue
        ml=float(np.sum(weights[lo]*component_scores[lo])/wl)
        mh=float(np.sum(weights[hi]*component_scores[hi])/wh)
        sse=float(np.sum(weights[lo]*(component_scores[lo]-ml)**2)+np.sum(weights[hi]*(component_scores[hi]-mh)**2))
        if best is None or sse<best['sse']:
            best={'sse':sse,'low':lo.tolist(),'high':hi.tolist(),'low_mean':ml,'high_mean':mh,
                  'low_weight':wl,'high_weight':wh}
    return best


def classify_one(df,cfg,x_weight=1.0,seed_offset=0):
    xcol=cfg['features']['x_column']; ccol=cfg['features']['c_column']
    xv=pd.to_numeric(df[xcol],errors='coerce'); cv=pd.to_numeric(df[ccol],errors='coerce')
    good=np.isfinite(xv.to_numpy()) & np.isfinite(cv.to_numpy())
    if good.sum()<50: raise ValueError('Fewer than 50 finite chromosome-map rows')
    Xraw=np.c_[xv.to_numpy()[good],cv.to_numpy()[good]]
    med,scale=robust_loc_scale(Xraw); Z=(Xraw-med)/scale; Zw=Z.copy(); Zw[:,0]*=float(x_weight)
    selected,fits=fit_best(Zw,cfg,seed_offset)
    bic1=next(f['bic'] for f in fits if f['k']==1); delta_bic=float(bic1-selected['bic'])
    model_entry=selected; forced=False
    if selected['k']==1:
        model_entry=next(f for f in fits if f['k']==2); forced=True
    gm=model_entry['model']; resp=gm.predict_proba(Zw)
    sem_means=gm.means_.copy();
    if x_weight!=0: sem_means[:,0]/=float(x_weight)
    ecfg=cfg['features']['enrichment_score']
    scores=float(ecfg['c_weight'])*sem_means[:,1]+float(ecfg['x_weight'])*sem_means[:,0]
    split=binary_split(scores,gm.weights_,float(cfg['binary_grouping']['min_group_weight']))
    if split is None: raise RuntimeError('Could not form two semantic groups')
    q=np.clip(resp[:,split['high']].sum(axis=1),0.0,1.0); qfull=np.full(len(df),np.nan); qfull[good]=q
    rawmeans=sem_means*scale+med
    def gmean(ids,dim):
        ids=np.asarray(ids,int); ww=gm.weights_[ids]; ww=ww/ww.sum(); return float(np.sum(ww*rawmeans[ids,dim]))
    dx=gmean(split['high'],0)-gmean(split['low'],0); dc=gmean(split['high'],1)-gmean(split['low'],1)
    lo=float(cfg['probability']['confident_1p_max_q2p']); hi=float(cfg['probability']['confident_2p_min_q2p'])
    amb=float(np.mean((q>lo)&(q<hi)))
    return {'good_mask':good,'qfull':qfull,'q':q,'selected':selected,'model_for_q':model_entry,
            'fits':fits,'forced_k2':forced,'delta_bic':delta_bic,'split':split,
            'group_gap':float(split['high_mean']-split['low_mean']),'delta_x':dx,'delta_c':dc,
            'ambiguous_fraction':amb,'med':med,'scale':scale,'x_weight':float(x_weight),
            'component_scores':scores,'raw_component_means':rawmeans}


def hard_category(q,cfg):
    lo=float(cfg['probability']['confident_1p_max_q2p']); hi=float(cfg['probability']['confident_2p_min_q2p'])
    out=np.full(len(q),'NO_PROBABILITY',dtype=object); finite=np.isfinite(q)
    out[finite&(q<=lo)]='1P_LIKE'; out[finite&(q>=hi)]='2P_LIKE'; out[finite&(q>lo)&(q<hi)]='AMBIGUOUS'
    return out


def gate_status(r,cfg):
    g=cfg['support_gates']; failures=[]
    if r['selected']['k']<2: failures.append('SELECTED_K1')
    if r['delta_bic']<float(g['min_delta_bic_k1_to_selected']): failures.append('WEAK_BIC_EVIDENCE')
    if r['group_gap']<float(g['min_group_enrichment_gap_robust_units']): failures.append('LOW_SEMANTIC_GROUP_GAP')
    if r['ambiguous_fraction']>float(g['max_ambiguous_fraction']): failures.append('HIGH_AMBIGUITY')
    if min(r['split']['low_weight'],r['split']['high_weight'])<float(g['min_binary_group_weight']): failures.append('SMALL_BINARY_GROUP')
    if bool(g['require_positive_delta_c_2p_minus_1p']) and not (r['delta_c']>0): failures.append('ORIENTATION_DELTA_C_FAILED')
    return ('SUPPORTED_PHOTOMETRIC_1P2P' if not failures else 'WEAK_MODEL_'+'+'.join(failures)),failures


def compare_q(q1,q2,cfg):
    f=np.isfinite(q1)&np.isfinite(q2)
    if not np.any(f): return {'median_abs_probability_change':np.nan,'hard_label_agreement':np.nan}
    return {'median_abs_probability_change':float(np.median(np.abs(q1[f]-q2[f]))),
            'hard_label_agreement':float(np.mean((q1[f]>=0.5)==(q2[f]>=0.5)))}


def model_json(r,status,failures):
    gm=r['model_for_q']['model']
    return {'stage':'Stage1C3','version':'0.1.0','status':status,'gate_failures':failures,
            'selected_k_by_bic':int(r['selected']['k']),'probability_model_k':int(r['model_for_q']['k']),
            'forced_k2_diagnostic':bool(r['forced_k2']),'delta_bic_k1_to_selected':r['delta_bic'],
            'x_weight':r['x_weight'],'robust_location':r['med'].tolist(),'robust_scale':r['scale'].tolist(),
            'weights':gm.weights_.tolist(),'means_weighted_robust':gm.means_.tolist(),
            'covariance_tied':gm.covariances_.tolist(),'component_enrichment_scores':r['component_scores'].tolist(),
            'components_1p_like':r['split']['low'],'components_2p_like':r['split']['high'],
            'group_enrichment_gap':r['group_gap'],'delta_x_2p_minus_1p':r['delta_x'],
            'delta_c_2p_minus_1p':r['delta_c'],'ambiguous_fraction':r['ambiguous_fraction'],
            'label_semantics':'photometric 1P-like/2P-like; not spectroscopic chemical truth'}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); args=ap.parse_args(); root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/'config/stage1c3_protocol.yaml').read_text(encoding='utf-8'))
    p2=json.loads((root/cfg['upstream']['stage1c2_preflight']).read_text(encoding='utf-8'))
    p2b=json.loads((root/cfg['upstream']['stage1c2b_preflight']).read_text(encoding='utf-8'))
    if not p2.get('rgb_verticalisation_ready',False): raise SystemExit('Stage1C2 is not ready')
    if not p2b.get('stage1c3_authorized',False): raise SystemExit('Stage1C2B has not authorized Stage1C3')
    out=root/'outputs/stage1c3'; out.mkdir(parents=True,exist_ok=True)
    summaries=[]; modelsels=[]; decisions=[]; anchors=[]; sensrows=[]
    for cid in cfg['pilot_clusters']:
        df=pd.read_csv(root/cfg['upstream']['rgb_verticalised_pattern'].format(cluster=cid))
        primary=classify_one(df,cfg,float(cfg['features']['primary_x_weight']),0); status,failures=gate_status(primary,cfg)
        # deterministic replay checks
        replay=[]
        if cfg['sensitivity']['seed_replay'].get('enabled',False):
            for j,_ in enumerate(cfg['sensitivity']['seed_replay']['seeds']):
                rr=classify_one(df,cfg,float(cfg['features']['primary_x_weight']),(j+1)*100000)
                replay.append(compare_q(primary['qfull'],rr['qfull'],cfg))
        seed_med=max((x['median_abs_probability_change'] for x in replay), default=0.0)
        seed_agree=min((x['hard_label_agreement'] for x in replay), default=1.0)
        ngc_mad=np.nan; ngc_agree=np.nan
        if cid=='NGC3201' and cfg['sensitivity']['ngc3201']['enabled']:
            rr=classify_one(df,cfg,float(cfg['sensitivity']['ngc3201']['x_weight_replay']),500000)
            cm=compare_q(primary['qfull'],rr['qfull'],cfg); ngc_mad=cm['median_abs_probability_change']; ngc_agree=cm['hard_label_agreement']
            sensrows.append({'cluster_id':cid,'replay':'C_DOMINANT_X_DOWNWEIGHTED','x_weight':cfg['sensitivity']['ngc3201']['x_weight_replay'],
                             'selected_k':rr['selected']['k'],'delta_bic_k1_to_selected':rr['delta_bic'],**cm})
        stability_fail=[]; sr=cfg['sensitivity']['seed_replay']
        if seed_med>float(sr['max_median_abs_probability_change']): stability_fail.append('SEED_PROBABILITY_INSTABILITY')
        if seed_agree<float(sr['min_hard_label_agreement']): stability_fail.append('SEED_HARD_LABEL_INSTABILITY')
        if cid=='NGC3201':
            ng=cfg['sensitivity']['ngc3201']
            if ngc_mad>float(ng['max_median_abs_probability_change']): stability_fail.append('NGC3201_XWEIGHT_PROBABILITY_INSTABILITY')
            if ngc_agree<float(ng['min_hard_label_agreement']): stability_fail.append('NGC3201_XWEIGHT_HARD_LABEL_INSTABILITY')
        if stability_fail and status.startswith('SUPPORTED'):
            failures+=stability_fail; status='WEAK_MODEL_'+'+'.join(failures)
        od=out/'clusters'/cid; od.mkdir(parents=True,exist_ok=True)
        prob=df[['cluster_id','master_star_id','source_row_id','p_cluster_member',cfg['features']['x_column'],cfg['features']['c_column']]].copy()
        prob['population_probability_2p']=primary['qfull']; prob['population_probability_1p']=1-prob['population_probability_2p']
        prob['population_label_provisional']=hard_category(primary['qfull'],cfg); prob['cluster_classifier_status']=status
        prob['label_semantics']='PHOTOMETRIC_1P_LIKE_2P_LIKE'; prob['classifier_version']='Stage1C3_v0.1.0'
        prob.to_csv(od/f'{cid}_population_probabilities.csv.gz',index=False,compression='gzip')
        write_json(od/f'{cid}_model.json',model_json(primary,status,failures))
        for f in primary['fits']:
            modelsels.append({'cluster_id':cid,'k':f['k'],'bic':f['bic'],'loglik':f['loglik'],'iterations':f['iterations'],'selected_by_bic':f['k']==primary['selected']['k']})
        q=primary['qfull']; fq=q[np.isfinite(q)]
        summaries.append({'cluster_id':cid,'n_rgb':len(df),'n_probability':len(fq),'selected_k_by_bic':primary['selected']['k'],
            'probability_model_k':primary['model_for_q']['k'],'forced_k2_diagnostic':primary['forced_k2'],
            'delta_bic_k1_to_selected':primary['delta_bic'],'group_enrichment_gap':primary['group_gap'],
            'delta_x_2p_minus_1p':primary['delta_x'],'delta_c_2p_minus_1p':primary['delta_c'],
            'fraction_1p_confident':float(np.mean(fq<=cfg['probability']['confident_1p_max_q2p'])),
            'fraction_2p_confident':float(np.mean(fq>=cfg['probability']['confident_2p_min_q2p'])),
            'fraction_ambiguous':primary['ambiguous_fraction'],'mean_q2p':float(np.mean(fq)),
            'seed_replay_max_median_abs_dq':seed_med,'seed_replay_min_hard_agreement':seed_agree,
            'ngc3201_xweight_median_abs_dq':ngc_mad,'ngc3201_xweight_hard_agreement':ngc_agree,'classifier_status':status})
        decisions.append({'cluster_id':cid,'classifier_status':status,'probability_claim_authorized':status=='SUPPORTED_PHOTOMETRIC_1P2P',
                          'gate_failures':';'.join(failures),'widefield_transfer_status':'ANCHORS_ONLY_NOT_TRANSFERRED'})
        mask=(prob.population_probability_2p<=cfg['probability']['transfer_anchor_1p_max_q2p'])|(prob.population_probability_2p>=cfg['probability']['transfer_anchor_2p_min_q2p'])
        if status=='SUPPORTED_PHOTOMETRIC_1P2P':
            aa=prob.loc[mask].copy(); aa['anchor_label']=np.where(aa.population_probability_2p>=cfg['probability']['transfer_anchor_2p_min_q2p'],'2P_LIKE','1P_LIKE'); anchors.append(aa)
        print(f"[Stage1C3] {cid}: K={primary['selected']['k']} dBIC={primary['delta_bic']:.2f} amb={primary['ambiguous_fraction']:.3f} status={status}")
    pd.DataFrame(summaries).to_csv(out/'stage1c3_cluster_summary.csv',index=False)
    pd.DataFrame(modelsels).to_csv(out/'stage1c3_model_selection.csv',index=False)
    pd.DataFrame(decisions).to_csv(out/'stage1c3_decision_ledger.csv',index=False)
    pd.DataFrame(sensrows).to_csv(out/'stage1c3_sensitivity_summary.csv',index=False)
    (pd.concat(anchors,ignore_index=True) if anchors else pd.DataFrame()).to_csv(out/'stage1c3_transfer_anchors.csv.gz',index=False,compression='gzip')
    rows=[]
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.name!='stage1c3_output_manifest.csv': rows.append({'path':str(p.relative_to(out)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha256_file(p)})
    pd.DataFrame(rows).to_csv(out/'stage1c3_output_manifest.csv',index=False)
    print(f"[Stage1C3] completed {len(summaries)} clusters; supported={sum(x['classifier_status']=='SUPPORTED_PHOTOMETRIC_1P2P' for x in summaries)}")

if __name__=='__main__': main()
