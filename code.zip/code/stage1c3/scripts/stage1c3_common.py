from __future__ import annotations
from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

def package_root(path=None):
    return Path(path or ".").resolve()

def timestamp_utc():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def write_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=False),encoding="utf-8")
