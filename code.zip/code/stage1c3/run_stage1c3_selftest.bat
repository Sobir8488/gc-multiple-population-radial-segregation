@echo off
python scripts\stage1c3_selftest.py
