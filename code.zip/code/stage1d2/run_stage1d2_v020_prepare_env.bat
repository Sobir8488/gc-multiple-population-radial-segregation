@echo off
python -c "import numpy,pandas,scipy,yaml; print('Stage1D2 v0.2.0 environment: OK')"
