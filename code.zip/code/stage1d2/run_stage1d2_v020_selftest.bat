@echo off
python scripts\stage1d2_v020_selftest.py
