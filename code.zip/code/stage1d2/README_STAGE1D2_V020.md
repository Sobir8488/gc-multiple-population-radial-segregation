# Stage 1D2 v0.2.0 — nullspace-aware conditional Delta-gamma science inference

**Use this package, not the earlier Stage 1D2 v0.1.0 package.**

Stage 1D1B2 closed the smoothness boundary by selecting the exact `PENALTY_NULLSPACE_LIMIT` for all six clusters. Stage 1D2 v0.2.0 therefore uses that state as the authoritative observed and bootstrap model.

The original Stage 1D1B science machinery remains in force:
- continuous q2P fractional-Bernoulli likelihood;
- q05-q95 fit support and q10-q90 claim support;
- 500 latent-label radial-stratified bootstraps;
- 300 soft-q bootstraps;
- simultaneous 95% derivative bands;
- 999 q2P-radius permutations;
- Benjamini-Hochberg FDR across six clusters;
- leave-one-radial-quintile-out stability.

For the permutation null test, smoothness is still reselected in every permutation. The candidate set is the original 17 finite lambdas plus the exact penalty-nullspace limit as the terminal smoothness candidate.

Because the primary state is lambda=infinity, the original multiplicative lambda-sensitivity audit is mathematically undefined. The replacement is fixed *before* science execution: compare the nullspace primary result with the two strongest finite members already present in the frozen grid (`1e4` and `3162.2776601683795`) and with nullspace fits using Kint-1/Kint/Kint+1.

The run is resumable; bootstrap and permutation arrays are checkpointed inside each cluster directory.

## Recommended cluster-by-cluster production run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a

call run_stage1d2_v020_prepare_env.bat
call run_stage1d2_v020_selftest.bat
call run_stage1d2_v020_input_preflight.bat

call run_stage1d2_v020_cluster.bat NGC2808
call run_stage1d2_v020_cluster.bat NGC5024
call run_stage1d2_v020_cluster.bat NGC5272
call run_stage1d2_v020_cluster.bat NGC3201
call run_stage1d2_v020_cluster.bat NGC5904
call run_stage1d2_v020_cluster.bat NGC6205

call run_stage1d2_v020_finalize.bat
```

You can rerun an interrupted cluster command; completed bootstrap/permutation checkpoints are reused.

Do not use the earlier `run_stage1d2.bat` from v0.1.0.
