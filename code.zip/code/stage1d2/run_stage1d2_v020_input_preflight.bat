@echo off
python scripts\stage1d2_v020_input_preflight.py --root .
