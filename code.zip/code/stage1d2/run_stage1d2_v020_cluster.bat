@echo off
setlocal
if "%~1"=="" (echo Usage: run_stage1d2_v020_cluster.bat NGC2808 & exit /b 2)
python scripts\stage1d2_v020_science.py --root . --cluster %~1 --mode full
endlocal
