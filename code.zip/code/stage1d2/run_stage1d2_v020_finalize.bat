@echo off
python scripts\stage1d2_v020_finalize.py --root .
