@echo off
setlocal
python scripts\stage1d2_v020_selftest.py || exit /b 1
python scripts\stage1d2_v020_input_preflight.py --root . || exit /b 1
python scripts\stage1d2_v020_science.py --root . --cluster ALL --mode full || exit /b 1
python scripts\stage1d2_v020_finalize.py --root . || exit /b 1
echo STAGE1D2_V020: PASS
endlocal
