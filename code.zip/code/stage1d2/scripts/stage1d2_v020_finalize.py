
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from stage1d2_v020_common import sha256_file, utcnow, write_json

def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p)
    r=p[o]*n/np.arange(1,n+1)
    r=np.minimum.accumulate(r[::-1])[::-1]
    q=np.empty(n,float); q[o]=np.clip(r,0,1)
    return q

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    e=yaml.safe_load((root/"config/stage1d2_execution_v020.yaml").read_text(encoding="utf-8"))
    out=root/"outputs/stage1d2_v020"; rows=[]; missing=[]
    for cid in e["clusters"]:
        p=out/"clusters"/cid/f"{cid}_science_summary.json"
        if not p.exists(): missing.append(cid)
        else: rows.append(json.loads(p.read_text(encoding="utf-8")))
    if missing: raise SystemExit("Missing completed clusters: "+",".join(missing))
    df=pd.DataFrame(rows); df["bh_q_value"]=bh(df.permutation_p_value)
    status=[]
    for _,r in df.iterrows():
        if not bool(r.all_method_stability_pass):
            st=e["final_statuses"]["unstable"]
        elif float(r.bh_q_value)<0.05:
            st=e["final_statuses"]["detected"]
        else:
            st=e["final_statuses"]["null"]
        status.append(st)
    df["global_bh_fdr_significant"]=df.bh_q_value<0.05
    df["final_status"]=status
    df.to_csv(out/"stage1d2_cluster_summary.csv",index=False)
    nrob=int(np.sum(df.final_status==e["final_statuses"]["detected"]))
    nnull=int(np.sum(df.final_status==e["final_statuses"]["null"]))
    nunst=int(np.sum(df.final_status==e["final_statuses"]["unstable"]))
    obj={
      "stage":"Stage1D2","version":"0.2.0","generated_utc":utcnow(),
      "science_inference_complete":True,
      "n_clusters":6,
      "n_robust_differential_structure":nrob,
      "n_consistent_with_no_resolved_differential_slope":nnull,
      "n_method_sensitive":nunst,
      "absolute_density_slopes_ready":False,
      "science_ready_for_next_validation":True,
      "next_required_stage":"Stage1D3 2D azimuthal/non-axisymmetry and spatial-systematics audit",
      "disposition":"CONDITIONAL_DELTA_GAMMA_SCIENCE_COMPLETE_2D_VALIDATION_REQUIRED"
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    write_json(val/"stage1d2_v020_preflight.json",obj)
    lines=["# Stage 1D2 v0.2.0 science summary","",
           f"- Robust differential structure: **{nrob}/6**",
           f"- No resolved differential slope: **{nnull}/6**",
           f"- Method-sensitive: **{nunst}/6**",
           "- Absolute density slopes ready: **False**","","## Cluster results"]
    for _,r in df.iterrows():
        lines.append(
          f"- {r.cluster_id}: `{r.final_status}`; D_diff={r.D_diff:.4f}, S_diff={r.S_diff:.4f}, "
          f"R_peak={r.R_peak_arcsec:.2f} arcsec, p={r.permutation_p_value:.4g}, q_BH={r.bh_q_value:.4g}, "
          f"local-band={bool(r.local_simultaneous_band_gate_pass)}, stable={bool(r.all_method_stability_pass)}."
        )
    lines += ["","Stage1D3 remains mandatory before final axisymmetric manuscript claims."]
    (val/"stage1d2_v020_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d2_output_manifest.csv":
            manifest.append({"path":str(p.relative_to(out)).replace("\\","/"),
                             "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1d2_output_manifest.csv",index=False)

if __name__=="__main__": main()
