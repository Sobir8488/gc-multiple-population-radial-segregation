
import numpy as np
from scipy.interpolate import BSpline
n=10
D2=np.diff(np.eye(n),n=2,axis=0); P=D2.T@D2
w,V=np.linalg.eigh(P); N=V[:,w<1e-9]
assert N.shape==(n,2)
degree=3
xlo,xhi=-2,2
interior=np.linspace(xlo,xhi,7+2)[1:-1]
knots=np.r_[np.repeat(xlo,degree+1),interior,np.repeat(xhi,degree+1)]
ncoef=len(knots)-degree-1
assert ncoef==11
print("STAGE1D2_V020_SELFTEST: PASS")
