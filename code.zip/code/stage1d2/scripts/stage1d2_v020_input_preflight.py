
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from stage1d2_v020_common import sha256_file, utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    e=yaml.safe_load((root/"config/stage1d2_execution_v020.yaml").read_text(encoding="utf-8"))
    p=root/"config/stage1d1b_protocol.yaml"
    b2=json.loads((root/"validation/stage1d1b2_preflight.json").read_text(encoding="utf-8"))
    checks=[]
    def add(n,v,d): checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("Stage1D1B protocol hash",sha256_file(p)==e["required_stage1d1b_protocol_sha256"],sha256_file(p))
    add("Stage1D1B2 disposition",b2.get("disposition")==e["required_stage1d1b2_disposition"],b2.get("disposition",""))
    states=b2.get("selected_smoothing_states",{})
    add("six nullspace states",all(states.get(c)==e["required_smoothing_state"] for c in e["clusters"]),str(states))
    ready=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_readiness_summary.csv")
    add("six science designs ready",ready.protocol_ready_for_science_fit.all(),f"{int(ready.protocol_ready_for_science_fit.sum())}/6")
    nerr=sum(not x["passed"] for x in checks)
    obj={"stage":"Stage1D2","version":"0.2.0","generated_utc":utcnow(),
         "production_input_ready":nerr==0,"science_fit_performed":False,
         "n_checks":len(checks),"n_error_failures":nerr,
         "disposition":"STAGE1D2_V020_INPUT_READY" if nerr==0 else "STAGE1D2_V020_INPUT_NOT_READY"}
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d2_v020_input_preflight.csv",index=False)
    write_json(val/"stage1d2_v020_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)
if __name__=="__main__": main()
