
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit
from stage1d2_v020_common import sha256_file, utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def basis(x,knots,degree,deriv=0):
    n=len(knots)-degree-1; eye=np.eye(n)
    cols=[]
    for j in range(n):
        s=BSpline(knots,eye[j],degree,extrapolate=False)
        if deriv: s=s.derivative(deriv)
        cols.append(s(np.asarray(x,float)))
    return np.column_stack(cols)

def penalty(n):
    D=np.diff(np.eye(n),n=2,axis=0)
    return D.T@D

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P)
    N=V[:,w<tol]
    if N.shape[1]!=2:
        raise RuntimeError(f"Expected penalty nullspace dimension 2, got {N.shape[1]}")
    return N

def fit_unpen(B,y,beta0=None,maxiter=80,tol=1e-9):
    y=np.asarray(y,float)
    if beta0 is None:
        m=float(np.clip(np.mean(y),1e-6,1-1e-6))
        b=np.zeros(B.shape[1],float); b[0]=math.log(m/(1-m))
    else:
        b=np.asarray(beta0,float).copy()
    last=np.inf
    for _ in range(maxiter):
        eta=B@b; p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta))
        g=B.T@(p-y); H=B.T@(w[:,None]*B)+1e-10*np.eye(B.shape[1])
        step=np.linalg.solve(H,g)
        alpha=1.0
        for _ in range(25):
            c=b-alpha*step
            e=B@c
            co=float(np.sum(np.logaddexp(0,e)-y*e))
            if co<=obj+1e-12:
                b=c; last=co; break
            alpha*=0.5
        if np.max(np.abs(alpha*step))<tol: break
    return b

def fit_pen(B,y,lam,P,beta0=None,maxiter=80,tol=1e-9):
    y=np.asarray(y,float)
    if beta0 is None:
        m=float(np.clip(np.mean(y),1e-6,1-1e-6))
        b=np.zeros(B.shape[1],float); b[0]=math.log(m/(1-m))
    else:
        b=np.asarray(beta0,float).copy()
    for _ in range(maxiter):
        eta=B@b; p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta)+0.5*lam*(b@P@b))
        g=B.T@(p-y)+lam*(P@b)
        H=B.T@(w[:,None]*B)+lam*P+1e-10*np.eye(B.shape[1])
        step=np.linalg.solve(H,g)
        alpha=1.0
        for _ in range(25):
            c=b-alpha*step
            e=B@c
            co=float(np.sum(np.logaddexp(0,e)-y*e)+0.5*lam*(c@P@c))
            if co<=obj+1e-12:
                b=c; break
            alpha*=0.5
        if np.max(np.abs(alpha*step))<tol: break
    return b

def mean_loss(B,y,b):
    eta=B@b
    return float(np.mean(np.logaddexp(0,eta)-y*eta))

def dedup(prob,master):
    rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        rows.append({"master_star_id":mid,"q2p":float(np.mean(num(g.population_probability_2p)))})
    d=pd.DataFrame(rows)
    m=master[["master_star_id","x_common_arcsec","y_common_arcsec"]].drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    d["radius_arcsec"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    return d

def load_design(root,cid,p1cfg):
    prob=pd.read_csv(root/p1cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
    master=pd.read_csv(root/p1cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
    d=dedup(prob,master)
    ready=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_readiness_summary.csv")
    r=ready.loc[ready.cluster_id==cid].iloc[0]
    knots_df=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_frozen_knots.csv")
    knots=knots_df.loc[knots_df.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
    folds_df=pd.read_csv(root/"outputs/stage1d1b/stage1d1b_frozen_cv_folds.csv.gz")
    ff=folds_df.loc[folds_df.cluster_id==cid].set_index("master_star_id")
    R=d.radius_arcsec.to_numpy(float); q=d.q2p.to_numpy(float)
    fit=(R>=float(r.r_fit_q05_arcsec))&(R<=float(r.r_fit_q95_arcsec))
    Rref=float(r.R_ref_arcsec); x=np.log(R/Rref)
    mids=d.loc[fit,"master_star_id"].astype(str).tolist()
    folds=np.array([int(ff.loc[m,"cv_fold"]) for m in mids],int)
    degree=int(p1cfg["model"]["degree"])
    B=basis(x[fit],knots,degree,0); P=penalty(B.shape[1]); N=nullspace(P)
    B0=B@N
    gx=np.linspace(np.log(float(r.r_claim_q10_arcsec)/Rref),
                   np.log(float(r.r_claim_q90_arcsec)/Rref),
                   int(p1cfg["model"]["grid_points"]))
    Bg=basis(gx,knots,degree,0); Dg=basis(gx,knots,degree,1)
    return d,q,fit,x,folds,knots,B,P,N,B0,gx,Bg,Dg,Rref,Rref*np.exp(gx),r

def cv_candidate_scan(B,P,N,y,folds,lambdas):
    rows=[]
    for lam in lambdas:
        losses=[]
        for f in range(5):
            tr=folds!=f; te=~tr
            b=fit_pen(B[tr],y[tr],float(lam),P)
            losses.append(mean_loss(B[te],y[te],b))
        rows.append({"candidate":"FINITE","lambda":float(lam),
                     "mean_loss":float(np.mean(losses)),
                     "se":float(np.std(losses,ddof=1)/np.sqrt(5))})
    B0=B@N
    losses=[]
    for f in range(5):
        tr=folds!=f; te=~tr
        th=fit_unpen(B0[tr],y[tr])
        losses.append(mean_loss(B0[te],y[te],th))
    rows.append({"candidate":"NULLSPACE","lambda":np.inf,
                 "mean_loss":float(np.mean(losses)),
                 "se":float(np.std(losses,ddof=1)/np.sqrt(5))})
    tab=pd.DataFrame(rows)
    finite=tab.loc[tab.candidate=="FINITE"]
    j=finite.mean_loss.idxmin()
    threshold=float(tab.loc[j,"mean_loss"]+tab.loc[j,"se"])
    nullrow=tab.loc[tab.candidate=="NULLSPACE"].iloc[0]
    if float(nullrow.mean_loss)<=threshold+1e-15:
        state="PENALTY_NULLSPACE_LIMIT"
    else:
        elig=finite.loc[finite.mean_loss<=threshold+1e-15]
        state=f"LAMBDA_{float(elig['lambda'].max()):g}"
    return tab,state,threshold

def state_fit(B,P,N,y,state):
    if state=="PENALTY_NULLSPACE_LIMIT":
        B0=B@N; th=fit_unpen(B0,y)
        return ("NULLSPACE",th)
    lam=float(state.split("_",1)[1])
    return ("FINITE",fit_pen(B,y,lam,P))

def state_profile(kind,coef,Bg,Dg,N):
    if kind=="NULLSPACE":
        eta=(Bg@N)@coef; dg=-((Dg@N)@coef)
    else:
        eta=Bg@coef; dg=-(Dg@coef)
    return eta,expit(eta),dg

def diag(dg,gx,gR):
    S=float(np.sqrt(np.mean(dg*dg))); D=float(np.mean(dg))
    j=int(np.argmax(np.abs(dg))); Rp=float(gR[j])
    T=float(np.trapezoid(dg*dg,gx)/(gx[-1]-gx[0]))
    return S,D,Rp,T

def strata_draw(rng,x,nstrata=10):
    order=np.argsort(x,kind="mergesort")
    s=np.empty(len(x),int); s[order]=np.clip(np.floor(np.arange(len(x))*nstrata/len(x)).astype(int),0,nstrata-1)
    return np.concatenate([rng.choice(np.where(s==k)[0],size=np.sum(s==k),replace=True) for k in range(nstrata)])

def bootstrap_nullspace(B0,D0,y,x,nrep,seed,latent):
    rng=np.random.default_rng(seed)
    out=np.empty((nrep,D0.shape[0]),float)
    for j in range(nrep):
        idx=strata_draw(rng,x,10)
        yy=y[idx]
        if latent:
            yy=rng.binomial(1,np.clip(yy,0,1)).astype(float)
        th=fit_unpen(B0[idx],yy)
        out[j]=-(D0@th)
    return out

def zero_exclusion_width(lo,hi,gx):
    sig=(lo>0)|(hi<0)
    best=0.0; sign=0
    i=0
    while i<len(sig):
        if not sig[i]: i+=1; continue
        s=1 if lo[i]>0 else -1; j=i
        while j+1<len(sig) and sig[j+1] and ((lo[j+1]>0)==(s>0)): j+=1
        w=float(gx[j]-gx[i])
        if w>best: best=w; sign=s
        i=j+1
    return best,sign

def nullspace_with_knot_count(x,y,fit,gx,kint,degree):
    xf=x[fit]; xlo=float(np.min(xf)); xhi=float(np.max(xf))
    interior=np.linspace(xlo,xhi,int(kint)+2)[1:-1]
    knots=np.r_[np.repeat(xlo,degree+1),interior,np.repeat(xhi,degree+1)]
    B=basis(xf,knots,degree,0); P=penalty(B.shape[1]); N=nullspace(P)
    th=fit_unpen(B@N,y[fit])
    D=basis(gx,knots,degree,1)@N
    if not np.isfinite(D).all(): return None
    return -(D@th)

def stability(d,q,fit,x,B,P,N,gx,Bg,Dg,primary,median_sd,base_k,p1cfg,e_cfg):
    rows=[]; psign=int(np.sign(np.mean(primary)))
    # Exact primary and two already-frozen finite approach candidates.
    for lam in e_cfg["smoothness_stability_when_primary_is_infinite"]["finite_approach_candidates"]:
        b=fit_pen(B,q[fit],float(lam),P)
        dg=-(Dg@b)
        rows.append({"type":"finite_approach","value":float(lam),
                     "D_diff":float(np.mean(dg)),
                     "sign_ok":int(np.sign(np.mean(dg)))==psign,
                     "median_abs_shift":float(np.median(np.abs(dg-primary)))})
    degree=int(p1cfg["model"]["degree"])
    for off in e_cfg["smoothness_stability_when_primary_is_infinite"]["knot_offsets"]:
        k=max(2,int(base_k)+int(off))
        dg=nullspace_with_knot_count(x,q,fit,gx,k,degree)
        if dg is None: continue
        rows.append({"type":"knot_offset","value":int(off),
                     "D_diff":float(np.mean(dg)),
                     "sign_ok":int(np.sign(np.mean(dg)))==psign,
                     "median_abs_shift":float(np.median(np.abs(dg-primary)))})
    pass_smooth=all(r["sign_ok"] and r["median_abs_shift"]<=median_sd for r in rows)

    fitidx=np.where(fit)[0]; rad=d.radius_arcsec.to_numpy(float)[fitidx]
    order=np.argsort(rad,kind="mergesort")
    quint=np.empty(len(rad),int); quint[order]=np.clip(np.floor(np.arange(len(rad))*5/len(rad)).astype(int),0,4)
    loro=[]
    B0=B@N; D0=Dg@N
    for k in range(5):
        keep=quint!=k
        th=fit_unpen(B0[keep],q[fitidx][keep])
        dg=-(D0@th)
        loro.append({"quintile_left_out":k,"D_diff":float(np.mean(dg)),
                     "sign_ok":int(np.sign(np.mean(dg)))==psign,
                     "median_abs_shift":float(np.median(np.abs(dg-primary)))})
    nsign=sum(r["sign_ok"] for r in loro)
    medshift=float(np.median([r["median_abs_shift"] for r in loro]))
    pass_loro=nsign>=4 and medshift<=1.5*median_sd
    return rows,pass_smooth,loro,pass_loro,nsign,medshift

def permutation_T(B,P,N,y,folds,lambdas,Dg,gx,rng):
    yp=rng.permutation(y)
    _,state,_=cv_candidate_scan(B,P,N,yp,folds,lambdas)
    kind,c=state_fit(B,P,N,yp,state)
    if kind=="NULLSPACE":
        dg=-((Dg@N)@c)
    else:
        dg=-(Dg@c)
    T=float(np.trapezoid(dg*dg,gx)/(gx[-1]-gx[0]))
    return T,state

def run_cluster(root,cid,mode):
    e=yaml.safe_load((root/"config/stage1d2_execution_v020.yaml").read_text(encoding="utf-8"))
    p1=yaml.safe_load((root/"config/stage1d1b_protocol.yaml").read_text(encoding="utf-8"))
    if sha256_file(root/"config/stage1d1b_protocol.yaml")!=e["required_stage1d1b_protocol_sha256"]:
        raise SystemExit("Stage1D1B protocol hash mismatch")
    p2=json.loads((root/"validation/stage1d1b2_preflight.json").read_text(encoding="utf-8"))
    if p2.get("disposition")!=e["required_stage1d1b2_disposition"]:
        raise SystemExit("Stage1D1B2 is not in the required frozen state")
    if p2["selected_smoothing_states"].get(cid)!=e["required_smoothing_state"]:
        raise SystemExit(f"{cid}: unexpected frozen smoothing state")

    d,q,fit,x,folds,knots,B,P,N,B0,gx,Bg,Dg,Rref,gR,srow=load_design(root,cid,p1)
    y=q[fit]; lambdas=np.asarray(p1["smoothness_selection"]["lambda_grid"],float)
    tab,state,threshold=cv_candidate_scan(B,P,N,y,folds,lambdas)
    if state!="PENALTY_NULLSPACE_LIMIT":
        raise RuntimeError(f"{cid}: observed Stage1D2 smoothing state disagrees with Stage1D1B2: {state}")
    th=fit_unpen(B0,y); eta,p,dg=state_profile("NULLSPACE",th,Bg,Dg,N)
    S,D,Rp,T=diag(dg,gx,gR)
    out=root/"outputs/stage1d2_v020"/"clusters"/cid; out.mkdir(parents=True,exist_ok=True)
    tab.to_csv(out/f"{cid}_cv_candidates.csv",index=False)
    write_json(out/f"{cid}_observed_summary.json",{
        "cluster_id":cid,"selected_smoothing_state":state,"one_se_threshold":threshold,
        "S_diff":S,"D_diff":D,"R_peak_arcsec":Rp,"T_global":T,
        "science_complete":False
    })
    pd.DataFrame({"cluster_id":cid,"R_arcsec":gR,"lnR_relative":gx,
                  "eta":eta,"p2p":p,"delta_gamma":dg}).to_csv(
                      out/f"{cid}_observed_profile.csv",index=False)
    print(f"[Stage1D2-v0.2] {cid} observed fit complete; frozen state={state}")
    if mode=="observed": return

    u=p1["uncertainty"]; seed=int(u["random_seed"])+int(e["execution"]["random_seed_offset"])+sum(map(ord,cid))
    b1p=out/f"{cid}_bootstrap_primary.npy"; bsp=out/f"{cid}_bootstrap_soft.npy"
    D0=Dg@N
    b1=np.load(b1p) if b1p.exists() else bootstrap_nullspace(B0,D0,y,x[fit],
          int(u["primary_bootstrap_replicates"]),seed,True)
    if not b1p.exists(): np.save(b1p,b1)
    bs=np.load(bsp) if bsp.exists() else bootstrap_nullspace(B0,D0,y,x[fit],
          int(u["secondary_soft_bootstrap_replicates"]),seed+100000,False)
    if not bsp.exists(): np.save(bsp,bs)

    sd=np.std(b1,axis=0,ddof=1); sd=np.maximum(sd,1e-10)
    zmax=np.max(np.abs((b1-dg[None,:])/sd[None,:]),axis=1)
    crit=float(np.quantile(zmax,.95))
    slo=dg-crit*sd; shi=dg+crit*sd
    qs=np.quantile(b1,[.025,.16,.5,.84,.975],axis=0)
    sq=np.quantile(bs,[.16,.5,.84],axis=0)
    width,localsign=zero_exclusion_width(slo,shi,gx)
    medsd=float(np.median(sd))
    srows,spass,lrows,lpass,nsign,lmed=stability(
        d,q,fit,x,B,P,N,gx,Bg,Dg,dg,medsd,int(srow.n_interior_knots),p1,e)
    pd.DataFrame(srows).to_csv(out/f"{cid}_smoothing_sensitivity.csv",index=False)
    pd.DataFrame(lrows).to_csv(out/f"{cid}_leave_one_quintile_out.csv",index=False)

    nperm=int(p1["global_null_test"]["permutations"])
    pp=out/f"{cid}_permutation_T.npy"
    ps=out/f"{cid}_permutation_state.json"
    vals=np.load(pp).tolist() if pp.exists() else []
    states=json.loads(ps.read_text()) if ps.exists() else []
    rng=np.random.default_rng(seed+200000)
    # Each permutation consumes one permutation draw; CV/fits consume no RNG.
    for _ in range(len(vals)):
        rng.permutation(y)
    checkpoint=int(e["execution"]["checkpoint_every_permutations"])
    for j in range(len(vals),nperm):
        tv,st=permutation_T(B,P,N,y,folds,lambdas,Dg,gx,rng)
        vals.append(tv); states.append(st)
        if (j+1)%checkpoint==0 or j+1==nperm:
            np.save(pp,np.asarray(vals,float)); write_json(ps,states)
            print(f"[Stage1D2-v0.2] {cid}: permutations {j+1}/{nperm}")
    vals=np.asarray(vals,float)
    pperm=float((1+np.sum(vals>=T))/(1+len(vals)))
    stability_pass=bool(spass and lpass)
    res={
      "cluster_id":cid,"selected_smoothing_state":state,
      "S_diff":S,"D_diff":D,"R_peak_arcsec":Rp,"T_global":T,
      "primary_bootstrap_replicates":int(len(b1)),
      "soft_bootstrap_replicates":int(len(bs)),
      "simultaneous_band_critical_value":crit,
      "max_contiguous_zero_exclusion_width_lnR":float(width),
      "dominant_significant_interval_sign":int(localsign),
      "local_simultaneous_band_gate_pass":bool(width>=0.30),
      "permutation_replicates":int(len(vals)),
      "permutation_p_value":pperm,
      "permutation_nullspace_selected_fraction":float(np.mean(np.array(states)=="PENALTY_NULLSPACE_LIMIT")),
      "smoothing_stability_pass":bool(spass),
      "loro_stability_pass":bool(lpass),
      "loro_sign_preserved_count":int(nsign),
      "loro_median_abs_shift":float(lmed),
      "all_method_stability_pass":stability_pass,
      "science_complete":True
    }
    write_json(out/f"{cid}_science_summary.json",res)
    pd.DataFrame({
      "cluster_id":cid,"R_arcsec":gR,"lnR_relative":gx,
      "eta_observed":eta,"p2p_observed":p,"delta_gamma_observed":dg,
      "delta_gamma_p025":qs[0],"delta_gamma_p16":qs[1],"delta_gamma_p50":qs[2],
      "delta_gamma_p84":qs[3],"delta_gamma_p975":qs[4],
      "simultaneous95_lower":slo,"simultaneous95_upper":shi,
      "soft_boot_delta_gamma_p16":sq[0],"soft_boot_delta_gamma_p50":sq[1],
      "soft_boot_delta_gamma_p84":sq[2]
    }).to_csv(out/f"{cid}_science_profile.csv",index=False)
    print(f"[Stage1D2-v0.2] {cid} complete: p={pperm:.4g}, local={width>=0.30}, stable={stability_pass}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=".")
    ap.add_argument("--cluster",default="ALL")
    ap.add_argument("--mode",choices=["observed","full"],default="full")
    args=ap.parse_args()
    root=Path(args.root).resolve()
    e=yaml.safe_load((root/"config/stage1d2_execution_v020.yaml").read_text(encoding="utf-8"))
    pre=json.loads((root/"validation/stage1d1b2_preflight.json").read_text(encoding="utf-8"))
    if not pre.get("stage1d2_authorized",False):
        raise SystemExit("Stage1D1B2 has not authorized Stage1D2")
    cs=e["clusters"] if args.cluster=="ALL" else [args.cluster]
    for cid in cs:
        if cid not in e["clusters"]: raise SystemExit("Unknown cluster "+cid)
        run_cluster(root,cid,args.mode)

if __name__=="__main__": main()
