@echo off
python -c "import numpy,pandas,scipy,yaml; print('Stage1D3 environment: OK')"
