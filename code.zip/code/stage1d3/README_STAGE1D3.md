# Stage 1D3 v0.1.0 — 2D azimuthal/non-axisymmetry and spatial-systematics audit

Stage 1D2 has produced the first conditional differential-slope results. Stage 1D3 asks whether those radial results can safely be interpreted as approximately axisymmetric cluster-wide population structure.

Three independent audits are frozen:

1. **Azimuthal omnibus test.**  
   The Stage 1D2 radial `logit p2P(R)` profile is held fixed as an offset. An 8-term m=1/m=2 angular model, including linear lnR interactions, is fitted to the soft q2P values. Significance is obtained from 999 theta permutations within 10 radial strata, followed by BH-FDR across six clusters.

2. **Quality-linked residual test.**  
   The same frozen radial offset is augmented by robust-standardized `log(max RMS)` and `min QFIT`. The paired quality covariates are permuted within radial strata. A significant result is treated as a classification/systematics warning, not as physical population structure.

3. **Sector jackknife.**  
   The exact Stage 1D1B2 nullspace radial model is refitted after leaving out each of 8 sectors at two sector phases (16 refits). For an upstream robust radial detection, at least 14/16 refits must preserve the D_diff sign and the median absolute D_diff shift must be <=1.5 bootstrap SD.

A Stage 1D2 robust radial result becomes `RADIAL_DIFFERENTIAL_STRUCTURE_2D_VALIDATED` only if all three gates pass.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d3_prepare_env.bat
call run_stage1d3_selftest.bat
call run_stage1d3_input_preflight.bat
call run_stage1d3.bat
```

Stage 1D3 still does not authorize absolute `gamma_1P` or `gamma_2P`.
