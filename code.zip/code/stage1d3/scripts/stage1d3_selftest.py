
import numpy as np
from scipy.special import expit

# Conditional spatial test sanity: if q is generated only from radius,
# an angle shuffle leaves the radial baseline conceptually unchanged.
theta=np.linspace(-np.pi,np.pi,200,endpoint=False)
x=np.linspace(-1,1,200)
X=np.c_[np.cos(theta),np.sin(theta),np.cos(2*theta),np.sin(2*theta),
        x*np.cos(theta),x*np.sin(theta),x*np.cos(2*theta),x*np.sin(2*theta)]
assert X.shape==(200,8)

# Eight sectors at two phases => 16 leave-one-sector-out refits.
assert 8*2==16
print("STAGE1D3_SELFTEST: PASS")
