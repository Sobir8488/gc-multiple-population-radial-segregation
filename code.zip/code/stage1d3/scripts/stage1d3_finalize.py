
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d3/stage1d3_cluster_summary.csv")
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("six clusters audited",set(s.cluster_id)==set(cfg["clusters"]),f"{len(s)}/6")
    add("all 2D p-values finite",s.azimuthal_permutation_p.notna().all() and s.quality_permutation_p.notna().all(),"finite")
    add("all BH q-values finite",s.azimuthal_bh_q.notna().all() and s.quality_bh_q.notna().all(),"finite")
    nerr=sum(not x["passed"] for x in checks)
    validated=int((s.stage1d3_status=="RADIAL_DIFFERENTIAL_STRUCTURE_2D_VALIDATED").sum())
    flagged=int((s.stage1d3_status=="RADIAL_DIFFERENTIAL_STRUCTURE_2D_FLAGGED").sum())
    nonax=int((s.stage1d3_status=="NONAXISYMMETRIC_STRUCTURE_WITHOUT_RADIAL_DIFFERENTIAL_SIGNAL").sum())
    null2d=int((s.stage1d3_status=="NO_RESOLVED_RADIAL_OR_2D_DIFFERENTIAL_STRUCTURE").sum())
    qlinked=int((s.stage1d3_status=="RADIAL_NULL_WITH_QUALITY_LINKED_STRUCTURE").sum())
    if nerr:
        next_stage="Stage1D3 repair"
        disp="STAGE1D3_AUDIT_NOT_READY"
    elif flagged or nonax or qlinked:
        next_stage="Stage1D3B flagged-cluster spatial closure before manuscript synthesis"
        disp="STAGE1D3_AUDIT_COMPLETE_FLAGGED_CLUSTERS_REQUIRE_CLOSURE"
    else:
        next_stage="Stage1D4 claim-safe science synthesis and manuscript integration"
        disp="STAGE1D3_2D_AUDIT_COMPLETE_CLAIM_SYNTHESIS_AUTHORIZED"
    obj={
      "stage":"Stage1D3","version":"0.1.0","generated_utc":utcnow(),
      "audit_complete":nerr==0,
      "n_radial_robust_2d_validated":validated,
      "n_radial_robust_2d_flagged":flagged,
      "n_nonaxisymmetric_without_radial_signal":nonax,
      "n_radial_null_quality_linked":qlinked,
      "n_no_resolved_radial_or_2d_structure":null2d,
      "absolute_density_slopes_ready":False,
      "science_ready_for_claim_synthesis":bool(nerr==0 and flagged==0 and nonax==0 and qlinked==0),
      "next_required_stage":next_stage,
      "n_checks":len(checks),"n_error_failures":nerr,
      "disposition":disp
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3_preflight.csv",index=False)
    write_json(val/"stage1d3_preflight.json",obj)
    lines=["# Stage 1D3 2D/spatial audit","",
           f"- Audit complete: **{obj['audit_complete']}**",
           f"- Radial robust + 2D validated: **{validated}**",
           f"- Radial robust but 2D flagged: **{flagged}**",
           f"- Non-axisymmetric without radial signal: **{nonax}**",
           f"- Radial-null quality-linked: **{qlinked}**",
           f"- No resolved radial or 2D structure: **{null2d}**",
           "- Absolute density slopes ready: **False**","",
           "## Cluster adjudication"]
    for _,r in s.iterrows():
        lines.append(
          f"- {r.cluster_id}: `{r.stage1d3_status}`; azimuth p={r.azimuthal_permutation_p:.4g}, "
          f"qBH={r.azimuthal_bh_q:.4g}; quality p={r.quality_permutation_p:.4g}, "
          f"qBH={r.quality_bh_q:.4g}; sector sign={int(r.sector_sign_preserved_count)}/16, "
          f"sector-pass={bool(r.sector_jackknife_pass)}."
        )
    lines += ["",f"Next: **{next_stage}**"]
    (val/"stage1d3_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__": main()
