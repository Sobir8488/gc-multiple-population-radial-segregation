
from pathlib import Path
import argparse, json, math
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import BSpline
from scipy.special import expit, logit
from stage1d3_common import sha256_file, utcnow, write_json

def num(x): return pd.to_numeric(x,errors="coerce")

def robust_z(x):
    x=np.asarray(x,float)
    med=float(np.nanmedian(x))
    q25,q75=np.nanquantile(x,[.25,.75])
    sc=float((q75-q25)/1.349)
    if not np.isfinite(sc) or sc<=1e-10:
        sc=float(np.nanstd(x))
    if not np.isfinite(sc) or sc<=1e-10: sc=1.0
    return (x-med)/sc

def basis(x,knots,degree,deriv=0):
    n=len(knots)-degree-1; eye=np.eye(n)
    cols=[]
    for j in range(n):
        s=BSpline(knots,eye[j],degree,extrapolate=False)
        if deriv: s=s.derivative(deriv)
        cols.append(s(np.asarray(x,float)))
    return np.column_stack(cols)

def penalty(n):
    D=np.diff(np.eye(n),n=2,axis=0)
    return D.T@D

def nullspace(P,tol=1e-9):
    w,V=np.linalg.eigh(P)
    N=V[:,w<tol]
    if N.shape[1]!=2: raise RuntimeError(f"nullspace dimension={N.shape[1]}")
    return N

def fit_offset(X,y,offset):
    X=np.asarray(X,float); y=np.asarray(y,float); offset=np.asarray(offset,float)
    b=np.zeros(X.shape[1],float)
    for _ in range(80):
        eta=offset+X@b
        p=expit(eta); w=np.maximum(p*(1-p),1e-7)
        g=X.T@(p-y)
        H=X.T@(w[:,None]*X)+1e-9*np.eye(X.shape[1])
        step=np.linalg.solve(H,g)
        obj=float(np.sum(np.logaddexp(0,eta)-y*eta))
        a=1.0
        for _ in range(25):
            c=b-a*step; e=offset+X@c
            co=float(np.sum(np.logaddexp(0,e)-y*e))
            if co<=obj+1e-12:
                b=c; break
            a*=0.5
        if np.max(np.abs(a*step))<1e-9: break
    return b

def ll_offset(X,y,offset,b):
    e=offset+X@b
    return float(np.sum(y*e-np.logaddexp(0,e)))

def fit_unpen(B,y):
    return fit_offset(B,y,np.zeros(len(y)))

def radial_strata(r,n=10):
    r=np.asarray(r,float)
    order=np.argsort(r,kind="mergesort")
    s=np.empty(len(r),int)
    s[order]=np.clip(np.floor(np.arange(len(r))*n/len(r)).astype(int),0,n-1)
    return s

def permute_within(rng,arr,strata):
    out=np.array(arr,copy=True)
    for s in np.unique(strata):
        idx=np.where(strata==s)[0]
        out[idx]=out[rng.permutation(idx)]
    return out

def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p)
    r=p[o]*n/np.arange(1,n+1)
    r=np.minimum.accumulate(r[::-1])[::-1]
    q=np.empty(n,float); q[o]=np.clip(r,0,1)
    return q

def load_master(root,cid,cfg):
    prob=pd.read_csv(root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
    master=pd.read_csv(root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
    rows=[]
    for mid,g in prob.groupby("master_star_id",sort=False):
        rows.append({"master_star_id":mid,
                     "q2p":float(np.mean(num(g.population_probability_2p)))})
    d=pd.DataFrame(rows)

    # HOTFIX v0.1.1:
    # Use the frozen Stage1B HUGS row-position identity, not source_row_id as a lookup key.
    # Some normalized HUGS tables contain duplicated source_row_id strings; source_row_id
    # is therefore descriptive provenance, whereas hugs_source_index is the authoritative
    # row-position link already frozen by Stage1B.
    needed=["master_star_id","x_common_arcsec","y_common_arcsec",
            "hugs_source_index","hugs_source_row_id"]
    missing=[c for c in needed if c not in master.columns]
    if missing:
        raise RuntimeError(f"{cid}: Stage1B master index missing columns: {missing}")
    m=master[needed].drop_duplicates("master_star_id")
    d=d.merge(m,on="master_star_id",how="left",validate="one_to_one")
    if d.hugs_source_index.isna().any():
        raise RuntimeError(f"{cid}: missing HUGS source index for Stage1C3 master")
    d["hugs_source_index"]=pd.to_numeric(d.hugs_source_index,errors="raise").astype(int)
    d["radius_arcsec"]=np.hypot(num(d.x_common_arcsec),num(d.y_common_arcsec))
    d["theta"]=np.arctan2(num(d.y_common_arcsec),num(d.x_common_arcsec))
    return d

def attach_quality(root,cid,d,cfg):
    h=pd.read_csv(root/cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid),low_memory=False)
    s=pd.read_csv(root/cfg["upstream"]["hugs_source_pattern"].format(cluster=cid),low_memory=False)
    if len(h)!=len(s):
        raise RuntimeError(f"{cid}: HUGS normalized/source mismatch")

    # HOTFIX v0.1.1: exact positional lookup through frozen Stage1B hugs_source_index.
    idx=d.hugs_source_index.to_numpy(int)
    if np.any(idx<0) or np.any(idx>=len(h)):
        raise RuntimeError(f"{cid}: HUGS source index outside normalized/source tables")
    hh=h.iloc[idx].reset_index(drop=True)
    ss=s.iloc[idx].reset_index(drop=True)

    # Provenance identity guard. Duplicated source_row_id values are allowed in the full
    # normalized HUGS table, but each Stage1B master must point to its exact indexed row.
    expected=d.hugs_source_row_id.astype(str).to_numpy()
    actual=hh.source_row_id.astype(str).to_numpy()
    if not np.array_equal(expected,actual):
        bad=np.where(expected!=actual)[0]
        raise RuntimeError(
            f"{cid}: Stage1B hugs_source_index/source_row_id identity mismatch "
            f"for {len(bad)} Stage1C3 master(s)"
        )

    rmscols=["RMS_F275W","RMS_F336W","RMS_F438W","RMS_F606W","RMS_F814W"]
    qfitcols=["QFIT_F275W","QFIT_F336W","QFIT_F438W","QFIT_F606W","QFIT_F814W"]
    rms=np.column_stack([num(ss[c]).to_numpy(float) for c in rmscols])
    qfit=np.column_stack([num(ss[c]).to_numpy(float) for c in qfitcols])
    if len(rms)!=len(d) or len(qfit)!=len(d):
        raise RuntimeError(f"{cid}: quality-vector length mismatch after indexed HUGS lookup")
    if not np.isfinite(rms).all() or not np.isfinite(qfit).all():
        raise RuntimeError(f"{cid}: non-finite HUGS RMS/QFIT in frozen Stage1C3 sample")
    d=d.copy()
    d["max_rms"]=np.max(rms,axis=1)
    d["min_qfit"]=np.min(qfit,axis=1)
    return d

def radial_baseline(root,cid,R,cfg):
    p=pd.read_csv(root/cfg["upstream"]["stage1d2_observed_profile_pattern"].format(cluster=cid))
    xp=np.log(num(p.R_arcsec).to_numpy(float))
    pp=np.clip(num(p.p2p).to_numpy(float),1e-6,1-1e-6)
    x=np.log(np.asarray(R,float))
    eta=np.interp(x,xp,logit(pp))
    return eta,float(np.min(p.R_arcsec)),float(np.max(p.R_arcsec))

def omnibus_X(theta,lnR):
    z=robust_z(lnR)
    return np.column_stack([
        np.cos(theta),np.sin(theta),np.cos(2*theta),np.sin(2*theta),
        z*np.cos(theta),z*np.sin(theta),z*np.cos(2*theta),z*np.sin(2*theta)
    ])

def permutation_test_theta(q,R,theta,offset,nperm,seed):
    X=omnibus_X(theta,np.log(R))
    b=fit_offset(X,q,offset)
    ll0=float(np.sum(q*offset-np.logaddexp(0,offset)))
    obs=2*(ll_offset(X,q,offset,b)-ll0)
    strata=radial_strata(R,10)
    rng=np.random.default_rng(seed)
    vals=np.empty(nperm,float)
    for j in range(nperm):
        tp=permute_within(rng,theta,strata)
        Xp=omnibus_X(tp,np.log(R))
        bp=fit_offset(Xp,q,offset)
        vals[j]=2*(ll_offset(Xp,q,offset,bp)-ll0)
    p=float((1+np.sum(vals>=obs))/(1+nperm))
    return obs,p,b,vals

def permutation_test_quality(q,R,Q,offset,nperm,seed):
    b=fit_offset(Q,q,offset)
    ll0=float(np.sum(q*offset-np.logaddexp(0,offset)))
    obs=2*(ll_offset(Q,q,offset,b)-ll0)
    strata=radial_strata(R,10); rng=np.random.default_rng(seed)
    vals=np.empty(nperm,float)
    for j in range(nperm):
        Qp=np.empty_like(Q)
        for s in np.unique(strata):
            idx=np.where(strata==s)[0]
            perm=rng.permutation(idx)
            Qp[idx]=Q[perm]
        bp=fit_offset(Qp,q,offset)
        vals[j]=2*(ll_offset(Qp,q,offset,bp)-ll0)
    p=float((1+np.sum(vals>=obs))/(1+nperm))
    return obs,p,b,vals

def sector_jackknife(root,cid,d,q,cfg,D_primary):
    ready=pd.read_csv(root/cfg["upstream"]["stage1d1b_readiness"])
    s=ready.loc[ready.cluster_id==cid].iloc[0]
    knotsdf=pd.read_csv(root/cfg["upstream"]["stage1d1b_knots"])
    knots=knotsdf.loc[knotsdf.cluster_id==cid].sort_values("knot_index").x_knot.to_numpy(float)
    R=d.radius_arcsec.to_numpy(float); th=d.theta.to_numpy(float)
    fit=(R>=float(s.r_fit_q05_arcsec))&(R<=float(s.r_fit_q95_arcsec))
    Rref=float(s.R_ref_arcsec); x=np.log(R/Rref)
    degree=3
    B=basis(x[fit],knots,degree,0); N=nullspace(penalty(B.shape[1])); B0=B@N
    gx=np.linspace(np.log(float(s.r_claim_q10_arcsec)/Rref),
                   np.log(float(s.r_claim_q90_arcsec)/Rref),201)
    D0=basis(gx,knots,degree,1)@N
    fitidx=np.where(fit)[0]
    thf=th[fitidx]; qf=q[fitidx]
    rows=[]
    phases=cfg["sector_jackknife"]["sector_phases_rad"]
    ns=int(cfg["sector_jackknife"]["n_sectors"])
    for phase in phases:
        sector=np.floor(((thf-float(phase))%(2*np.pi))/(2*np.pi/ns)).astype(int)
        sector=np.clip(sector,0,ns-1)
        for k in range(ns):
            keep=sector!=k
            coef=fit_unpen(B0[keep],qf[keep])
            dg=-(D0@coef); Dj=float(np.mean(dg))
            rows.append({"phase_rad":float(phase),"sector_left_out":k,
                         "n_fit":int(keep.sum()),"D_diff":Dj,
                         "sign_preserved":bool(np.sign(Dj)==np.sign(D_primary)),
                         "abs_D_shift":float(abs(Dj-D_primary))})
    boot=np.load(root/cfg["upstream"]["stage1d2_bootstrap_primary_pattern"].format(cluster=cid))
    Dboot=np.mean(boot,axis=1)
    sd=float(np.std(Dboot,ddof=1))
    nsign=sum(r["sign_preserved"] for r in rows)
    medshift=float(np.median([r["abs_D_shift"] for r in rows]))
    gate=cfg["sector_jackknife"]["robust_signal_gate"]
    passed=(nsign>=int(gate["minimum_sign_preserved_refits"]) and
            medshift<=float(gate["maximum_median_abs_D_shift_in_bootstrap_sd_units"])*sd)
    return pd.DataFrame(rows),sd,nsign,medshift,passed

def sector_residuals(R,theta,q,p0,ns=8):
    sec=np.floor(((theta%(2*np.pi))/(2*np.pi/ns))).astype(int)
    rows=[]
    for k in range(ns):
        m=sec==k
        rows.append({"sector":k,"n":int(m.sum()),
                     "mean_q2p":float(np.mean(q[m])),
                     "mean_radial_baseline_p2p":float(np.mean(p0[m])),
                     "mean_q_minus_baseline":float(np.mean(q[m]-p0[m]))})
    return rows

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3_protocol.yaml").read_text(encoding="utf-8"))
    inp=json.loads((root/"validation/stage1d3_input_preflight.json").read_text(encoding="utf-8"))
    if not inp.get("input_ready",False): raise SystemExit("Stage1D3 input preflight not ready")
    s2=pd.read_csv(root/cfg["upstream"]["stage1d2_summary"])
    out=root/"outputs/stage1d3"; out.mkdir(parents=True,exist_ok=True)
    raw=[]; sector_tables=[]; sector_res=[]; manifests=[]

    for ic,cid in enumerate(cfg["clusters"]):
        d=attach_quality(root,cid,load_master(root,cid,cfg),cfg)
        eta,rlo,rhi=radial_baseline(root,cid,d.radius_arcsec,cfg)
        R=d.radius_arcsec.to_numpy(float)
        claim=(R>=rlo)&(R<=rhi)
        g=d.loc[claim].copy().reset_index(drop=True)
        q=g.q2p.to_numpy(float); Rg=g.radius_arcsec.to_numpy(float)
        th=g.theta.to_numpy(float); off=eta[claim]
        p0=expit(off)
        if len(g)<100: raise RuntimeError(f"{cid}: insufficient Stage1D3 claim support")
        nperm=int(cfg["azimuthal_omnibus"]["permutations"])
        a_stat,a_p,a_b,a_perm=permutation_test_theta(
            q,Rg,th,off,nperm,int(cfg["azimuthal_omnibus"]["random_seed"])+ic*10000)
        Q=np.column_stack([
            robust_z(np.log(np.clip(g.max_rms.to_numpy(float),1e-8,None))),
            robust_z(g.min_qfit.to_numpy(float))
        ])
        q_stat,q_p,q_b,q_perm=permutation_test_quality(
            q,Rg,Q,off,int(cfg["quality_linked_systematics"]["permutations"]),
            int(cfg["azimuthal_omnibus"]["random_seed"])+500000+ic*10000)

        upstream=s2.loc[s2.cluster_id==cid].iloc[0]
        sj,bsd,nsign,medshift,sjpass=sector_jackknife(
            root,cid,d,d.q2p.to_numpy(float),cfg,float(upstream.D_diff))
        sj["cluster_id"]=cid; sector_tables.append(sj)
        sr=sector_residuals(Rg,th,q,p0,8)
        for r in sr: r["cluster_id"]=cid
        sector_res.extend(sr)

        amp1=float(np.hypot(a_b[0],a_b[1]))
        amp2=float(np.hypot(a_b[2],a_b[3]))
        raw.append({
          "cluster_id":cid,"upstream_stage1d2_status":upstream.final_status,
          "n_claim":len(g),
          "azimuthal_statistic":a_stat,"azimuthal_permutation_p":a_p,
          "azimuthal_m1_logit_amplitude":amp1,"azimuthal_m2_logit_amplitude":amp2,
          "quality_statistic":q_stat,"quality_permutation_p":q_p,
          "quality_beta_log_maxrms":float(q_b[0]),"quality_beta_min_qfit":float(q_b[1]),
          "bootstrap_D_sd":bsd,"sector_sign_preserved_count":nsign,
          "sector_median_abs_D_shift":medshift,"sector_jackknife_pass":bool(sjpass)
        })
        cdir=out/"clusters"/cid; cdir.mkdir(parents=True,exist_ok=True)
        np.save(cdir/f"{cid}_azimuthal_permutation_statistics.npy",a_perm)
        np.save(cdir/f"{cid}_quality_permutation_statistics.npy",q_perm)
        print(f"[Stage1D3] {cid}: az_p={a_p:.4g} quality_p={q_p:.4g} "
              f"sector={nsign}/16 pass={sjpass}")

    df=pd.DataFrame(raw)
    df["azimuthal_bh_q"]=bh(df.azimuthal_permutation_p)
    df["quality_bh_q"]=bh(df.quality_permutation_p)
    finals=[]
    azsig=[]; qsig=[]
    for _,r in df.iterrows():
        a=bool(r.azimuthal_bh_q<0.05); qq=bool(r.quality_bh_q<0.05)
        azsig.append(a); qsig.append(qq)
        up=str(r.upstream_stage1d2_status)
        if up=="ROBUST_DIFFERENTIAL_STRUCTURE":
            if (not a) and (not qq) and bool(r.sector_jackknife_pass):
                st=cfg["final_adjudication"]["upstream_robust_and_all_2d_gates_pass"]
            else:
                st=cfg["final_adjudication"]["upstream_robust_but_any_2d_gate_fails"]
        elif up=="CONSISTENT_WITH_NO_RESOLVED_DIFFERENTIAL_SLOPE":
            if a:
                st=cfg["final_adjudication"]["upstream_null_and_azimuthal_significant"]
            elif qq:
                st=cfg["final_adjudication"]["upstream_null_and_quality_significant"]
            else:
                st=cfg["final_adjudication"]["upstream_null_and_no_2d_flags"]
        else:
            st=cfg["final_adjudication"]["upstream_method_sensitive"]
        finals.append(st)
    df["azimuthal_significant"]=azsig
    df["quality_link_significant"]=qsig
    df["stage1d3_status"]=finals
    df.to_csv(out/"stage1d3_cluster_summary.csv",index=False)
    pd.concat(sector_tables,ignore_index=True).to_csv(out/"stage1d3_sector_jackknife.csv",index=False)
    pd.DataFrame(sector_res).to_csv(out/"stage1d3_sector_residuals.csv",index=False)

    rows=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d3_output_manifest.csv":
            rows.append({"path":str(p.relative_to(out)).replace("\\","/"),
                         "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(rows).to_csv(out/"stage1d3_output_manifest.csv",index=False)

if __name__=="__main__": main()
