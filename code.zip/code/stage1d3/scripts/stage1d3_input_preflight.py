
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d3_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3_protocol.yaml").read_text(encoding="utf-8"))
    p=json.loads((root/cfg["upstream"]["stage1d2_preflight"]).read_text(encoding="utf-8"))
    s=pd.read_csv(root/cfg["upstream"]["stage1d2_summary"])
    checks=[]
    def add(n,v,d):
        checks.append({"check":n,"passed":bool(v),"severity":"ERROR","detail":d})
    add("Stage1D2 complete",p.get("science_inference_complete",False),p.get("disposition",""))
    add("six Stage1D2 clusters",set(s.cluster_id)==set(cfg["clusters"]),f"{len(s)}/6")
    add("no upstream method-sensitive cluster",not (s.final_status=="DIFFERENTIAL_STRUCTURE_METHOD_SENSITIVE").any(),
        f"method-sensitive={int((s.final_status=='DIFFERENTIAL_STRUCTURE_METHOD_SENSITIVE').sum())}")
    missing=[]
    for cid in cfg["clusters"]:
        rels=[
          cfg["upstream"]["stage1d2_observed_profile_pattern"].format(cluster=cid),
          cfg["upstream"]["stage1d2_bootstrap_primary_pattern"].format(cluster=cid),
          cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),
          cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),
          cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid),
          cfg["upstream"]["hugs_source_pattern"].format(cluster=cid),
        ]
        for rel in rels:
            if not (root/rel).exists(): missing.append(rel)
    add("all per-cluster inputs present",len(missing)==0,";".join(missing) if missing else "all present")
    add("Stage1D1B design products present",
        (root/cfg["upstream"]["stage1d1b_knots"]).exists() and
        (root/cfg["upstream"]["stage1d1b_readiness"]).exists(),
        "knots/readiness")
    nerr=sum(not x["passed"] for x in checks)
    obj={
      "stage":"Stage1D3","version":"0.1.0","generated_utc":utcnow(),
      "input_ready":nerr==0,"science_audit_performed":False,
      "n_checks":len(checks),"n_error_failures":nerr,
      "disposition":"STAGE1D3_INPUT_READY" if nerr==0 else "STAGE1D3_INPUT_NOT_READY"
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d3_input_preflight.csv",index=False)
    write_json(val/"stage1d3_input_preflight.json",obj)
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__": main()
