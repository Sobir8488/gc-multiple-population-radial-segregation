
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import yaml

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d3_protocol.yaml").read_text(encoding="utf-8"))
    for cid in cfg["clusters"]:
        prob=pd.read_csv(root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid),low_memory=False)
        master=pd.read_csv(root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid),low_memory=False)
        h=pd.read_csv(root/cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid),
                      usecols=["source_row_id"],low_memory=False)
        s=pd.read_csv(root/cfg["upstream"]["hugs_source_pattern"].format(cluster=cid),
                      usecols=["RMS_F275W","RMS_F336W","RMS_F438W","RMS_F606W","RMS_F814W",
                               "QFIT_F275W","QFIT_F336W","QFIT_F438W","QFIT_F606W","QFIT_F814W"],
                      low_memory=False)
        if len(h)!=len(s):
            raise RuntimeError(f"{cid}: HUGS normalized/source row mismatch")
        mids=prob.master_star_id.astype(str).drop_duplicates()
        m=master.loc[master.master_star_id.astype(str).isin(mids),
                     ["master_star_id","hugs_source_index","hugs_source_row_id"]].drop_duplicates("master_star_id")
        if len(m)!=mids.nunique():
            raise RuntimeError(f"{cid}: master/HUGS index coverage mismatch")
        idx=pd.to_numeric(m.hugs_source_index,errors="raise").astype(int).to_numpy()
        if np.any(idx<0) or np.any(idx>=len(h)):
            raise RuntimeError(f"{cid}: indexed HUGS row outside table")
        actual=h.iloc[idx].source_row_id.astype(str).to_numpy()
        expected=m.hugs_source_row_id.astype(str).to_numpy()
        if not np.array_equal(actual,expected):
            raise RuntimeError(f"{cid}: hugs_source_index/source_row_id provenance identity failed")
        dup=int(h.source_row_id.duplicated().sum())
        print(f"[Stage1D3-v0.1.1] {cid}: masters={len(m)} HUGS_full_duplicate_source_row_ids={dup} indexed_identity=PASS")
    print("STAGE1D3_V011_MAPPING_SELFTEST: PASS")

if __name__=="__main__":
    main()
