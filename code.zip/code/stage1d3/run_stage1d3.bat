@echo off
setlocal
python scripts\stage1d3_selftest.py || exit /b 1
python scripts\stage1d3_input_preflight.py --root . || exit /b 1
python scripts\stage1d3_audit.py --root . || exit /b 1
python scripts\stage1d3_finalize.py --root . || exit /b 1
echo STAGE1D3: PASS
endlocal
