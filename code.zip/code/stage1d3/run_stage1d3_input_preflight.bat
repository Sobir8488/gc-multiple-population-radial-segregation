@echo off
python scripts\stage1d3_input_preflight.py --root .
