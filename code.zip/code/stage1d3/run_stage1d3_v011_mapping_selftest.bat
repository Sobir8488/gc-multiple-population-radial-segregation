@echo off
python scripts\stage1d3_v011_mapping_selftest.py --root .
