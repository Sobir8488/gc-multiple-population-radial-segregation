# Stage 1D3 v0.1.1 HUGS-index mapping hotfix

This hotfix fixes the crash:

`ValueError: Length of values (1573) does not match length of index (1572)`

seen at NGC 5272.

## Cause

Stage 1D3 v0.1.0 used `source_row_id` as a pandas lookup key when attaching HUGS RMS/QFIT values.
The full normalized HUGS catalogue is allowed to contain duplicated `source_row_id` strings.
For NGC 5272, selecting 1572 Stage1C3 masters through that non-unique index returned 1573 rows.

The Stage 1B harmonization had already frozen the correct positional identity:
`master_star_id -> hugs_source_index`.

## Fix

Stage 1D3 v0.1.1 uses `hugs_source_index` for the exact row-position lookup in both
the normalized HUGS and HUGS source-column tables, and then verifies that the indexed
`source_row_id` equals the frozen Stage1B provenance value.

No scientific model, threshold, permutation count, random seed, BH-FDR rule, or
sector-jackknife gate is changed.

## Important

The NGC 2808 and NGC 5024 raw p-values printed before the crash are **partial pre-hotfix output**.
Do not interpret them. Re-run the full Stage 1D3 audit after applying this hotfix so all six
clusters are evaluated with one identical code path and BH-FDR is recomputed globally.
