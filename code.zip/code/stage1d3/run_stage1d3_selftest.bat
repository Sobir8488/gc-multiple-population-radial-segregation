@echo off
python scripts\stage1d3_selftest.py
