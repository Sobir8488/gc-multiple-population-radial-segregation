# Stage 1C2 v0.1.0 — RGB science-support freeze and chromosome-map verticalisation

This is a **flat overlay** for the existing `stage1a_source_acquisition_v0_1_0` project root after Stage 1C1 has passed.

## Scientific scope

Stage 1C2 freezes, for the eight pilot clusters:

1. a high-membership, five-band, magnitude-dependent quality-selected upper-RGB sample;
2. a conservative F814W support interval from 2.00 to 0.60 mag above the Stage1C1 MSTO anchor;
3. an optical `F438W-F814W` RGB locus independent of chromosome-map population coordinates;
4. blue/red 5th/95th-percentile non-parametric fiducials for `F275W-F814W` and `C_F275W,F336W,F438W`;
5. Milone-style verticalised coordinates `Delta_F275W,F814W` and `Delta_C_F275W,F336W,F438W`;
6. the Stage1B `master_star_id` link for every frozen RGB star.

No 1P/2P classifier is fit in this stage. No population label, radial prior, or spatial information is used to define the RGB sample or fiducials.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1c2_prepare_env.bat
call run_stage1c2_selftest.bat
call run_stage1c2.bat
```

Expected final disposition:

`RGB_VERTICALISATION_FROZEN_CLASSIFIER_BLOCKED`

## Main outputs

- `outputs/stage1c2/stage1c2_rgb_freeze.csv`
- `outputs/stage1c2/stage1c2_fiducial_grid.csv`
- `outputs/stage1c2/stage1c2_quality_envelopes.csv`
- `outputs/stage1c2/stage1c2_external_width_benchmark.csv`
- `outputs/stage1c2/stage1c2_decision_ledger.csv`
- `outputs/stage1c2/clusters/<CLUSTER>/<CLUSTER>_rgb_verticalised.csv.gz`
- `validation/stage1c2_preflight.json`
- `validation/stage1c2_preflight.md`

The literature-width comparison is **diagnostic only** and is never used to tune or accept the fiducials.
