@echo off
setlocal
python -c "import numpy,pandas,yaml,scipy; print('Stage1C2 dependencies: OK')" || exit /b 1
call run_stage1c2_selftest.bat || exit /b 1
python scripts\stage1c2_verticalize.py --root .
if errorlevel 1 exit /b %errorlevel%
echo STAGE1C2: PASS
endlocal
