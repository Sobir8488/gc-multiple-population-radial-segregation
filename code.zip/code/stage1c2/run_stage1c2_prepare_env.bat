@echo off
python -c "import numpy,pandas,yaml,scipy; print('Stage1C2 environment: OK')" || exit /b 1
