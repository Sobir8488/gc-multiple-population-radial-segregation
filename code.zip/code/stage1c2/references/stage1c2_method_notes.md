# Method notes

- Milone et al. (2017, MNRAS, 464, 3636) construct chromosome maps from `F275W-F814W` and `C_F275W,F336W,F438W`, using cluster-specific blue/red RGB fiducials and widths evaluated two F814W magnitudes above the MSTO.
- Nardiello et al. (2018, MNRAS, 481, 3382) provide the public five-band HUGS catalogues and photometric-quality diagnostics used here.
- The Stage 1C2 literature-width table is a diagnostic comparison only; it is not used to tune the frozen pipeline.
