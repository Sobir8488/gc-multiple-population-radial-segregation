from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import UnivariateSpline, PchipInterpolator

BANDS = ["F275W","F336W","F438W","F606W","F814W"]
MAGCOL = {b:f"mag_{b.lower()}" for b in BANDS}

# Milone et al. 2017, MNRAS 464, 3636, Table 2.  Diagnostic only: these
# published widths do not enter selection, fiducial fitting, or validation gates.
PUBLISHED_WIDTHS = {
    "NGC2808": {"W_C":0.457, "W_X":0.518, "N":2682},
    "NGC5024": {"W_C":0.209, "W_X":0.200, "N":1081},
    "NGC5272": {"W_C":0.279, "W_X":0.263, "N":1177},
    "NGC3201": {"W_C":0.292, "W_X":0.211, "N":169},
    "NGC6101": {"W_C":0.140, "W_X":0.116, "N":263},
    "NGC5904": {"W_C":0.332, "W_X":0.219, "N":965},
    "NGC6205": {"W_C":0.291, "W_X":0.231, "N":1198},
    "NGC7078": {"W_C":0.217, "W_X":0.215, "N":1495},
}

def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def sha256(p:Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def load_protocol(root:Path, config:str|None):
    p=Path(config).resolve() if config else root/"config/stage1c2_protocol.yaml"
    with p.open("r",encoding="utf-8") as f: return yaml.safe_load(f)

def running_quantile(mag,val,grid,half,q,min_n=15):
    mag=np.asarray(mag,float); val=np.asarray(val,float)
    out=np.full(len(grid),np.nan)
    for j,g in enumerate(grid):
        z=val[(np.abs(mag-g)<=half)&np.isfinite(mag)&np.isfinite(val)]
        if z.size>=min_n: out[j]=np.quantile(z,q)
    ok=np.isfinite(out)
    if ok.sum()<2: return np.full(len(mag),np.nan), out
    interp=np.interp(mag,grid[ok],out[ok],left=out[ok][0],right=out[ok][-1])
    return interp,out

def binned_quantiles(mag,val,lo,hi,width,step,min_n,quantiles):
    mag=np.asarray(mag,float); val=np.asarray(val,float)
    centers=np.arange(lo,hi+1e-9,step)
    rows=[]
    for c in centers:
        z=val[(np.abs(mag-c)<=width/2)&np.isfinite(mag)&np.isfinite(val)]
        if z.size>=min_n:
            rows.append([c,int(z.size),*map(float,np.quantile(z,quantiles))])
    return np.asarray(rows,float) if rows else np.empty((0,2+len(quantiles)))

def check_upstream(root,protocol):
    p=root/protocol["upstream"]["stage1c1_preflight"]
    if not p.exists(): return False,{"missing":str(p)}
    try: d=json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: return False,{"parse_error":repr(e)}
    ready=bool(d.get("inventory_ready",False) and int(d.get("n_error_failures",1))==0 and int(d.get("n_clusters_stage1c2_eligible",0))==8)
    return ready,d

def quality_mask(h,s,mto,protocol,quality_rows,cid):
    sp=protocol["selection"]; qp=sp["quality"]
    req=[MAGCOL[b] for b in sp["required_bands"]]
    lo=mto-float(sp["bright_extent_above_msto_mag"])
    hi=mto-float(sp["faint_offset_above_msto_mag"])
    base=(pd.to_numeric(h["p_cluster_member"],errors="coerce")>=float(sp["membership_threshold"])) & h[req].notna().all(axis=1) & (h["mag_f814w"]>=lo) & (h["mag_f814w"]<=hi)
    keep=base.to_numpy(dtype=bool,copy=True)
    mag=pd.to_numeric(h["mag_f814w"],errors="coerce").to_numpy(float)
    grid=np.arange(lo,hi+float(qp["quality_grid_step_mag"])/2,float(qp["quality_grid_step_mag"]))
    for band in sp["required_bands"]:
        qfit=pd.to_numeric(s[f"QFIT_{band}"],errors="coerce").to_numpy(float)
        rms=pd.to_numeric(s[f"RMS_{band}"],errors="coerce").to_numpy(float)
        rad=pd.to_numeric(s[f"RADXS_{band}"],errors="coerce").to_numpy(float)
        nf=pd.to_numeric(s[f"Nf_{band}"],errors="coerce").to_numpy(float)
        ng=pd.to_numeric(s[f"Ng_{band}"],errors="coerce").to_numpy(float)
        valid=base.to_numpy() & np.isfinite(qfit) & np.isfinite(rms)
        qv=np.where(valid,qfit,np.nan); rv=np.where(valid,rms,np.nan)
        qlo, qnodes=running_quantile(mag,qv,grid,float(qp["quality_window_halfwidth_mag"]),float(qp["qfit_lower_quantile"]))
        rhi, rnodes=running_quantile(mag,rv,grid,float(qp["quality_window_halfwidth_mag"]),float(qp["rms_upper_quantile"]))
        if np.all(~np.isfinite(qlo)):
            qlo=np.full(len(mag),np.nanquantile(qv,float(qp["qfit_lower_quantile"])))
        if np.all(~np.isfinite(rhi)):
            rhi=np.full(len(mag),np.nanquantile(rv,float(qp["rms_upper_quantile"])))
        info=np.isfinite(rad)&(np.abs(rad)<float(qp["radxs_sentinel_abs_ge"]))&base.to_numpy()
        av=np.where(info,np.abs(rad),np.nan)
        ahi, anodes=running_quantile(mag,av,grid,float(qp["quality_window_halfwidth_mag"]),float(qp["radxs_abs_upper_quantile"]))
        good=np.isfinite(qfit)&np.isfinite(rms)&(qfit>=qlo)&(rms<=rhi)&(nf>=int(qp["require_nf_ge"]))&(ng>=int(qp["require_ng_ge"]))
        good &= (~info) | (np.abs(rad)<=ahi)
        keep &= good
        for j,g in enumerate(grid):
            quality_rows.append({"cluster_id":cid,"band":band,"mag_f814w_grid":g,
                                 "qfit_min":qnodes[j] if j<len(qnodes) else np.nan,
                                 "rms_max":rnodes[j] if j<len(rnodes) else np.nan,
                                 "radxs_abs_max":anodes[j] if j<len(anodes) else np.nan})
    return base.to_numpy(dtype=bool),keep,lo,hi

def rgb_locus_select(h,quality,lo,hi,protocol):
    rp=protocol["selection"]["optical_rgb_locus"]
    mag=pd.to_numeric(h["mag_f814w"],errors="coerce").to_numpy(float)
    opt=(pd.to_numeric(h["mag_f438w"],errors="coerce")-pd.to_numeric(h["mag_f814w"],errors="coerce")).to_numpy(float)
    sel=quality.copy()
    pred=np.full(len(h),np.nan); psig=np.full(len(h),np.nan)
    last_nodes=None
    for _ in range(int(rp["iterations"])):
        st=binned_quantiles(mag[sel],opt[sel],lo,hi,float(rp["bin_width_mag"]),float(rp["grid_step_mag"]),int(rp["min_bin_stars"]),(0.16,0.50,0.84))
        if len(st)<5: break
        c=st[:,0]; q16=st[:,2]; med=st[:,3]; q84=st[:,4]
        sig=np.maximum((q84-q16)/2,float(rp["sigma_floor_mag"]))
        k=min(3,len(c)-1)
        sm=max(len(c)*0.001,0.001)
        spl=UnivariateSpline(c,med,w=np.sqrt(st[:,1]),s=sm,k=k,ext=3)
        ss=UnivariateSpline(c,sig,w=np.sqrt(st[:,1]),s=max(len(c)*0.0003,0.0003),k=k,ext=3)
        pred=spl(np.clip(mag,c.min(),c.max())); psig=np.maximum(ss(np.clip(mag,c.min(),c.max())),float(rp["sigma_floor_mag"]))
        sel=quality & (np.abs(opt-pred)<=float(rp["selection_nsigma"])*psig)
        last_nodes=st
    residual_sigma=(opt-pred)/psig
    return sel,residual_sigma,last_nodes

def fit_envelope(mag,val,lo,hi,protocol):
    fp=protocol["fiducials"]
    st=binned_quantiles(mag,val,lo,hi,float(fp["bin_width_mag"]),float(fp["grid_step_mag"]),int(fp["min_bin_stars"]),(float(fp["lower_quantile"]),0.50,float(fp["upper_quantile"])))
    if len(st)<int(fp["min_fiducial_nodes"]): return None
    c=st[:,0]; qlo=st[:,2]; med=st[:,3]; qhi=st[:,4]
    # Preserve the quantile ordering by interpolating the median and the two
    # positive deviations from it.  This prevents spline overshoot from making
    # blue/red fiducials cross in sparse bright-RGB bins.
    eps=1e-4
    low=np.maximum(med-qlo,eps); high=np.maximum(qhi-med,eps)
    fmed=PchipInterpolator(c,med,extrapolate=True)
    flow=PchipInterpolator(c,np.log(low),extrapolate=True)
    fhigh=PchipInterpolator(c,np.log(high),extrapolate=True)
    def evaluate(x):
        xx=np.clip(np.asarray(x,float),c.min(),c.max())
        mm=fmed(xx); bb=mm-np.exp(flow(xx)); rr=mm+np.exp(fhigh(xx))
        return bb,mm,rr
    return st,evaluate

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",type=Path,default=Path.cwd()); ap.add_argument("--config",default=None)
    args=ap.parse_args(); root=args.root.resolve(); protocol=load_protocol(root,args.config)
    out=root/"outputs/stage1c2"; val=root/"validation"; out.mkdir(parents=True,exist_ok=True); val.mkdir(parents=True,exist_ok=True)
    checks=[]; freeze=[]; fidrows=[]; qrows=[]; bench=[]; decisions=[]
    upstream,meta=check_upstream(root,protocol)
    checks.append({"cluster_id":"GLOBAL","check":"Stage1C1 inventory ready","severity":"ERROR","passed":upstream,"detail":json.dumps(meta,sort_keys=True)[:500]})
    invp=root/protocol["upstream"]["stage1c1_inventory"]
    inv=pd.read_csv(invp).set_index("cluster_id") if invp.exists() else pd.DataFrame()
    for cid in protocol["pilot_clusters"]:
        hp=root/protocol["hugs"]["normalized_pattern"].format(cluster=cid); sp=root/protocol["hugs"]["source_columns_pattern"].format(cluster=cid)
        exists=hp.exists() and sp.exists() and cid in inv.index
        checks.append({"cluster_id":cid,"check":"Stage1C2 inputs exist","severity":"ERROR","passed":exists,"detail":f"hugs={hp.exists()} source={sp.exists()} inventory={cid in inv.index}"})
        if not exists:
            decisions.append({"cluster_id":cid,"stage1c2_status":"INPUT_MISSING","stage1c3_eligible":False,"reason":"required input missing"}); continue
        h=pd.read_csv(hp); s=pd.read_csv(sp)
        aligned=len(h)==len(s)
        checks.append({"cluster_id":cid,"check":"HUGS/source rows aligned","severity":"ERROR","passed":aligned,"detail":f"h={len(h)} s={len(s)}"})
        if not aligned: continue
        mto=float(inv.loc[cid,"provisional_msto_f814w"])
        checks.append({"cluster_id":cid,"check":"Stage1C1 MSTO anchor finite","severity":"ERROR","passed":np.isfinite(mto),"detail":f"msto={mto}"})
        base,quality,lo,hi=quality_mask(h,s,mto,protocol,qrows,cid)
        rgb,resid_sigma,ridge_nodes=rgb_locus_select(h,quality,lo,hi,protocol)
        nbase,nq,nrgb=int(base.sum()),int(quality.sum()),int(rgb.sum())
        minrgb=int(protocol["selection"]["min_final_rgb_stars"])
        checks.append({"cluster_id":cid,"check":"Final RGB sample adequate","severity":"ERROR","passed":nrgb>=minrgb,"detail":f"n_rgb={nrgb} threshold={minrgb}; base={nbase} quality={nq}"})
        rr=h.loc[rgb].copy(); rr["optical_rgb_residual_sigma"]=resid_sigma[rgb]
        mag=rr["mag_f814w"].to_numpy(float); X=rr["color_f275w_f814w"].to_numpy(float); C=rr["chromosome_c_f275w_f336w_f438w"].to_numpy(float)
        ex=fit_envelope(mag,X,lo,hi,protocol); ec=fit_envelope(mag,C,lo,hi,protocol)
        nodes_ok=ex is not None and ec is not None
        checks.append({"cluster_id":cid,"check":"Chromosome fiducial support adequate","severity":"ERROR","passed":nodes_ok,
                       "detail":f"nodes_X={len(ex[0]) if ex else 0} nodes_C={len(ec[0]) if ec else 0}"})
        if not nodes_ok:
            decisions.append({"cluster_id":cid,"stage1c2_status":"FIDUCIAL_SUPPORT_FAILED","stage1c3_eligible":False,"reason":"insufficient fiducial nodes"}); continue
        stx,sx=ex; stc,sc=ec
        xB,xM,xR=sx(mag); cB,cM,cR=sc(mag)
        wx=xR-xB; wc=cR-cB
        minw=float(protocol["fiducials"]["min_local_width_mag"])
        width_ok=bool(np.all(np.isfinite(wx)) and np.all(np.isfinite(wc)) and np.nanmin(wx)>minw and np.nanmin(wc)>minw)
        checks.append({"cluster_id":cid,"check":"Local fiducial widths positive and resolved","severity":"ERROR","passed":width_ok,
                       "detail":f"min_WX={np.nanmin(wx):.6f} min_WC={np.nanmin(wc):.6f} threshold={minw}"})
        ref=mto-float(protocol["fiducials"]["reference_offset_above_msto_mag"])
        xb_ref,xm_ref,xr_ref=sx(np.array([ref])); cb_ref,cm_ref,cr_ref=sc(np.array([ref]))
        W_X=float(xr_ref[0]-xb_ref[0]); W_C=float(cr_ref[0]-cb_ref[0])
        delta_x=W_X*(X-xR)/(xR-xB)
        delta_c=W_C*(cR-C)/(cR-cB)
        finite=bool(np.isfinite(delta_x).all() and np.isfinite(delta_c).all())
        checks.append({"cluster_id":cid,"check":"Verticalised coordinates finite","severity":"ERROR","passed":finite,"detail":f"finite={finite} n={nrgb}"})
        # Formula identity on the raw observables.
        calcX=rr["mag_f275w"]-rr["mag_f814w"]; calcC=rr["mag_f275w"]-2*rr["mag_f336w"]+rr["mag_f438w"]
        ferr=max(float(np.nanmax(np.abs(calcX-X))),float(np.nanmax(np.abs(calcC-C)))) if nrgb else np.inf
        checks.append({"cluster_id":cid,"check":"Chromosome raw formula identity","severity":"ERROR","passed":ferr<=float(protocol["validation"]["max_formula_identity_abs_error"]),"detail":f"max_abs_error={ferr:.3e}"})
        # Join to frozen Stage1B identity layer.
        smp=root/protocol["stage1b"]["source_to_master_pattern"].format(cluster=cid)
        sm=pd.read_csv(smp,low_memory=False); sm=sm[(sm["source_catalogue_group"]=="HUGS") & (~sm["exclude_duplicate_nonprimary"].fillna(False))]
        link=dict(zip(sm["source_row_id"].astype(str),sm["master_star_id"].astype(str)))
        rr["master_star_id"]=[link.get(str(x),np.nan) for x in rr["source_row_id"]]
        unlinked=float(rr["master_star_id"].isna().mean()) if nrgb else 1.0
        checks.append({"cluster_id":cid,"check":"Final RGB rows linked to Stage1B master IDs","severity":"ERROR","passed":unlinked<=float(protocol["validation"]["max_master_unlinked_fraction"]),"detail":f"unlinked_fraction={unlinked:.6f}"})
        # Confirm no classifier outputs are created upstream or here.
        nolabel=(rr.get("p_population_2p",pd.Series(index=rr.index,dtype=float)).notna().sum()==0 and rr.get("population_label",pd.Series(index=rr.index,dtype=object)).notna().sum()==0)
        checks.append({"cluster_id":cid,"check":"No population labels used or inferred","severity":"ERROR","passed":bool(nolabel),"detail":"Stage1C2 selection uses no population coordinate or radial information"})
        rrout=pd.DataFrame({
            "cluster_id":cid,"master_star_id":rr["master_star_id"].to_numpy(),"source_row_id":rr["source_row_id"].to_numpy(),
            "ra_deg":rr["ra_deg"].to_numpy(),"dec_deg":rr["dec_deg"].to_numpy(),"p_cluster_member":rr["p_cluster_member"].to_numpy(),
            "mag_f275w":rr["mag_f275w"].to_numpy(),"mag_f336w":rr["mag_f336w"].to_numpy(),"mag_f438w":rr["mag_f438w"].to_numpy(),
            "mag_f606w":rr["mag_f606w"].to_numpy(),"mag_f814w":rr["mag_f814w"].to_numpy(),
            "x_f275w_f814w":X,"c_f275w_f336w_f438w":C,"x_fid_blue":xB,"x_fid_red":xR,"c_fid_blue":cB,"c_fid_red":cR,
            "delta_f275w_f814w":delta_x,"delta_c_f275w_f336w_f438w":delta_c,"optical_rgb_residual_sigma":rr["optical_rgb_residual_sigma"].to_numpy(),
            "rgb_support_frozen":True,"population_label_status":"NOT_INFERRED_STAGE1C2"
        })
        cdir=out/"clusters"/cid; cdir.mkdir(parents=True,exist_ok=True)
        rrout.to_csv(cdir/f"{cid}_rgb_verticalised.csv.gz",index=False,compression="gzip")
        # Fiducial grid is data-supported and explicitly includes the bright reference endpoint.
        grid=np.unique(np.r_[np.arange(lo,hi+0.0001,0.02),ref,hi]); grid.sort()
        xbg,xmg,xrg=sx(grid); cbg,cmg,crg=sc(grid)
        for j,g in enumerate(grid):
            fidrows.append({"cluster_id":cid,"mag_f814w":g,"x_blue":xbg[j],"x_median":xmg[j],"x_red":xrg[j],"c_blue":cbg[j],"c_median":cmg[j],"c_red":crg[j],"within_frozen_rgb_support":bool(lo-1e-9<=g<=hi+1e-9)})
        pub=PUBLISHED_WIDTHS.get(cid,{})
        dX=abs(W_X-pub.get("W_X",np.nan))/pub.get("W_X",np.nan) if pub.get("W_X",0)>0 else np.nan
        dC=abs(W_C-pub.get("W_C",np.nan))/pub.get("W_C",np.nan) if pub.get("W_C",0)>0 else np.nan
        bench.append({"cluster_id":cid,"stage1c2_W_X":W_X,"published_W_X":pub.get("W_X",np.nan),"fractional_difference_X":dX,
                      "stage1c2_W_C":W_C,"published_W_C":pub.get("W_C",np.nan),"fractional_difference_C":dC,
                      "stage1c2_n_rgb":nrgb,"published_n_rgb":pub.get("N",np.nan),
                      "benchmark_status":"REVIEW" if max(dX,dC)>float(protocol["validation"]["benchmark_review_fractional_difference"]) else "CONSISTENT_DIAGNOSTIC",
                      "benchmark_is_gate":False})
        freeze.append({"cluster_id":cid,"msto_f814w_anchor":mto,"rgb_support_bright_f814w":lo,"rgb_support_faint_f814w":hi,
                       "n_candidate":nbase,"n_quality_pass":nq,"n_final_rgb":nrgb,"quality_retention":nq/max(nbase,1),"rgb_locus_retention":nrgb/max(nq,1),
                       "n_fiducial_nodes_x":len(stx),"n_fiducial_nodes_c":len(stc),"reference_f814w":ref,"W_X_reference":W_X,"W_C_reference":W_C,
                       "delta_x_median":float(np.nanmedian(delta_x)),"delta_c_median":float(np.nanmedian(delta_c)),"final_rgb_freeze":True,
                       "classifier_status":"BLOCKED_NOT_FIT"})
        decisions.append({"cluster_id":cid,"stage1c2_status":"RGB_VERTICALISATION_FROZEN","stage1c3_eligible":True,
                          "reason":"photometric quality, optical RGB locus, fiducial, identity, and master-link gates passed"})
        print(f"[Stage1C2] {cid}: candidate={nbase} quality={nq} RGB={nrgb} W_X={W_X:.4f} W_C={W_C:.4f}")
    # Write summary products.
    pd.DataFrame(freeze).to_csv(out/"stage1c2_rgb_freeze.csv",index=False)
    pd.DataFrame(fidrows).to_csv(out/"stage1c2_fiducial_grid.csv",index=False)
    pd.DataFrame(qrows).to_csv(out/"stage1c2_quality_envelopes.csv",index=False)
    pd.DataFrame(bench).to_csv(out/"stage1c2_external_width_benchmark.csv",index=False)
    pd.DataFrame(decisions).to_csv(out/"stage1c2_decision_ledger.csv",index=False)
    cdf=pd.DataFrame(checks); cdf.to_csv(val/"stage1c2_preflight.csv",index=False)
    err=cdf[(cdf.severity=="ERROR") & (~cdf.passed.astype(bool))]
    neligible=int(sum(bool(x.get("stage1c3_eligible",False)) for x in decisions))
    ready=bool(upstream and len(err)==0 and neligible==len(protocol["pilot_clusters"]))
    retained=list(protocol["retained_blockers"])
    disposition="RGB_VERTICALISATION_FROZEN_CLASSIFIER_BLOCKED" if ready else "RGB_VERTICALISATION_NOT_READY"
    meta={"stage":"Stage1C2","version":str(protocol["version"]),"generated_utc":utcnow(),"stage1c1_inventory_ready":upstream,
          "rgb_verticalisation_ready":ready,"classifier_ready":False,"science_ready":False,"n_clusters":len(protocol["pilot_clusters"]),
          "n_clusters_stage1c3_eligible":neligible,"n_checks":len(cdf),"n_error_failures":len(err),"n_retained_blockers":len(retained),
          "retained_blockers":retained,"disposition":disposition}
    (val/"stage1c2_preflight.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
    lines=["# Stage 1C2 preflight","",f"- Disposition: **{disposition}**",f"- RGB verticalisation ready: **{ready}**",f"- Stage1C3 eligible clusters: **{neligible}/{len(protocol['pilot_clusters'])}**",f"- Error failures: **{len(err)}**",f"- Retained blockers: **{len(retained)}**",""]
    if len(err):
        lines += ["## Failed error checks"]+[f"- {r.cluster_id} — {r.check}: {r.detail}" for _,r in err.iterrows()]+[""]
    lines += ["## Retained blockers"]+[f"- {x}" for x in retained]+["","## Claim boundary","No 1P/2P classifier, population label, radial prior, or population-separability claim is produced in Stage 1C2."]
    (val/"stage1c2_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    # output manifest
    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file(): manifest.append({"relative_path":str(p.relative_to(root)).replace("\\","/"),"bytes":p.stat().st_size,"sha256":sha256(p)})
    pd.DataFrame(manifest).to_csv(out/"stage1c2_output_manifest.csv",index=False)
    print(json.dumps(meta,indent=2))
    return 0 if ready else 2

if __name__=="__main__": raise SystemExit(main())
