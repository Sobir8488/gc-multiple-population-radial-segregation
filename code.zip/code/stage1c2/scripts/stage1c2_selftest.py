from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent))
from stage1c2_verticalize import binned_quantiles, running_quantile

def main():
    rng=np.random.default_rng(20260807)
    # Synthetic RGB with known smooth centre and two chemistry-induced envelopes.
    m=np.repeat(np.linspace(15,17,41),60)
    ridge=1.2+0.18*(m-16)+0.04*(m-16)**2
    v=ridge+rng.normal(0,0.03,len(m))
    st=binned_quantiles(m,v,15,17,0.24,0.07,15,(0.05,0.5,0.95))
    assert len(st)>=20
    assert np.all(st[:,4]>st[:,2])
    grid=np.arange(15,17.001,0.08)
    interp,nodes=running_quantile(m,v,grid,0.18,0.95,15)
    assert np.isfinite(interp).all() and np.isfinite(nodes).sum()>10
    # Exact Milone-style algebra at artificial blue/red boundaries.
    XB=np.array([1.0,1.2]); XR=np.array([1.4,1.6]); X=np.array([1.0,1.6]); WX=0.4
    dx=WX*(X-XR)/(XR-XB)
    assert np.allclose(dx,[-0.4,0.0])
    CB=np.array([-0.2,-0.1]); CR=np.array([0.2,0.3]); C=np.array([-0.2,0.3]); WC=0.4
    dc=WC*(CR-C)/(CR-CB)
    assert np.allclose(dc,[0.4,0.0])
    # Pandas/NumPy Copy-on-Write regression: writable boolean arrays are explicit copies.
    z=pd.Series([True,False,True]); a=z.to_numpy(dtype=bool,copy=True); a &= np.array([True,True,False]); assert a.tolist()==[True,False,False]
    print("STAGE1C2_SELFTEST: PASS")
    return 0
if __name__=="__main__": raise SystemExit(main())
