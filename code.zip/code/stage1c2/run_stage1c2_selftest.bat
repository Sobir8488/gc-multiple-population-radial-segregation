@echo off
python scripts\stage1c2_selftest.py || exit /b 1
