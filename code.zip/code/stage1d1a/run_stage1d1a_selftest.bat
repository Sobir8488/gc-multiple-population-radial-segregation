@echo off
python scripts\stage1d1a_selftest.py
