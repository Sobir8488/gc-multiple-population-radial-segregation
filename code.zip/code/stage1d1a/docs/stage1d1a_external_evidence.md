# Stage 1D1A external evidence note

The public HUGS release of Nardiello et al. (2018) provides three photometric catalogues per cluster and astrometrized stacked images. Its published catalogue schema contains five-band photometry, RMS/QFIT/RADXS diagnostics, exposure counts, membership probability, coordinates, source ID and finding iteration. The public release description does not list a homogeneous artificial-star recovery catalogue among the released products.

Artificial-star tests remain the correct route to absolute crowded-field detection completeness. Cluster-specific multiple-population studies, such as the M15 analysis, explicitly generated artificial RGB stars and measured recovery versus radius and magnitude.

Accordingly, Stage 1D1A does not substitute catalogue density or a convex hull for a true completeness/area model. It uses only the conditional population-fraction quantity for which common selection cancels.
