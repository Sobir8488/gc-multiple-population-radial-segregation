
from pathlib import Path
import argparse, json
import pandas as pd
import yaml
from stage1d1a_common import utcnow, write_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1a_protocol.yaml").read_text(encoding="utf-8"))
    s=pd.read_csv(root/"outputs/stage1d1a/stage1d1a_support_summary.csv")
    q=pd.read_csv(root/"outputs/stage1d1a/stage1d1a_rgb_measurement_quality.csv")
    checks=[]
    def add(name,passed,detail,severity="ERROR"):
        checks.append({"check":name,"passed":bool(passed),"severity":severity,"detail":detail})
    add("six HST-supported clusters audited",set(s.cluster_id)==set(cfg["clusters"]),f"{len(s)}/6")
    add("all six conditional Delta-gamma supports pass",s.conditional_delta_gamma_support_ready.all(),
        f"{int(s.conditional_delta_gamma_support_ready.sum())}/6")
    add("absolute density slopes remain blocked",(s.absolute_density_support_ready==False).all(),
        "AST/effective-area closure intentionally absent")
    add("frozen RGB stars have complete five-band measurements",
        (q.fraction_all_five_magnitudes_finite==1.0).all(),
        f"{int((q.fraction_all_five_magnitudes_finite==1.0).sum())}/6 clusters")
    nerr=sum((not x["passed"]) and x["severity"]=="ERROR" for x in checks)
    ready=(nerr==0 and s.conditional_delta_gamma_support_ready.all())
    obj={
      "stage":"Stage1D1A","version":"0.1.0","generated_utc":utcnow(),
      "conditional_delta_gamma_support_ready":bool(ready),
      "n_clusters_conditional_ready":int(s.conditional_delta_gamma_support_ready.sum()),
      "absolute_density_slopes_ready":False,
      "stage1d1b_authorized":bool(ready),
      "science_ready":False,
      "n_checks":len(checks),"n_error_failures":nerr,
      "n_retained_blockers":len(cfg["retained_blockers"]),
      "retained_blockers":cfg["retained_blockers"],
      "disposition":("CONDITIONAL_DELTA_GAMMA_SUPPORT_FROZEN_ABSOLUTE_SLOPES_BLOCKED"
                     if ready else "CONDITIONAL_SLOPE_SUPPORT_NOT_READY")
    }
    val=root/"validation"; val.mkdir(exist_ok=True)
    pd.DataFrame(checks).to_csv(val/"stage1d1a_preflight.csv",index=False)
    write_json(val/"stage1d1a_preflight.json",obj)
    lines=["# Stage 1D1A preflight","",
           f"- Disposition: **{obj['disposition']}**",
           f"- Conditional Delta-gamma support ready: **{obj['conditional_delta_gamma_support_ready']}**",
           f"- Conditional-ready clusters: **{obj['n_clusters_conditional_ready']}/6**",
           "- Absolute gamma_1P/gamma_2P ready: **False**",
           f"- Stage 1D1B authorized: **{obj['stage1d1b_authorized']}**",
           f"- Error failures: **{nerr}**","","## Cluster support"]
    for _,r in s.iterrows():
        lines.append(
          f"- {r.cluster_id}: N={int(r.n_rgb_probability_rows)}, "
          f"primary R=[{r.r_q05_arcsec:.2f},{r.r_q95_arcsec:.2f}] arcsec, "
          f"Nsupport={int(r.n_primary_radial_support)}, "
          f"confident 1P/2P={int(r.n_confident_1p_primary)}/{int(r.n_confident_2p_primary)}, "
          f"max radial-quintile ambiguity={r.max_radial_quintile_ambiguity_fraction:.3f}."
        )
    lines += ["","## Identifiability boundary",
      "The primary HST-only route is the conditional population-fraction likelihood. "
      "Under common selection of the two populations, footprint and detection completeness cancel from p2P(R), "
      "so Delta-gamma(R) is identifiable without claiming unavailable AST or effective-area products.",
      "",
      "Absolute Sigma_1P, Sigma_2P, gamma_1P and gamma_2P remain blocked until true completeness and footprint products are available."]
    (val/"stage1d1a_preflight.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(obj,indent=2))
    if nerr: raise SystemExit(2)

if __name__=="__main__":
    main()
