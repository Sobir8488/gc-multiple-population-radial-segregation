
import numpy as np
s1=np.array([2.,3.,5.]); s2=np.array([1.,2.,4.]); common=np.array([0.2,0.5,0.9])
assert np.allclose(s2/(s1+s2),(common*s2)/(common*s1+common*s2))
R=np.geomspace(1,100,1000); g1=0.8; g2=1.3
S1=R**(-g1); S2=2*R**(-g2); p=S2/(S1+S2)
z=np.log(p/(1-p)); dz=np.gradient(z,np.log(R))
assert abs(np.median(-dz)-(g2-g1))<1e-3
print("STAGE1D1A_SELFTEST: PASS")
