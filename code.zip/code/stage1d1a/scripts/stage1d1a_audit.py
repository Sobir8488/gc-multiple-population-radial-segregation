
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import yaml
from stage1d1a_common import sha256_file, utcnow, write_json

def num(x):
    return pd.to_numeric(x,errors="coerce")

def radial_quintile(r,n=5):
    r=np.asarray(r,float)
    order=np.argsort(r,kind="mergesort")
    out=np.empty(len(r),int)
    out[order]=np.floor(np.arange(len(r))*n/len(r)).astype(int)
    return np.clip(out,0,n-1)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",default="."); args=ap.parse_args()
    root=Path(args.root).resolve()
    cfg=yaml.safe_load((root/"config/stage1d1a_protocol.yaml").read_text(encoding="utf-8"))
    pre=json.loads((root/cfg["upstream"]["stage1c4r3_preflight"]).read_text(encoding="utf-8"))
    if pre.get("disposition")!="REVISED_CUBI_EVALUATION_COMPLETE_NO_GROUND_TRANSFER_VALIDATED":
        raise SystemExit("Unexpected Stage1C4R3 disposition.")
    out=root/"outputs/stage1d1a"; out.mkdir(parents=True,exist_ok=True)

    summaries=[]; quintiles=[]; quality=[]; inputs=[]
    qcfg=cfg["radial_support"]

    for cid in cfg["clusters"]:
        pp=root/cfg["upstream"]["stage1c3_probability_pattern"].format(cluster=cid)
        mp=root/cfg["upstream"]["stage1b_master_pattern"].format(cluster=cid)
        hp=root/cfg["upstream"]["hugs_normalized_pattern"].format(cluster=cid)
        sp=root/cfg["upstream"]["hugs_source_pattern"].format(cluster=cid)
        modp=root/cfg["upstream"]["stage1c3_model_pattern"].format(cluster=cid)
        for role,p in [("stage1c3_probabilities",pp),("stage1b_master",mp),
                       ("hugs_normalized",hp),("hugs_source",sp),("stage1c3_model",modp)]:
            inputs.append({"cluster_id":cid,"role":role,
                           "path":str(p.relative_to(root)).replace("\\","/"),
                           "bytes":p.stat().st_size,"sha256":sha256_file(p)})

        prob=pd.read_csv(pp,low_memory=False)
        master=pd.read_csv(mp,usecols=["master_star_id","x_common_arcsec","y_common_arcsec"],low_memory=False)
        hugs=pd.read_csv(hp,low_memory=False)
        src=pd.read_csv(sp,low_memory=False)
        if len(hugs)!=len(src):
            raise RuntimeError(f"{cid}: normalized/source HUGS row mismatch")

        j=prob.merge(master,on="master_star_id",how="left",validate="many_to_one")
        r=np.hypot(num(j.x_common_arcsec),num(j.y_common_arcsec)).to_numpy(float)
        q=num(j.population_probability_2p).to_numpy(float)
        if not np.isfinite(r).all() or not np.isfinite(q).all():
            raise RuntimeError(f"{cid}: non-finite radius or q2P")

        lo,hi=np.quantile(r,qcfg["primary_quantile_interval"])
        primary=(r>=lo)&(r<=hi)
        fq=radial_quintile(r,int(qcfg["audit_quintiles"]))
        maxamb=0.0; minbin=10**9
        for k in range(int(qcfg["audit_quintiles"])):
            m=fq==k
            qq=np.clip(q[m],1e-12,1-1e-12)
            amb=float(np.mean((qq>0.20)&(qq<0.80)))
            maxamb=max(maxamb,amb); minbin=min(minbin,int(m.sum()))
            quintiles.append({
                "cluster_id":cid,"radial_quintile":k,"n":int(m.sum()),
                "r_min_arcsec":float(np.min(r[m])),"r_median_arcsec":float(np.median(r[m])),
                "r_max_arcsec":float(np.max(r[m])),"mean_q2p":float(np.mean(qq)),
                "ambiguous_fraction":amb,
                "mean_binary_entropy_nats":float(np.mean(-(qq*np.log(qq)+(1-qq)*np.log(1-qq))))
            })

        n1=int(np.sum(q[primary]<=0.20)); n2=int(np.sum(q[primary]>=0.80))
        support_pass=(
            int(primary.sum())>=int(qcfg["minimum_stars_primary_support"]) and
            minbin>=int(qcfg["minimum_stars_per_radial_quintile"]) and
            maxamb<=float(qcfg["maximum_ambiguous_fraction_per_quintile"]) and
            n1>=int(qcfg["minimum_confident_1p"]) and n2>=int(qcfg["minimum_confident_2p"])
        )

        det_nonnull=int(hugs.completeness_detection.notna().sum()) if "completeness_detection" in hugs else 0
        cls_nonnull=int(hugs.completeness_classification.notna().sum()) if "completeness_classification" in hugs else 0
        fp_nonnull=int(hugs.footprint_valid.notna().sum()) if "footprint_valid" in hugs else 0

        # Exact row lookup by normalized source_row_id; row IDs are not assumed to equal row numbers.
        rowmap=pd.Series(np.arange(len(hugs),dtype=int),index=hugs.source_row_id.astype(str))
        try:
            idx=rowmap.loc[j.source_row_id.astype(str)].to_numpy(int)
        except KeyError as e:
            raise RuntimeError(f"{cid}: Stage1C3 HUGS source_row_id not present in normalized HUGS") from e
        hh=hugs.iloc[idx].reset_index(drop=True)
        ss=src.iloc[idx].reset_index(drop=True)
        magcols=["mag_f275w","mag_f336w","mag_f438w","mag_f606w","mag_f814w"]
        mags=np.column_stack([num(hh[c]).to_numpy(float) for c in magcols])
        rmscols=["RMS_F275W","RMS_F336W","RMS_F438W","RMS_F606W","RMS_F814W"]
        qfitcols=["QFIT_F275W","QFIT_F336W","QFIT_F438W","QFIT_F606W","QFIT_F814W"]
        rms=np.column_stack([num(ss[c]).to_numpy(float) for c in rmscols])
        qfit=np.column_stack([num(ss[c]).to_numpy(float) for c in qfitcols])
        maxrms=np.max(rms,axis=1)
        quality.append({
            "cluster_id":cid,"n_rgb":len(j),
            "fraction_all_five_magnitudes_finite":float(np.mean(np.isfinite(mags).all(axis=1))),
            "fraction_all_five_rms_finite":float(np.mean(np.isfinite(rms).all(axis=1))),
            "fraction_all_five_qfit_finite":float(np.mean(np.isfinite(qfit).all(axis=1))),
            "median_max_filter_rms_mag":float(np.median(maxrms)),
            "q95_max_filter_rms_mag":float(np.quantile(maxrms,0.95)),
        })

        summaries.append({
            "cluster_id":cid,"n_rgb_probability_rows":len(j),
            "r_q05_arcsec":float(lo),"r_q95_arcsec":float(hi),
            "n_primary_radial_support":int(primary.sum()),
            "n_confident_1p_primary":n1,"n_confident_2p_primary":n2,
            "max_radial_quintile_ambiguity_fraction":maxamb,
            "min_stars_per_radial_quintile":minbin,
            "hugs_detection_completeness_nonnull_rows":det_nonnull,
            "hugs_classification_completeness_nonnull_rows":cls_nonnull,
            "hugs_footprint_valid_nonnull_rows":fp_nonnull,
            "conditional_delta_gamma_support_ready":support_pass,
            "absolute_density_support_ready":False,
            "absolute_density_blocker":"AST_AND_EXACT_EFFECTIVE_AREA_NOT_PRESENT"
        })
        print(f"[Stage1D1A] {cid}: N={len(j)} support={int(primary.sum())} "
              f"1P/2P={n1}/{n2} maxAmb={maxamb:.3f} "
              f"conditional_ready={support_pass} absolute_ready=False")

    pd.DataFrame(summaries).to_csv(out/"stage1d1a_support_summary.csv",index=False)
    pd.DataFrame(quintiles).to_csv(out/"stage1d1a_radial_quintile_audit.csv",index=False)
    pd.DataFrame(quality).to_csv(out/"stage1d1a_rgb_measurement_quality.csv",index=False)
    pd.DataFrame(inputs).to_csv(out/"stage1d1a_input_manifest.csv",index=False)
    write_json(out/"stage1d1a_identifiability_boundary.json",{
        "stage":"Stage1D1A","version":"0.1.0","generated_utc":utcnow(),
        "primary_identifiable_quantity":"Delta_gamma(R)=-d logit[p_2P(R)]/d ln R",
        "conditional_selection_cancellation":"AUTHORIZED_UNDER_COMMON_SELECTION_ASSUMPTION",
        "absolute_population_density_slopes":"BLOCKED",
        "reason_absolute_blocked":[
            "no artificial-star/recovery completeness product in current normalized HUGS inputs",
            "no exact common-filter effective-area/footprint mask in current normalized HUGS inputs"
        ],
        "hard_label_primary_analysis":"FORBIDDEN","soft_q2p_required":True
    })
    rows=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="stage1d1a_output_manifest.csv":
            rows.append({"path":str(p.relative_to(out)).replace("\\","/"),
                         "bytes":p.stat().st_size,"sha256":sha256_file(p)})
    pd.DataFrame(rows).to_csv(out/"stage1d1a_output_manifest.csv",index=False)

if __name__=="__main__":
    main()
