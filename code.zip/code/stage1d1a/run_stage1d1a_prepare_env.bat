@echo off
python -c "import numpy,pandas,yaml; print('Stage1D1A environment: OK')"
