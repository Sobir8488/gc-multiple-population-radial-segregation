# Stage 1D1A v0.1.0 — HST-only conditional differential-slope support

The failed Stetson transfer does not prevent a strong HST-only differential result.

For the two population surface densities,

p_2P(R) = Sigma_2P(R) / [Sigma_1P(R) + Sigma_2P(R)],

and therefore

Delta_gamma(R) = gamma_2P(R) - gamma_1P(R)
               = - d logit[p_2P(R)] / d ln R.

If detection/footprint selection is common to the two populations within the same frozen RGB sample,
that common factor cancels exactly from the conditional population fraction. This lets the project
infer the differential local slope without pretending that public HUGS artificial-star completeness
or exact effective-area masks are already present.

Stage 1D1A is an identifiability/support freeze only; it does not fit the radial slope.
The primary future likelihood must use continuous Stage 1C3 q2P probabilities, not hard labels.

Absolute Sigma_1P, Sigma_2P, gamma_1P and gamma_2P remain blocked until artificial-star/recovery
and exact footprint products are available.

## Run

```bat
cd /d "%USERPROFILE%\Downloads\stage1a_source_acquisition_v0_1_0"
conda activate mp-slopes-stage1a
call run_stage1d1a_prepare_env.bat
call run_stage1d1a_selftest.bat
call run_stage1d1a.bat
```
