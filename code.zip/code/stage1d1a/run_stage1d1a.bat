@echo off
setlocal
python scripts\stage1d1a_selftest.py || exit /b 1
python scripts\stage1d1a_audit.py --root . || exit /b 1
python scripts\stage1d1a_preflight.py --root . || exit /b 1
echo STAGE1D1A: PASS
endlocal
