# Environment note

The analysis was run in the project conda environment `mp-slopes-stage1a`.

The stage scripts require, at minimum, Python with NumPy, pandas, SciPy, Matplotlib and PyYAML.
Exact dependency versions are not asserted here because this archive was assembled independently of the user's original local conda package lock. The algorithms, frozen configurations, random seeds and derived outputs are preserved.
